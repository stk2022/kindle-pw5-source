/***************************************************************************
 *
 * Multitouch X driver
 * Copyright (C) 2008 Henrik Rydberg <rydberg@euromail.se>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 **************************************************************************/

#include "gestures.h"
#include "log.h"
#include <pthread.h>
#include <sys/ioctl.h>
#include <math.h>
#include <linux/lab126_touch.h>
#include <linux/lab126_keypad.h>

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 3
#include <X11/Xatom.h>
#include <xserver-properties.h>
#include <multitouch-properties.h>
#define HAVE_PROPERTIES 1
#endif

#define RANDRSUPPORT 0
#if RANDRSUPPORT > 0
#include <randrstr.h>
#endif

#define GE_ALLOW_ALL                  0
#define GE_ALLOW_PINCH                1
#define GE_ALLOW_NONE                 2

#define MIN_KEYCODE 8
#define KEY_SCREENSHOT                KEY_SCROLLLOCK+MIN_KEYCODE
#define KEY_SWIPE_TOP                 KEY_PAGEDOWN+MIN_KEYCODE
#define KEY_SWIPE_HOME                KEY_HOME+MIN_KEYCODE

#define KEYPAD_DEBOUNCE_MS            30

#define MIN_DIST_PINCH_START_MM       23.0f

/* Only used to log whether short swipe will be ignored in CVM */
#define CVM_CLICK_RADIUS              7.55f

/* button mapping simplified */
#define PROPMAP(m, x, y) m[x] = XIGetKnownProperty(y)
#define RADIAN_TO_DEGREE(x) ((x) * 57.295779513)

/*Defining seperately in case stylus requires different threshold, defined in pixels */
#define STYLUS_SWIPE_THRESHOLD       105

/* Define the maximum tries of replug stylus device*/
#define STYLUS_REPLUG_MAXIMUM_TRIES    20

#ifdef HAVE_PROPERTIES
static Atom prop_orientation = 0;
static Atom prop_grip_suppr = 0;
#endif

static int compass[4][4] =
{
  {MT_BUTTON_SWIPE_UP, MT_BUTTON_SWIPE_DOWN, MT_BUTTON_SWIPE_LEFT, MT_BUTTON_SWIPE_RIGHT},
  {MT_BUTTON_SWIPE_DOWN, MT_BUTTON_SWIPE_UP, MT_BUTTON_SWIPE_RIGHT, MT_BUTTON_SWIPE_LEFT},
  {MT_BUTTON_SWIPE_LEFT, MT_BUTTON_SWIPE_RIGHT, MT_BUTTON_SWIPE_DOWN, MT_BUTTON_SWIPE_UP},
  {MT_BUTTON_SWIPE_RIGHT, MT_BUTTON_SWIPE_LEFT, MT_BUTTON_SWIPE_UP, MT_BUTTON_SWIPE_DOWN},
};

XkbRMLVOSet rmlvo;
pthread_mutex_t ge_mutex;
int g_touch_suppression = TOUCH_SUPPR_OFF;
int g_MT_TOOL_TYPE = MT_TOOL_FINGER;
int g_touch_cancel_sent = FALSE;
unsigned int g_MT_BUTTON_STATE=0;
int g_foreverReplugStylus = FALSE;
Orientation currOrientation=PORTRAIT_UP;

unsigned int g_log_level=0;

// Protos
static void handle_gestures(LocalDevicePtr local,
    const struct Gestures *gs,
    const struct Capabilities *caps);


  static void
SetXkbOption(InputInfoPtr pInfo, char *name, char **option)
{
  char *s;

  if ((s = xf86SetStrOption(pInfo->options, name, NULL))) {
    if (!s[0]) {
      xfree(s);
      *option = NULL;
    } else {
      *option = s;
    }
  }
}

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
static void initAxesLabels(Atom map[2])
{
  memset(map, 0, 2 * sizeof(Atom));
  PROPMAP(map, 0, AXIS_LABEL_PROP_ABS_X);
  PROPMAP(map, 1, AXIS_LABEL_PROP_ABS_Y);
}

static void initButtonLabels(Atom map[DIM_BUTTON])
{
  memset(map, 0, DIM_BUTTON * sizeof(Atom));
  PROPMAP(map, MT_BUTTON_LEFT, BTN_LABEL_PROP_BTN_LEFT);
  PROPMAP(map, MT_BUTTON_MIDDLE, BTN_LABEL_PROP_BTN_MIDDLE);
  /* how to map swipe buttons? */
  PROPMAP(map, MT_BUTTON_SWIPE_UP, BTN_LABEL_PROP_BTN_0);
  PROPMAP(map, MT_BUTTON_SWIPE_DOWN, BTN_LABEL_PROP_BTN_1);
  PROPMAP(map, MT_BUTTON_SWIPE_LEFT, BTN_LABEL_PROP_BTN_2);
  PROPMAP(map, MT_BUTTON_SWIPE_RIGHT, BTN_LABEL_PROP_BTN_3);
  /* how to map scale and rotate? */
  PROPMAP(map, MT_BUTTON_SCALE_DOWN, BTN_LABEL_PROP_BTN_4);
  PROPMAP(map, MT_BUTTON_SCALE_UP, BTN_LABEL_PROP_BTN_5);
  PROPMAP(map, MT_BUTTON_HOLD, BTN_LABEL_PROP_BTN_6);
}
#endif

static void pointer_control(DeviceIntPtr dev, PtrCtrl *ctrl)
{
}

static int device_init_valuators(DeviceIntPtr dev, LocalDevicePtr local, int orientation)
{
  struct MTouch *mt = local->private;
  unsigned char btmap[DIM_BUTTON + 1] = {
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9//, 10, 11, 12, 13, 14, 15
  };

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
  Atom axes_labels[2], btn_labels[DIM_BUTTON];
  initAxesLabels(axes_labels);
  initButtonLabels(btn_labels);
#endif

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) < 3
  InitPointerDeviceStruct((DevicePtr)dev,
      btmap, DIM_BUTTON,
      GetMotionHistory,
      pointer_control,
      GetMotionHistorySize(),
      2);
#elif GET_ABI_MAJOR(ABI_XINPUT_VERSION) < 7
  InitPointerDeviceStruct((DevicePtr)dev,
      btmap, DIM_BUTTON,
      pointer_control,
      GetMotionHistorySize(),
      2);
#elif GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
  InitPointerDeviceStruct((DevicePtr)dev,
      btmap, DIM_BUTTON, btn_labels,
      pointer_control,
      GetMotionHistorySize(),
      2, axes_labels);
#else
#error "Unsupported ABI_XINPUT_VERSION"
#endif

  if (orientation <= 1)
  {
    xf86InitValuatorAxisStruct(dev, 0,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
        axes_labels[0],
#endif
        mt->caps.abs[BIT_POSITION_X].minimum,
        mt->caps.abs[BIT_POSITION_X].maximum,
        10000, 0, 10000);
    xf86InitValuatorDefaults(dev, 0);
    xf86InitValuatorAxisStruct(dev, 1,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
        axes_labels[1],
#endif
        mt->caps.abs[BIT_POSITION_Y].minimum,
        mt->caps.abs[BIT_POSITION_Y].maximum,
        10000, 0, 10000);
    xf86InitValuatorDefaults(dev, 1);
  }
  else
  {
    xf86InitValuatorAxisStruct(dev, 0,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
        axes_labels[0],
#endif
        mt->caps.abs[BIT_POSITION_Y].minimum,
        mt->caps.abs[BIT_POSITION_Y].maximum,
        10000, 0, 10000);
    xf86InitValuatorDefaults(dev, 0);
    xf86InitValuatorAxisStruct(dev, 1,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
        axes_labels[1],
#endif
        mt->caps.abs[BIT_POSITION_X].minimum,
        mt->caps.abs[BIT_POSITION_X].maximum,
        10000, 0, 10000);
    xf86InitValuatorDefaults(dev, 1);
  }
  local->dev->valuator->mode = Absolute;
}

static int device_init_keyboard(DeviceIntPtr dev, LocalDevicePtr local)
{
  InputInfoPtr pInfo = dev->public.devicePrivate;

  /* sorry, no rules change allowed for you */
  xf86ReplaceStrOption(pInfo->options, "xkb_rules", "evdev");
  SetXkbOption(pInfo, "xkb_rules", &rmlvo.rules);
  SetXkbOption(pInfo, "xkb_model", &rmlvo.model);
  if (!rmlvo.model)
    SetXkbOption(pInfo, "XkbModel", &rmlvo.model);
  SetXkbOption(pInfo, "xkb_layout", &rmlvo.layout);
  if (!rmlvo.layout)
    SetXkbOption(pInfo, "XkbLayout", &rmlvo.layout);
  SetXkbOption(pInfo, "xkb_variant", &rmlvo.variant);
  if (!rmlvo.variant)
    SetXkbOption(pInfo, "XkbVariant", &rmlvo.variant);
  SetXkbOption(pInfo, "xkb_options", &rmlvo.options);
  if (!rmlvo.options)
    SetXkbOption(pInfo, "XkbOptions", &rmlvo.options);

  if (!InitKeyboardDeviceStruct(local->dev, &rmlvo, NULL, NULL))
  {
    xf86Msg(X_ERROR, "%s: Keyboard initialization failed. This "
        "could be a missing or incorrect setup of "
        "xkeyboard-config.\n", dev->name);
    return !Success;
  }
  return Success;
}

static int pointer_property(DeviceIntPtr dev,
    Atom property,
    XIPropertyValuePtr prop,
    BOOL checkonly)
{
  return Success;
}

static float convertX_to_mm(struct MTouch *mt, int x)
{
  struct Capabilities *caps = &mt->caps;
  return ((float)x * mt->options.size_x_mm / (float)get_cap_xsize(caps));
}

static float convertY_to_mm(struct MTouch *mt, int y)
{
  struct Capabilities *caps = &mt->caps;
  return ((float)y * mt->options.size_y_mm / (float)get_cap_ysize(caps));
}

#if RANDRSUPPORT > 0
static void setRotation(struct MTouch *mtouch, Rotation rotation)
{
  int orientation;

  switch(rotation)
  {
    case(RR_Rotate_90 ): orientation = 1; break; // Portrait down
    case(RR_Rotate_0  ): orientation = 3; break; // Landscape right
    case(RR_Rotate_270): orientation = 0; break; // Portrait up
    case(RR_Rotate_180): orientation = 2; break; // Landscape left
    default: orientation = 0;
  }

  mtouch->orientation = orientation;
}


// This expects framebuffer to start in UD mode
// This converts the touch positions based on the orientation of the screen
static void convertXY(LocalDevicePtr local, struct MTouch *mtouch, int *x, int *y)
{
  ScrnInfoPtr pScrn = xf86Screens[0];
  Rotation rotation = rrGetScrPriv(pScrn->pScreen) ? RRGetRotation(pScrn->pScreen) : RR_Rotate_270;
  int tmpX = *x;

  if (mtouch->options.randr == FALSE)
    rotation = RR_Rotate_270;

  setRotation(mtouch, rotation);

  switch(mtouch->orientation)
  {
    case 0: // Portrait UP
      break;
    case 1: // Portrait DOWN
      *x = mtouch->caps.abs[BIT_POSITION_X].maximum - *x - 1;
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1;
      break;
    case 2: // Landscape LEFT
      *x = *y;
      tmpX = mtouch->caps.abs[BIT_POSITION_X].maximum - tmpX - 1;
      *y = tmpX;
      break;
    case 3: // Landscape RIGHT
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1;
      *x = *y;
      *y = tmpX;
      break;
  }

  return;
}


// Sends a motion event that takes into account orientation
static void postConvertedMotionXY(LocalDevicePtr local, int x, int y)
{
  struct MTouch *mtouch = local->private;

  convertXY(local, mtouch, &x, &y);

  xf86XInputSetScreen(local, 0, x, y);

  xf86PostMotionEvent (local->dev, TRUE, 0, 2, x, y);
}
#else
static void convertXY(LocalDevicePtr local, struct MTouch *mtouch, int *x, int *y)
{
  int tmpX = *x;

  switch(mtouch->orientation)
  {
    case 0: // Portrait UP
      break;
    case 1: // Portrait DOWN
      *x = mtouch->caps.abs[BIT_POSITION_X].maximum - *x - 1;
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1;
      break;
    case 2: // Landscape LEFT
      *x = *y;
      tmpX = mtouch->caps.abs[BIT_POSITION_X].maximum - tmpX - 1;
      *y = tmpX;
      break;
    case 3: // Landscape RIGHT
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1;
      *x = *y;
      *y = tmpX;
      break;
  }
}



int lastMotionX=-1;
int lastMotionY=-1;
// Sends a motion event that takes into account orientation
static void postConvertedMotionXY(LocalDevicePtr local, int x, int y)
{
  struct MTouch *mtouch = local->private;

  convertXY(local, mtouch, &x, &y);
  if(lastMotionX==x && lastMotionY==y)
  {
    DEBUG_INFO(DEBUG_LLOG, "skipping motion event as it leads to the same pixel");
    return;
  }
  xf86XInputSetScreen(local, 0, x, y);
  xf86PostMotionEvent (local->dev, TRUE, 0, 2, x, y);
  lastMotionX=x;
  lastMotionY=y;
}
#endif // RANDRSUPPORT

static int do_grip_suppression(int enable)
{
  int fd;

  DEBUG_INFO(DEBUG_LLOG, "Doing grip suppression: %d\n", enable);
  fd = open(PATH_DEV_TOUCH, O_WRONLY);
  if (fd < 0) {
    DEBUG_INFO(DEBUG_LLOG, "Fail open\n");
    return -1;
  }
  if (ioctl(fd, TOUCH_IOCTL_GRIP_SUP_EN, &enable) < 0)
  {
    DEBUG_INFO(DEBUG_LLOG, "Fail ioctl\n");
    return -1;
  }
  close(fd);
}

static int do_keypad_touch_active(int touch)
{
  int fd;

  fd = open(PATH_DEV_KEYPAD, O_WRONLY);
  if (fd < 0) {
    DEBUG_INFO(DEBUG_LLOG, "Fail open keypad\n");
    return -1;
  }

  if (ioctl(fd, KEYPAD_IOCTL_TOUCH_ACTIVE, &touch) < 0)
  {
    DEBUG_INFO(DEBUG_LLOG, "Fail ioctl keypad touch active\n");
    return -1;
  }
  close(fd);
}

#ifdef HAVE_PROPERTIES
// Initialize the Orientation property
static void MTInitProperty(DeviceIntPtr dev)
{
  LocalDevicePtr local = dev->public.devicePrivate;
  struct MTouch *mtouch = local->private;
  int rc;

  prop_orientation = MakeAtom(MULTITOUCH_PROP_ORIENTATION, strlen(MULTITOUCH_PROP_ORIENTATION), TRUE);

  rc = XIChangeDeviceProperty(dev, prop_orientation, XA_INTEGER, 8,
      PropModeReplace, 1, &mtouch->orientation, FALSE);
  if (rc != Success)
    return;

  XISetDevicePropertyDeletable(dev, prop_orientation, FALSE);

  prop_grip_suppr = MakeAtom(MULTITOUCH_PROP_GRIPSUPR, strlen(MULTITOUCH_PROP_GRIPSUPR), TRUE);

  rc = XIChangeDeviceProperty(dev, prop_grip_suppr, XA_INTEGER, 8,
      PropModeReplace, 1, &mtouch->grip_suppression, FALSE);

  if (rc != Success)
    return;

  XISetDevicePropertyDeletable(dev, prop_grip_suppr, FALSE);
}

// Orientation property change request
static int MTSetProperty(DeviceIntPtr dev, Atom atom,
    XIPropertyValuePtr val, BOOL checkonly)
{
  LocalDevicePtr local = dev->public.devicePrivate;
  struct MTouch *mt = local->private;
  Atom axes_labels[2];

  if (atom == prop_orientation)
  {
    if (val->format != 8 || val->type != XA_INTEGER || val->size != 1)
      return BadMatch;
    if (!checkonly)
    {
      int orientation = (Orientation)*((BOOL*)val->data);
      if (orientation >= 0 && orientation < 4)
      {
        if (mt->orientation != orientation)
        {
          currOrientation=orientation;
          device_init_valuators(dev, local, orientation);
          mt->orientation = orientation;
          //Change vertical swipe angle to 60 if in landscape mode
          if (mt->orientation == 2 || mt->orientation == 3)
            mt->options.vswipe_angle = 60;
          else
            mt->options.vswipe_angle = 30;
        }
      }
    }
  }
  else if (atom == prop_grip_suppr)
  {
    if (!mt->options.grip_suppr)
      return Success;
    if (val->format != 8 || val->type != XA_INTEGER || val->size != 1)
      return BadMatch;
    if (!checkonly)
    {
      int grip_suppression = (int)*((BOOL*)val->data);
      grip_suppression = grip_suppression > 0 ? 1 : 0;
      DEBUG_INFO(DEBUG_LLOG, "Setting grip suppression : %d\n", grip_suppression);
      mt->grip_suppression = grip_suppression;
    }
  }
  return Success;
}

static int MTGetProperty(DeviceIntPtr dev, Atom property)
{
  return Success;
}

#endif

void* 
keypad_thread_handler(void *arg)
{
  struct input_event ev;
  static const mstime_t ms = 1000;
  struct MTouch *mt = arg;

  if (!mt->keypad.fd)
    return;

  while(42)
  {
    xf86ReadSerial(mt->keypad.fd, &ev, sizeof(struct input_event));

    switch(ev.type)
    {
      case EV_SYN:
        break;
      case EV_KEY:
        pthread_mutex_lock(&mt->keypad.mutex);
        mt->keypad.down_time = ev.time.tv_usec / ms + ev.time.tv_sec * ms;
        pthread_mutex_unlock(&mt->keypad.mutex);
        break;
    }
  }
}

static int device_init(DeviceIntPtr dev, LocalDevicePtr local)
{
  DEBUG_INFO(DEBUG_LLOG_PERF, "Touch debug: device init");
  struct MTouch *mt = local->private;

  local->fd = xf86OpenSerial(local->options);
  if (local->fd < 0) {
    xf86Msg(X_ERROR, "multitouch: cannot open device\n");
    return !Success;
  }
  if (configure_mtouch(mt, local->fd)) {
    xf86Msg(X_ERROR, "multitouch: cannot configure device\n");
    return !Success;
  }
  xf86CloseSerial(local->fd);

  device_init_valuators(dev, local, 0);
  device_init_keyboard(dev, local);

  mt->grip_suppression = mt->options.grip_suppr;

#ifdef HAVE_PROPERTIES
  MTInitProperty(dev);
  XIRegisterPropertyHandler(dev, MTSetProperty, MTGetProperty, NULL);
#endif
  return Success;
}

static int stylus_device_init(DeviceIntPtr dev, LocalDevicePtr local)
{
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: device init");
  struct stat statInfo;
  // /app/tools stuff will be surely deleted in GM builds
  // and we could include the file by default in our builds
  if (!stat("/app/tools/FOREVER_REPLUG_STYLUS", &statInfo)) {
    g_foreverReplugStylus = TRUE;
  }

  struct MTouch *mt = local->private;

  local->fd = xf86OpenSerial(local->options);
  if (local->fd < 0) {
    xf86Msg(X_ERROR, "stylus: cannot open device\n");
    return !Success;
  }
  if (configure_mtouch(mt, local->fd)) {
    xf86Msg(X_ERROR, "stylus: cannot configure device\n");
    return !Success;
  }
  xf86CloseSerial(local->fd);

  device_init_valuators(dev, local, 0);
  device_init_keyboard(dev, local);

  mt->grip_suppression = mt->options.grip_suppr;

#ifdef HAVE_PROPERTIES
  //ToDo the properties are already registered with multitouch. does not make sense to register again with the stylus dev pointer
  MTInitProperty(dev);
  XIRegisterPropertyHandler(dev, MTSetProperty, MTGetProperty, NULL);
#endif

  //ToDo the capability structure is unfilled for stylus. to be debugged why
  mt->caps.abs[BIT_POSITION_X].maximum=mt->options.res_x;
  mt->caps.abs[BIT_POSITION_Y].maximum=mt->options.res_y;

  return Success;
}



static int stylus_device_on(LocalDevicePtr local)
{
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: device on");
  struct MTouch *mt = local->private;
  local->fd = xf86OpenSerial(local->options);
  if (local->fd < 0) {
    xf86Msg(X_ERROR, "multitouch: cannot open device\n");
    return !Success;
  }
  if (open_mtouch(mt, local->fd)) {
    xf86Msg(X_ERROR, "multitouch: cannot grab device\n");
    return !Success;
  }
  xf86AddEnabledDevice(local);
  return Success;
}

static int stylus_device_off(LocalDevicePtr local)
{
  struct MTouch *mt = local->private;
  xf86RemoveEnabledDevice(local);
  if (close_mtouch(mt, local->fd))
    xf86Msg(X_WARNING, "multitouch: cannot ungrab device\n");
  xf86CloseSerial(local->fd);
  pthread_mutex_destroy(&mt->keypad.mutex);
  return Success;
}

static int stylus_device_close(LocalDevicePtr local)
{
  struct MTouch *mt = local->private;
  if (mt->ge_state.timer != NULL)
    TimerFree(mt->ge_state.timer);
  return Success;
}


static int device_on(LocalDevicePtr local)
{
  DEBUG_INFO(DEBUG_LLOG_PERF, "touch device on");
  struct MTouch *mt = local->private;
  local->fd = xf86OpenSerial(local->options);
  if (local->fd < 0) {
    xf86Msg(X_ERROR, "multitouch: cannot open device\n");
    return !Success;
  }
  if (open_mtouch(mt, local->fd)) {
    xf86Msg(X_ERROR, "multitouch: cannot grab device\n");
    return !Success;
  }

  pthread_mutex_init(&mt->keypad.mutex, NULL);

  if (mt->options.keypad)
  {
    mt->keypad.fd = open(mt->options.keypad, O_RDONLY);
    if (mt->keypad.fd)
    {
      pthread_attr_t attr;

      pthread_attr_init(&attr);
      pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
      pthread_create(&mt->keypad.thread, &attr, &keypad_thread_handler, mt);
      pthread_attr_destroy(&attr);
    }
    else
    {
      mt->keypad.fd = 0;
      xf86Msg(X_ERROR, "multitouch: Could not open specified keypad device : %s\n", mt->options.keypad);
    }
  }
  xf86AddEnabledDevice(local);
  return Success;
}

static int device_off(LocalDevicePtr local)
{
  struct MTouch *mt = local->private;
  xf86RemoveEnabledDevice(local);
  if (close_mtouch(mt, local->fd))
    xf86Msg(X_WARNING, "multitouch: cannot ungrab device\n");
  xf86CloseSerial(local->fd);
  if (mt->keypad.fd)
  {
    pthread_cancel(mt->keypad.thread);
    pthread_join(mt->keypad.thread, NULL);
    close(mt->keypad.fd);
    mt->keypad.fd = 0;
  }
  pthread_mutex_destroy(&mt->keypad.mutex);
  return Success;
}

static int device_close(LocalDevicePtr local)
{
  struct MTouch *mt = local->private;
  if (mt->ge_state.timer != NULL)
    TimerFree(mt->ge_state.timer);
  return Success;
}

static inline void send_button(LocalDevicePtr local, int id, int state)
{
  if(state==1)
  {
	 if((g_MT_TOOL_TYPE==MT_TOOL_PALM || g_touch_suppression == TOUCH_SUPPR_ON) && id!=MT_BUTTON_PALM)
	 {
		 //no new button down must be sent when palm is detected or touch supression is on
		 DEBUG_INFO(DEBUG_LLOG_PERF, "Skipped Sending button down id %d, MT_BTN_STATT 0x%x",id,g_MT_BUTTON_STATE);
     return;
    }

    if((g_MT_BUTTON_STATE & (1<<id))==0)
    {
      DEBUG_INFO(DEBUG_X_FULL, "Local FD without pos: %d", local->fd);
      struct timeval curTime;
      gettimeofday(&curTime, NULL);
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button %d down %d.%06d. MT_BUTTON_STATE 0x%x\n", id, (int)curTime.tv_sec, (int)curTime.tv_usec,g_MT_BUTTON_STATE);
      xf86PostButtonEvent(local->dev, FALSE, id, state, 0, 0);
      g_MT_BUTTON_STATE |= (1<<id);
    }
    else
    {
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button down cancelled for button %d , MT_BUTTON_STATE 0x%x", id, g_MT_BUTTON_STATE);
    }
  }
  else
  {
    if((g_MT_BUTTON_STATE & (1<<id))!=0)
    {
      DEBUG_INFO(DEBUG_X_FULL, "Local FD without pos: %d", local->fd);
      struct timeval curTime;
      gettimeofday(&curTime, NULL);
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button %d up %d.%06d. MT_BUTTON_STATE 0x%x\n", id, (int)curTime.tv_sec, (int)curTime.tv_usec,g_MT_BUTTON_STATE);
      xf86PostButtonEvent(local->dev, FALSE, id, state, 0, 0);
      g_MT_BUTTON_STATE &= ~(1<<id);
    }
    else
    {
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button up cancelled for button %d , MT_BUTTON_STATE 0x%x", id, g_MT_BUTTON_STATE);
    }
  }

}

static inline void send_button_with_position(LocalDevicePtr local, int id, int state, int x, int y)
{
  struct MTouch *mt = local->private;
  if(state==1)
  {
	 if((g_MT_TOOL_TYPE==MT_TOOL_PALM || g_touch_suppression == TOUCH_SUPPR_ON) && id!=MT_BUTTON_PALM)
	 {
		 //no new button down must be sent when palm is detected or touch supression is on
		 DEBUG_INFO(DEBUG_LLOG_PERF, "Skipped Sending button down id %d, MT_BTN_STATT 0x%x",id,g_MT_BUTTON_STATE);
     return;
    }

    if((g_MT_BUTTON_STATE & (1<<id))==0)
    {
      DEBUG_INFO(DEBUG_X_FULL, "Local FD without pos: %d", local->fd);
      struct timeval curTime;
      gettimeofday(&curTime, NULL);
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button %d down %d.%06d. MT_BUTTON_STATE 0x%x\n", id, (int)curTime.tv_sec, (int)curTime.tv_usec,g_MT_BUTTON_STATE);
      convertXY(local, mt, &x, &y);
      xf86XInputSetScreen(local, 0, x, y);
      xf86PostButtonEvent(local->dev, TRUE, id, state, 0, 2, x, y);
      g_MT_BUTTON_STATE |= (1<<id);
    }
    else
    {
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button down cancelled for button %d , MT_BUTTON_STATE 0x%x", id, g_MT_BUTTON_STATE);
    }
  }
  else
  {
    if((g_MT_BUTTON_STATE & (1<<id))!=0)
    {
      DEBUG_INFO(DEBUG_X_FULL, "Local FD without pos: %d", local->fd);
      struct timeval curTime;
      gettimeofday(&curTime, NULL);
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button %d up %d.%06d. MT_BUTTON_STATE 0x%x\n", id, (int)curTime.tv_sec, (int)curTime.tv_usec,g_MT_BUTTON_STATE);
      convertXY(local, mt, &x, &y);
      xf86XInputSetScreen(local, 0, x, y);
      xf86PostButtonEvent(local->dev, TRUE, id, state, 0, 2, x, y);
      g_MT_BUTTON_STATE &= ~(1<<id);
    }
    else
    {
      DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button up cancelled for button %d , MT_BUTTON_STATE 0x%x", id, g_MT_BUTTON_STATE);
    }
  }
}



// Tickle the key
static void tickle_key(LocalDevicePtr local, int key)
{
  DEBUG_INFO(DEBUG_LLOG, "Sending key event : %d\n", key);
  xf86PostKeyboardEvent(local->dev, key, 1);
  xf86PostKeyboardEvent(local->dev, key, 0);
}

static void tickle_button(LocalDevicePtr local, int id)
{
  send_button(local, id, 1);
  send_button(local, id, 0);
}

// Timer Function for HOLD event
static CARD32 timerFunc(OsTimerPtr timer, CARD32 now, pointer arg)
{
  LocalDevicePtr local = (LocalDevicePtr)arg;
  struct MTouch* mt = local->private;
  struct Gestures gs;
  int sigState;

  // Avoid any interruptions
  pthread_mutex_lock(&ge_mutex);
  DEBUG_INFO(DEBUG_X_FULL, "Timer holdActive = %u\n", mt->ge_state.holdActive);
  if (mt->ge_state.holdActive == FALSE)
  {
    pthread_mutex_unlock(&ge_mutex);
    return 0;
  }
  DEBUG_INFO(DEBUG_X_LOW, "Hold detected (%ums)\n", gettimems());
  mt->ge_state.holdActive = FALSE;
  mt->ge_state.gestureSent = GE_ALLOW_NONE;
  tickle_button(local, MT_BUTTON_HOLD+1);
  pthread_mutex_unlock(&ge_mutex);
  return 0;
}

/* Returns 1 if something happened. Returns 0 otherwize */
static int  button_scroll(LocalDevicePtr local,
    int btdec, int btinc,
    float *hScroll, float *vScroll,
    BOOL dirSwipe, float step)
{
  struct MTouch *mt = local->private;

  float distSquare = (*hScroll) * (*hScroll) + (*vScroll) * (*vScroll);
  float stepSquare = step * step;
  float clickSquare = CVM_CLICK_RADIUS * CVM_CLICK_RADIUS;

  if (distSquare > clickSquare && distSquare < stepSquare)
    DEBUG_INFO(DEBUG_LLOG_PERF, "Gesture travelling within grey zone");

  if (distSquare < stepSquare)
    return GE_ALLOW_ALL;

  if (distSquare > clickSquare && distSquare > stepSquare)
    DEBUG_INFO(DEBUG_LLOG_PERF, "Gesture travelling beyond swipe threshold");
  //send swipe event only on when you have fingers and not palm
    if (dirSwipe) {
      /* Send the button event to where the touch originialy started */
      tickle_button(local, btinc);
    } else {
      /* Send the button event to where the touch originialy started */
      tickle_button(local, btdec);
    }
  *hScroll = *vScroll = 0;

  return GE_ALLOW_NONE;
}

/* Returns 1 if something happened. Returns 0 otherwize */
static int  button_scale(LocalDevicePtr local,
    GestureState *gstate,
    int btdec, int btinc,
    float *scroll, float step,
    float new_distance)
{
  struct MTouch *mt = local->private;
  int ret = gstate->gestureSent;

  DEBUG_INFO(DEBUG_X_FULL, "Dist : %f __ new_dist : %f __ step : %f\n", *scroll, new_distance, step);
  while (new_distance < (*scroll - step)) {
    /* Send the button to event to where the touch originialy started */
     //send scale event only on when you have fingers and not palm
    tickle_button(local, btdec);
    
    *scroll -= step;
    ret = GE_ALLOW_PINCH;
  }
  while (new_distance > (*scroll + step)) {
    /* Send the button to event to where the touch originialy started */
    //send scale event only on when you have fingers and not palm
      tickle_button(local, btinc);
    
    *scroll += step;
    ret = GE_ALLOW_PINCH;
  }
  return ret;
}

static void clear_gesture_state(LocalDevicePtr local,
    const struct Gestures *gs,
    GestureState *gstate,
    int nFingers)
{
  DEBUG_INFO(DEBUG_X_FULL, "Fingers detected : %d\n", nFingers);
  /* Send one gesture until finger released */
  if (!gs->same_fingers || !nFingers)
  {
    gstate->vscroll = 0;
    gstate->hscroll = 0;
    gstate->vswipe = 0;
    gstate->hswipe = 0;
  //  TODO: Seperate hold variable for stylus
    gstate->holdActive = FALSE;
    DEBUG_INFO(DEBUG_LLOG_PERF, "Clear holdActive : %d\n", gstate->holdActive);
    /* Clear scale state */
    gstate->distance = 0;
  }

  if(!nFingers)
    gstate->gestureSent = GE_ALLOW_ALL;
}

/**
 * Get the index of the release button
 */
static int get_buttonUp_index(struct MTouch * mt)
{
    // find the correct finger which is lifted
    int i = 0;
    foreach_bit(i, mt->mem.prev_fingers) {
      const struct FingerState *prev = &mt->prev_state.finger[i];
      int tracking_id = prev->tracking_id;
      const struct FingerState *f = find_finger(&mt->state, tracking_id);
      if (!f) {
          // This finger is not active now
          break;
      }
    }

    if (i >= mt->mem.prev_fingers) {
        i = -1;
    }
    return i;
}

/* If the fingers are release too quickly the else statement sends the events */
/* from lower to higher. We want to make sure button 2 is released first      */
/* so that the toolkits can synthesize a click event on a very quick tap.     */
/* If button 2 was down make sure we send the events in backwards order       */
static void handle_button_events(LocalDevicePtr local,
    const struct Gestures *gs,
    GestureState *gstate,
    int nFingers)
{
  struct MTouch *mt = local->private;
  int i = 0;
  int motionx;
  int motiony;

  DEBUG_INFO(DEBUG_X_LOW, "Fingers: %d __ PrevFingers: %d\n", nFingers, gstate->nPrevFingers);
  /* Have to handle these cases explicitely to reposition the cursor */
  if (nFingers == 0 && gstate->nPrevFingers >= 2)
  {
      if (mt->options.multitouch && gstate->nPrevFingers == 2) {
          postConvertedMotionXY(local, mt->prev_state.finger[1].position_x, mt->prev_state.finger[1].position_y);
          send_button_with_position(local, MT_BUTTON_MIDDLE+1, 0, mt->prev_state.finger[1].position_x, mt->prev_state.finger[1].position_y);
          
          postConvertedMotionXY(local, mt->prev_state.finger[0].position_x, mt->prev_state.finger[0].position_y);
          send_button_with_position(local, MT_BUTTON_LEFT+1, 0, mt->prev_state.finger[0].position_x, mt->prev_state.finger[0].position_y);
      } else {
          send_button(local, MT_BUTTON_MIDDLE+1, 0);
          send_button(local, MT_BUTTON_LEFT+1, 0);
      }
  }
  else if (nFingers == 1 && gstate->nPrevFingers >= 2)
  {
    BOOL isButtonEventSent = FALSE;
    if (mt->options.multitouch && gstate->nPrevFingers == 2 ) {
        int index = get_buttonUp_index(mt);
        if (index >= 0 ) {
            postConvertedMotionXY(local, mt->prev_state.finger[index].position_x,  mt->prev_state.finger[index].position_y);
            send_button_with_position(local, MT_BUTTON_MIDDLE+1, 0,  mt->prev_state.finger[index].position_x,  mt->prev_state.finger[index].position_y);
            isButtonEventSent = TRUE;
        }
    } 
    
    if (!isButtonEventSent) {
        send_button(local, MT_BUTTON_MIDDLE+1, 0);
    }
    postConvertedMotionXY(local, gs->x, gs->y);
  }
  else if (nFingers > 0)
  {
    /* Number of fingers changed. Reposition the cursor */
    if (nFingers != gstate->nPrevFingers)
    {
      if (nFingers == 1)
      {
        DEBUG_INFO(DEBUG_X_LOW, "Touch down X: %d Y: %d (%ums)\n", mt->mem.xdown, mt->mem.ydown, gettimems());
        if (mt->options.debug)
        {
          DEBUG_INFO(DEBUG_LLOG, "Touch down X: %d Y: %d (%ums)\n", mt->mem.xdown, mt->mem.ydown, gettimems());
        }
        // Send the position
        postConvertedMotionXY(local, gs->x, gs->y);
        if (gstate->nPrevFingers == 2) {
            BOOL isButtonEventSent = FALSE;
            if (mt->options.multitouch) {
               int index = get_buttonUp_index(mt);
                if (index >= 0 ) {
                    postConvertedMotionXY(local, mt->prev_state.finger[index].position_x,  mt->prev_state.finger[index].position_y);
                    send_button_with_position(local, MT_BUTTON_MIDDLE+1, 0,  mt->prev_state.finger[index].position_x,  mt->prev_state.finger[index].position_y);
                    isButtonEventSent = TRUE;
                }
	    }

            if (!isButtonEventSent) {
                send_button(local, MT_BUTTON_MIDDLE+1, 0);
	    }
        } else {
            send_button(local, MT_BUTTON_LEFT+1, 1);
        }
      }

      if (nFingers > 1 && gstate->gestureSent < GE_ALLOW_NONE)
      {
        if (!gstate->nPrevFingers)
        {
          // 2 Finger from zero. Send one of the 2 touch positions
          // before sending the centroid
          postConvertedMotionXY(local, mt->mem.xdown, mt->mem.ydown);
          if (mt->options.multitouch && nFingers == 2) {
              postConvertedMotionXY(local, mt->state.finger[0].position_x,  mt->state.finger[0].position_y);
              send_button_with_position(local, MT_BUTTON_LEFT+1, 1,  mt->state.finger[0].position_x,  mt->state.finger[0].position_y);
          } else {
              send_button_with_position(local, MT_BUTTON_LEFT+1, 1, gs->x, gs->y);
          }
        }

        /* Cancel hold timer and stop gestures other than pinch */
        DEBUG_INFO(DEBUG_X_FULL, "Canceled hold timer\n");
        gstate->holdActive = FALSE;
        gstate->distance = gs->distance;

        if (mt->options.multitouch && nFingers == 2) {
            postConvertedMotionXY(local, mt->state.finger[1].position_x,  mt->state.finger[1].position_y);
            send_button_with_position(local, MT_BUTTON_MIDDLE+1, 1,  mt->state.finger[1].position_x,  mt->state.finger[1].position_y);
        } else {
            // Send the centroid position with the button.
            send_button_with_position(local, MT_BUTTON_MIDDLE+1, 1, gs->x, gs->y);
        }
      }
      else if (nFingers == 1 && gstate->nPrevFingers == 0 && gstate->gestureSent == GE_ALLOW_ALL)
      {
        /* We can hold in this case. Let's start the timer */
        gstate->holdActive = TRUE;
        DEBUG_INFO(DEBUG_LLOG_PERF, "Can hold : %d. Starting timer\n");
        gstate->timer = TimerSet(gstate->timer, 0, mt->options.hold_time, timerFunc, local);
        // Send the position
        postConvertedMotionXY(local, gs->x, gs->y);
      }
    }
  }
  else if (gstate->nPrevFingers == 1)
  {
    DEBUG_INFO(DEBUG_X_LOW, "Touch up X: %d Y: %d (%ums)\n", mt->mem.xup, mt->mem.yup, gettimems());
    send_button(local, MT_BUTTON_LEFT+1, 0);
    if (mt->options.debug)
    {
      DEBUG_INFO(DEBUG_LLOG, "Touch up X: %d Y: %d (%ums)\n", mt->mem.xup, mt->mem.yup, gettimems());
    }
  }
}

static int is_within_threshold(struct MTouch *mt, int x, int y, float threshold)
{
  float dx = convertX_to_mm(mt, x);
  float dy = convertY_to_mm(mt, y);
  float distSqr = dx*dx + dy*dy;
  float maxDistSqr = threshold*threshold;

  DEBUG_INFO(DEBUG_X_FULL, "DX : %f __ DY : %f __ DSQR: %f __ maxDist: %f\n", dx, dy, distSqr, threshold);

  if (distSqr > maxDistSqr)
    return 0;
  return 1;
}

static void handle_move_events(LocalDevicePtr local,
    const struct Gestures *gs,
    const struct Capabilities *caps,
    GestureState *gstate,
    int nFingers)
{
  struct MTouch *mt = local->private;

  if (!nFingers)
    return;

  // Don't move on 2 finger down if pinch is not allowed
  if (nFingers > 1 && gstate->gestureSent == GE_ALLOW_NONE)
    return;

  DEBUG_INFO(DEBUG_X_FULL, "Testing GS_MOVE\n");
  if (GETBIT(gs->type, GS_MOVE))
  {
    DEBUG_INFO(DEBUG_X_FULL, "In handle_move_events : %d\n", gstate->gestureSent);
    // Touch has moved.
    postConvertedMotionXY(local, gs->x, gs->y);
    /* Update the HOLD timer only if we are in the initiale state */
    if (gstate->gestureSent == GE_ALLOW_ALL)
    {
      DEBUG_INFO(DEBUG_X_FULL, "In handle_move_events : %d\n", mt->mem.xdown);
      if (mt->mem.xdown)
      {
        if (!is_within_threshold(mt, mt->mem.xdown - gs->x, mt->mem.ydown - gs->y,
             mt->options.min_hold_dist)) {
          DEBUG_INFO(DEBUG_X_FULL, "Canceling. Moved out of HOLD radius\n");
          gstate->holdActive = FALSE;
        }
      }
    }
    else
    {
      DEBUG_INFO(DEBUG_X_FULL, "ALLOW ALL NOT SET : holdActive : %d\n", gstate->holdActive);
      gstate->holdActive = FALSE;
    }
  }
}

static void handle_swipe_events(LocalDevicePtr local,
    const struct Gestures *gs,
    const struct Capabilities *caps,
    GestureState *gstate,
    int nFingers)
{
  struct MTouch *mt = local->private;

  if (nFingers > 1 || (!nFingers && !gstate->nPrevFingers))
    return;

  if (!GETBIT(gs->type, GS_HSWIPE) && !GETBIT(gs->type, GS_VSWIPE))
    return;

  if (gstate->gestureSent != GE_ALLOW_ALL)
    return;

  gstate->hswipe += convertX_to_mm(mt, gs->dx);
  gstate->vswipe += convertY_to_mm(mt, gs->dy);

  /* Send a swipe if no swipe event was previously sent */
  if (GETBIT(gs->type, GS_VSWIPE)) {
    gstate->gestureSent = button_scroll(local, compass[mt->orientation][0]+1, compass[mt->orientation][1]+1, &gstate->hswipe,
        &gstate->vswipe, (gstate->vswipe >= 0), mt->options.min_swipe);
  } else {
    gstate->gestureSent = button_scroll(local, compass[mt->orientation][2]+1, compass[mt->orientation][3]+1, &gstate->hswipe,
        &gstate->vswipe, (gstate->hswipe >= 0), mt->options.min_swipe);
  }
}

static void handle_scale_events(LocalDevicePtr local,
    const struct Gestures *gs,
    const struct Capabilities *caps,
    GestureState *gstate,
    int nFingers)
{
  struct MTouch *mt = local->private;

  if (nFingers < 2)
    return;

  if (GETBIT(gs->type, GS_SCALE) && (gstate->gestureSent < GE_ALLOW_NONE)) {
    if (gstate->distance == 0.0f) {
      if (gs->distance < MIN_DIST_PINCH_START_MM) {
        return;
      }
      gstate->distance = gs->distance;
    }

    gstate->gestureSent = button_scale(local, gstate, MT_BUTTON_SCALE_DOWN+1, MT_BUTTON_SCALE_UP+1, &gstate->distance,
        mt->options.min_scale, gs->distance);
  }
}


static int handle_screenshot(LocalDevicePtr local,
    const struct Gestures *gs,
    GestureState *gstate,
    int nFingers)
{
  struct MTouch *mt = local->private;

  if (mt->options.screenshot && GETBIT(gs->type, GS_SCREENSHOT))
  {
    if (gstate->gestureSent < GE_ALLOW_PINCH)
      tickle_key(local, KEY_SCREENSHOT);
    gstate->gestureSent = GE_ALLOW_NONE;
    return 1;
  }
  return 0;
}

static int handle_suppressed(LocalDevicePtr local,
    const struct Gestures *gs,
    GestureState *gstate,
    int nActive)
{
  struct MTouch *mt = local->private;
  int nFingers = bitcount(mt->mem.fingers);
  int prevFingers = bitcount(mt->mem.prev_fingers);
  int i;

  if (!nActive)
  {
    foreach_bit(i, mt->mem.prev_fingers) {
      const struct FingerState *prev = &mt->prev_state.finger[i];
      int tracking_id = prev->tracking_id;
      const struct FingerState *f = find_finger(&mt->state, tracking_id);

      if (nFingers != prevFingers)
      {
        if (!f && GETBIT(mt->mem.prev_suppressed, tracking_id))
        {
          if ((mt->state.evtime - mt->mem.touch_down[tracking_id]) <= mt->options.suppressed_tap_time)
          {
            // Did a keypad event trigger ?
            pthread_mutex_lock(&mt->keypad.mutex);
            if ((mt->keypad.down_time >= (mt->mem.touch_down[tracking_id] - KEYPAD_DEBOUNCE_MS)) &&
									(mt->keypad.down_time < (mt->state.evtime + KEYPAD_DEBOUNCE_MS)))
            {
              pthread_mutex_unlock(&mt->keypad.mutex);
              continue;
            }
            pthread_mutex_unlock(&mt->keypad.mutex);
            postConvertedMotionXY(local, prev->position_x, prev->position_y);
            tickle_button(local, MT_BUTTON_LEFT+1);
            break;
          }
        }
      }
      else if (f)
      {
        // Move distance
        if (!is_within_threshold(mt, mt->mem.down_pos[f->tracking_id].x - f->position_x,
              mt->mem.down_pos[f->tracking_id].y - f->position_y, mt->options.min_suppressed_move))
        {
          // The finger has moved out of suppression radius
          // Make the finger ACTIVE
          CLEARBIT(mt->mem.suppressed, f->tracking_id);
          SETBIT(mt->mem.active, f->tracking_id);
          SETBIT(mt->mem.pointing, i);
          postConvertedMotionXY(local, mt->mem.down_pos[f->tracking_id].x, mt->mem.down_pos[f->tracking_id].y);
          send_button(local, MT_BUTTON_LEFT+1, 1);
          mt->mem.xdown = mt->mem.down_pos[f->tracking_id].x;
          mt->mem.ydown = mt->mem.down_pos[f->tracking_id].y;
          mt->mem.dx[i] = f->position_x - mt->mem.down_pos[f->tracking_id].x;
          mt->mem.dy[i] = f->position_y - mt->mem.down_pos[f->tracking_id].y;
          break;
        }
      }
    }
  }
  return bitcount(mt->mem.pointing);
}

static void handle_gestures(LocalDevicePtr local,
    const struct Gestures *gs,
    const struct Capabilities *caps)
{
  struct MTouch *mt = local->private;
  GestureState  *gstate = &mt->ge_state;

  /* Get the number of fingers currently detected */
  int nFingers = bitcount(mt->mem.fingers);
  int nActive = bitcount(mt->mem.pointing);
  int nSuppressed = bitcount(mt->mem.suppressed);
  int prevFingers = bitcount(mt->mem.prev_fingers);
  int nNewActive;

  DEBUG_INFO(DEBUG_X_FULL, "Fingers: %d __ Prev_Fingers: %d __ Active: %d __ Suppressed: %d\n", nFingers, prevFingers, nActive, nSuppressed);

  DEBUG_INFO(DEBUG_X_FULL, "Handling grip suppression\n");
  nNewActive = handle_suppressed(local, gs, gstate, nActive);
  
  /*
  if(g_touch_suppression == TOUCH_SUPPR_ON)
  {
        DEBUG_INFO(DEBUG_LLOG_PERF, "Handling touch suppression with stylus in contact");
        //cancel the hold if active
        gstate->holdActive=FALSE;

        if(!(nFingers < g_buttons_sent))
          goto out;
  }
  */

  if(g_MT_TOOL_TYPE==MT_TOOL_PALM || g_touch_suppression == TOUCH_SUPPR_ON)
  {
	    DEBUG_INFO(DEBUG_LLOG_PERF, "Touch cancel. palm %d, supression %d",g_MT_TOOL_TYPE,g_touch_suppression);
      if(g_touch_cancel_sent==FALSE &&  g_MT_BUTTON_STATE!=0) //need to send BTN 10/touch cancel only when there are some btn down's already sent
      {
        //cancel the hold if enabled
        gstate->holdActive=FALSE;
        tickle_button(local,MT_BUTTON_PALM);
        g_touch_cancel_sent=TRUE;
        DEBUG_INFO(DEBUG_LLOG_PERF, "Cancelling hold due to touch cancel");
      }
      if(nFingers < prevFingers)
      {
          //likely UP event to complement the previous btn DOWN
          handle_button_events(local, gs, gstate, nActive);
      }
	    goto out;
  }
  else
  {
      g_touch_cancel_sent=FALSE; 
  }

  if (mt->options.keypad)
  {
    if ((nNewActive && !gstate->nPrevFingers) ||
        (!nNewActive && gstate->nPrevFingers))
      do_keypad_touch_active(nNewActive);
  }

  if (nNewActive != nActive)
    goto out;

  DEBUG_INFO(DEBUG_X_FULL, "Handling screenshot");
  if (handle_screenshot(local, gs, gstate, nFingers))
    return;

  DEBUG_INFO(DEBUG_X_FULL, "Clearing gesture state\n");
  clear_gesture_state(local, gs, gstate, nActive);

  DEBUG_INFO(DEBUG_X_FULL, "Move events\n");
  handle_move_events(local, gs, caps, gstate, nActive);

  DEBUG_INFO(DEBUG_X_FULL, "Button event\n");
  handle_button_events(local, gs, gstate, nActive);

  DEBUG_INFO(DEBUG_X_FULL, "Swipe events\n");
  handle_swipe_events(local, gs, caps, gstate, nActive);

  DEBUG_INFO(DEBUG_X_FULL, "Pinch events\n");
  handle_scale_events(local, gs, caps, gstate, nActive);

out:
  DEBUG_INFO(DEBUG_X_FULL, "Setting prev fingers.. out\n");
  finalize_memory(&mt->mem);
  gstate->nPrevFingers = nActive;
  mt->prev_state = mt->state;
}
int calculate_angle(struct MTouch* mt)
{
      DEBUG_INFO(DEBUG_LLOG_PERF, "Entering print angle");
      float angleX = 0.0f;
      float angleY = 90.0f;
      if (mt->mem.stylus_ydown - mt->mem.stylus_dy!=0)
      {
        angleX = atanf((float)(mt->mem.stylus_dy - (float)mt->mem.stylus_ydown) /
            (float)(mt->mem.stylus_dx - (float)mt->mem.stylus_xdown));
        angleX = fabs(RADIAN_TO_DEGREE(angleX));
      }
      angleY -= angleX;
      DEBUG_INFO(DEBUG_LLOG_PERF, "Printing angle: %.6f", angleY);
      if (angleY < mt->options.vswipe_angle)
      {
        return 0;
      }
      return 1;
}
int is_within_stylus_threshold(struct MTouch *mt, int dx, int dy, int threshold) {
  int distSqr = dx*dx + dy*dy;
  int maxDistSqr = threshold*threshold;
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus DX : %d __ DY : %d __ DSQR: %d __ maxDist: %d", dx, dy, distSqr, maxDistSqr);
  if (distSqr > maxDistSqr)
    return 0;
  return 1;
}

static inline void send_button_stylus(LocalDevicePtr local, int id, int state)
{

  DEBUG_INFO(DEBUG_X_FULL, "Local FD without pos: %d", local->fd);
  DEBUG_INFO(DEBUG_LLOG_PERF, "Sending button - stylus %d %s", id, (state?"down":"up"));
  xf86PostButtonEvent(local->dev, FALSE, id, state, 0, 0);
}

static void tickle_button_stylus(LocalDevicePtr local, int id)
{
  send_button_stylus(local, id, 1);
  send_button_stylus(local, id, 0);
}

static int  stylus_scroll(LocalDevicePtr local, 
    int btdec, int btinc,
    BOOL dirSwipe)
{
  if (dirSwipe) {
    /* Send the button event to where the touch originialy started */
    tickle_button_stylus(local, btinc);
  } else {
    /* Send the button event to where the touch originialy started */
    tickle_button_stylus(local, btdec);
  }
  return 1;
}

// Stylus timer Function for HOLD event
static CARD32 stylusTimerFunc(OsTimerPtr timer, CARD32 now, pointer arg)
{
  LocalDevicePtr local = (LocalDevicePtr)arg;
  struct MTouch* mt = local->private;
  struct Gestures gs;

  // Avoid any interruptions
  pthread_mutex_lock(&ge_mutex);
  DEBUG_INFO(DEBUG_X_FULL, "Timer holdActive = %u\n", mt->ge_state.stylusCanHold);
  if (mt->ge_state.stylusCanHold == FALSE)
  {
    pthread_mutex_unlock(&ge_mutex);
    return 0;
  }
  DEBUG_INFO(DEBUG_X_LOW, "Hold detected (%ums)\n", gettimems());
  mt->ge_state.stylusCanHold = FALSE;
  tickle_button_stylus(local, MT_BUTTON_HOLD+1);
  mt->ge_state.isStylusHoldEventSent = TRUE;
  pthread_mutex_unlock(&ge_mutex);
  return 0;
}

void stylus_gestures(LocalDevicePtr local, struct MTouch* mt)
{
        int xmove, ymove;
        DEBUG_INFO(DEBUG_X_FULL,"Entering stylus gestures: on_display= %d swipe_event= %d tap_event= %d", mt->hs.stylus_data.on_display, mt->hs.stylus_data.swipe_sent, mt->hs.stylus_data.tap_sent);
        mt->orientation=currOrientation;

        if(mt->hs.stylus_data.on_display == 1)
        {
            if(mt->hs.stylus_data.tap_sent == 0)
            {
                //first packet
                DEBUG_INFO(DEBUG_LLOG_PERF,"stylus gestures: sending tap. on_display= %d swipe_event= %d tap_event= %d", mt->hs.stylus_data.on_display, mt->hs.stylus_data.swipe_sent, mt->hs.stylus_data.tap_sent);
                mt->hs.stylus_data.tap_sent = 1;
                postConvertedMotionXY(local, mt->mem.stylus_xdown, mt->mem.stylus_ydown);
                #ifdef STYLUS_DISTINCTION
                  send_button_stylus(local, STYLUS_SCREEN_TOUCH, BTN_STATE_DOWN);
                #endif
                send_button_stylus(local, 1, 1);
                mt->hs.stylus_data.swipe_sent = 0;
                mt->ge_state.stylusCanHold = TRUE;
                mt->ge_state.isStylusHoldEventSent = FALSE;
                mt->ge_state.stylusTimer = TimerSet(mt->ge_state.stylusTimer, 0, mt->options.hold_time, stylusTimerFunc, local);
                DEBUG_INFO(DEBUG_LLOG_PERF, "Can hold : Starting timer\n");
            }
            else
            {
                //subsequest packets
                xmove = mt->mem.stylus_dx - mt->mem.stylus_xdown;
                ymove = mt->mem.stylus_dy - mt->mem.stylus_ydown;
                DEBUG_INFO(DEBUG_X_FULL,"xmove, ymove = %d %d", xmove, ymove);
                postConvertedMotionXY(local, mt->mem.stylus_dx, mt->mem.stylus_dy);

                //checks to see if we need to disengage hold and for detecting swipe
                int distSqr = (xmove*xmove) + (ymove*ymove);
                int holdThresholdSqr = mt->options.min_hold_dist_stylus * mt->options.min_hold_dist_stylus;

                if(distSqr > holdThresholdSqr){
                    mt->ge_state.stylusCanHold = FALSE;
                }

                if(mt->hs.stylus_data.swipe_sent == 0){
                    //ensure hold isn't sent yet to avoid race conditions. very rare
                    if(mt->ge_state.isStylusHoldEventSent == FALSE)
                    {
                        int swipeThresholdSqr = mt->options.min_swipe_stylus * mt->options.min_swipe_stylus;
                        if(distSqr > swipeThresholdSqr)
                        {
                            if (calculate_angle(mt) == 0) {
                                mt->hs.stylus_data.swipe_sent = stylus_scroll(local, compass[mt->orientation][0]+1, compass[mt->orientation][1]+1, (ymove >= 0) );
                            }
                            else {
                                mt->hs.stylus_data.swipe_sent = stylus_scroll(local, compass[mt->orientation][2]+1, compass[mt->orientation][3]+1, (xmove >= 0) );
                            }
                            mt->ge_state.stylusCanHold = FALSE;
                            DEBUG_INFO(DEBUG_LLOG_PERF,"Swipe detected in stylus, cancelling hold");
                        }
                    }

                }
            }
        }
        else
        {
            DEBUG_INFO(DEBUG_LLOG_PERF,"stylus gestures: hovering. on_display= %d swipe_event= %d tap_event= %d", mt->hs.stylus_data.on_display, mt->hs.stylus_data.swipe_sent, mt->hs.stylus_data.tap_sent);
            if(mt->hs.stylus_data.tap_sent == 1){
                postConvertedMotionXY(local, mt->mem.stylus_xup, mt->mem.stylus_yup);
                send_button_stylus(local, 1, 0);
                #ifdef STYLUS_DISTINCTION
                  send_button_stylus(local, STYLUS_SCREEN_TOUCH, BTN_STATE_UP);
                #endif
                mt->hs.stylus_data.tap_sent = 0;
                mt->ge_state.stylusCanHold = FALSE;
                mt->ge_state.isStylusHoldEventSent = FALSE;
                DEBUG_INFO(DEBUG_LLOG_PERF,"Button up in stylus, cancelling hold");
            }
            lastMotionX=-1;
            lastMotionY=-1;
        }
    DEBUG_INFO(DEBUG_X_FULL,"Leaving stylus gestures: on_display= %d swipe_event= %d tap_event= %d", mt->hs.stylus_data.on_display, mt->hs.stylus_data.swipe_sent, mt->hs.stylus_data.tap_sent);
}
/* called for each full received packet from the touchpad */
static void read_input(LocalDevicePtr local)
{
  struct Gestures gs;
  struct MTouch *mt = local->private;

  while (read_packet(mt, local->fd, TOUCH_INPUT) > 0) {
    pthread_mutex_lock(&ge_mutex);
    extract_gestures(&gs, mt);
    handle_gestures(local, &gs, &mt->caps);
    pthread_mutex_unlock(&ge_mutex);
  }
}

void *try_stylus_device_on(void * arg) {
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: try to turn on stylus device");
  LocalDevicePtr local = (LocalDevicePtr) arg;
  int i = 0;
  while(stylus_device_on(local) != Success && i < STYLUS_REPLUG_MAXIMUM_TRIES) {
    if(g_foreverReplugStylus == FALSE) {
      i++;
    }
    sleep(3);
  }
  if (i == STYLUS_REPLUG_MAXIMUM_TRIES) {
    DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: timeout in replug stylus device");
  } else {
    DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: stylus device turn on successfully again");
  }
  pthread_exit(NULL);
}

static void stylus_read_input(LocalDevicePtr local)
{
  struct Gestures gs;
  struct MTouch *mt = local->private;
  int ret;
DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: main about to read_packet");
  while ((ret = stylus_read_packet(mt, local->fd)) > 0) {
    pthread_mutex_lock(&ge_mutex);
    DEBUG_INFO(DEBUG_LLOG_PERF, "Multitouch main about to test gestures");
    stylus_gestures(local, mt);
    pthread_mutex_unlock(&ge_mutex);
  }
  if (ret == -ENODEV) {
    // The stylus device is closed after succussfully opened
    // So, we turn it off and try replug it
    DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: stylus device lost, try replug");
    stylus_device_off(local);
    pthread_attr_t attr;
    pthread_t thread;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&thread, &attr, &try_stylus_device_on, local);
    pthread_attr_destroy(&attr);
  }
DEBUG_INFO(DEBUG_LLOG_PERF, "Multitouch main finished read_packet");
}

static Bool device_control(DeviceIntPtr dev, int mode)
{
  LocalDevicePtr local = dev->public.devicePrivate;
  switch (mode) {
    case DEVICE_INIT:
      return device_init(dev, local);
    case DEVICE_ON:
      return device_on(local);
    case DEVICE_OFF:
      return device_off(local);
    case DEVICE_CLOSE:
      return device_close(local);
    default:
      return BadValue;
  }
}

static Bool stylus_device_control(DeviceIntPtr dev, int mode)
{
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: in device control");
  LocalDevicePtr local = dev->public.devicePrivate;
  switch (mode) {
    case DEVICE_INIT:
      return stylus_device_init(dev, local);
    case DEVICE_ON:
      return stylus_device_on(local);
    case DEVICE_OFF:
      return stylus_device_off(local);
    case DEVICE_CLOSE:
      return stylus_device_close(local);
    default:
      return BadValue;
  }
}

static void printOptions(MOptions *options)
{
  xf86Msg(X_INFO, "Option VScrollFrac : %f\n", options->vscroll_fraction);
  xf86Msg(X_INFO, "Option HScrollFrac : %f\n", options->hscroll_fraction);
  xf86Msg(X_INFO, "Option MinSwipe : %f\n", options->min_swipe);
  xf86Msg(X_INFO, "Option MinScale : %f\n", options->min_scale);
  xf86Msg(X_INFO, "Option RotFrac : %f\n", options->rot_fraction);
  xf86Msg(X_INFO, "Option HoldTime : %d\n", options->hold_time);
  xf86Msg(X_INFO, "Option MinHoldDist : %f\n", options->min_hold_dist);
  xf86Msg(X_INFO, "Option MinSuppressedTapTime : %d\n", options->suppressed_tap_time);
  xf86Msg(X_INFO, "Option MinSuppressedMove : %f\n", options->min_suppressed_move);
  xf86Msg(X_INFO, "Option VSwipeAngle : %d\n", options->vswipe_angle);
  xf86Msg(X_INFO, "Option Screenshot : %d\n", options->screenshot);
  xf86Msg(X_INFO, "Option size x mm: %f\n", options->size_x_mm);
  xf86Msg(X_INFO, "Option size y mm: %f\n", options->size_y_mm);
  xf86Msg(X_INFO, "Option GripSuppr : %d\n", options->grip_suppr);
  xf86Msg(X_INFO, "Option Keypad : %s\n", options->keypad);
  xf86Msg(X_INFO, "Option Debug : %d\n", options->debug);
}

/*
  The standard evdev format for storing axis values is an array with the following order:
  { "Value", "Min  ", "Max  ", "Fuzz ", "Flat " }
  This function gets the Max of the axis.
*/
static void findEMRResolution(InputInfoPtr local, struct MTouch *mt)
{
  int fd = open(mt->options.device, O_RDONLY);
  if((fd < 0) && (errno == EACCES) && (getuid() != 0)) {
      DEBUG_INFO(DEBUG_LLOG_PERF, "Could not open device file. ");
  }
    DEBUG_INFO(DEBUG_LLOG_PERF, "Device Input Values: %s", mt->options.device);
  int absX[6] = {};
  int absY[6] = {};
  ioctl(fd, EVIOCGABS(ABS_X), absX);
  ioctl(fd, EVIOCGABS(ABS_Y), absY);
  mt->options.wac_x_max = absX[2];
  mt->options.wac_y_max = absY[2];
  DEBUG_INFO(DEBUG_LLOG_PERF, "EMR Resolution Values: %d %d", mt->options.wac_x_max, mt->options.wac_y_max);
}

static InputInfoPtr preinit(InputDriverPtr drv, IDevPtr dev, int flags)
{
  DEBUG_INFO(DEBUG_LLOG_PERF, "Touch debug: fd preinit");
  struct MTouch *mt;
  InputInfoPtr local = xf86AllocateInput(drv, 0);
  if (!local)
    goto error;
  mt = xcalloc(1, sizeof(struct MTouch));
  if (!mt)
    goto error;

  local->name = dev->identifier;
  local->type_name = XI_TOUCHPAD;
  local->device_control = device_control;
  local->read_input = read_input;
  local->private = mt;
  local->flags = XI86_POINTER_CAPABLE | XI86_SEND_DRAG_EVENTS | XI86_KEYBOARD_CAPABLE;
  local->conf_idev = dev;

  if (pthread_mutex_init(&ge_mutex, NULL))
    goto error;

  mt->options.vscroll_fraction = xf86SetRealOption(dev->commonOptions,
      "VScrollFrac",
      DEF_VSCROLL_FRAC);
  mt->options.hscroll_fraction = xf86SetRealOption(dev->commonOptions,
      "HScrollFrac",
      DEF_HSCROLL_FRAC);
  mt->options.min_swipe = xf86SetRealOption(dev->commonOptions,
      "minSwipeMM",
      DEF_MIN_SWIPE_MM);
  mt->options.min_scale = xf86SetRealOption(dev->commonOptions,
      "minScaleMM",
      DEF_MIN_SCALE_MM);
  mt->options.suppressed_tap_time = xf86SetIntOption(dev->commonOptions,
      "minScaleMM",
      DEF_SUPPR_TAP_TIME_MS);
  mt->options.min_suppressed_move = xf86SetRealOption(dev->commonOptions,
      "minSupprMoveMM",
      DEF_MIN_SUPPR_MOVE_MM);
  mt->options.rot_fraction = xf86SetRealOption(dev->commonOptions,
      "RotateFrac",
      DEF_ROT_FRAC);
  mt->options.hold_time = xf86SetIntOption(dev->commonOptions,
      "HoldTime",
      DEF_HOLD_TIME_MS);
  mt->options.min_hold_dist = xf86SetRealOption(dev->commonOptions,
      "minHoldMM",
      DEF_MIN_HOLD_MM);
  mt->options.vswipe_angle = xf86SetIntOption(dev->commonOptions,
      "VSwipeAngle",
      DEF_VSWIPE_ANGLE);
  mt->options.size_x_mm = xf86SetRealOption(dev->commonOptions,
      "SizeXMM",
      DEF_SIZE_X_MM);
  mt->options.size_y_mm = xf86SetRealOption(dev->commonOptions,
      "SizeYMM",
      DEF_SIZE_Y_MM);
  mt->options.randr = xf86SetBoolOption(dev->commonOptions,
      "RandR",
      DEF_RANDR_OPT);
  mt->options.screenshot = xf86SetBoolOption(dev->commonOptions,
      "ScreenShot",
      DEF_SCREENSHOT_OPT);
  mt->options.grip_suppr = xf86SetBoolOption(dev->commonOptions,
      "GripSuppr",
      DEF_GRIPSUPPR_OPT);
  mt->options.multitouch = xf86SetBoolOption(dev->commonOptions,
      "multitouch",
      DEF_MULTITOUCH_OPT);
  mt->options.debug = xf86SetBoolOption(dev->commonOptions,
      "Debug",
      DEF_DEBUG_OPT);
  mt->options.keypad = xf86SetStrOption(dev->commonOptions,
      "Keypad",
      DEF_KEYPAD_OPT);
  mt->options.stylus = xf86SetStrOption(dev->commonOptions,
      "Stylus",
      DEF_STYLUS_OPT);
  printOptions(&mt->options);
  DEBUG_INFO(DEBUG_LLOG_PERF, "Touch debug: fd device set options");

  xf86CollectInputOptions(local, NULL, NULL);
  xf86ProcessCommonOptions(local, local->options);

  local->flags |= XI86_CONFIGURED;
error:
  return local;
}


static void uninit(InputDriverPtr drv, InputInfoPtr local, int flags)
{
  xfree(local->private);
  local->private = 0;
  xf86DeleteInput(local, 0);
  pthread_mutex_destroy(&ge_mutex);
}
static InputInfoPtr sylusPreinit(InputDriverPtr drv, IDevPtr dev, int flags)
{
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: in preinit");
  struct MTouch *mt;
  InputInfoPtr local = xf86AllocateInput(drv, 0);
  if (!local)
    goto error;
  mt = xcalloc(1, sizeof(struct MTouch));
  if (!mt)
    goto error;

  local->name = dev->identifier;
  local->type_name = XI_TOUCHPAD;
  local->device_control = stylus_device_control;
  local->read_input = stylus_read_input;
  local->private = mt;
  local->flags = XI86_POINTER_CAPABLE | XI86_SEND_DRAG_EVENTS | XI86_KEYBOARD_CAPABLE;
  local->conf_idev = dev;
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: set local values");

  if (pthread_mutex_init(&ge_mutex, NULL))
    goto error;

  mt->options.vscroll_fraction = xf86SetRealOption(dev->commonOptions,
      "VScrollFrac",
      DEF_VSCROLL_FRAC);
  mt->options.hscroll_fraction = xf86SetRealOption(dev->commonOptions,
      "HScrollFrac",
      DEF_HSCROLL_FRAC);
  mt->options.min_swipe = xf86SetRealOption(dev->commonOptions,
      "minSwipeMM",
      DEF_MIN_SWIPE_MM);
  mt->options.min_swipe_stylus = xf86SetRealOption(dev->commonOptions,
      "minSwipeStylus",
      DEF_MIN_STYLUS_SWIPE);
  mt->options.min_scale = xf86SetRealOption(dev->commonOptions,
      "minScaleMM",
      DEF_MIN_SCALE_MM);
  mt->options.suppressed_tap_time = xf86SetIntOption(dev->commonOptions,
      "minScaleMM",
      DEF_SUPPR_TAP_TIME_MS);
  mt->options.min_suppressed_move = xf86SetRealOption(dev->commonOptions,
      "minSupprMoveMM",
      DEF_MIN_SUPPR_MOVE_MM);
  mt->options.rot_fraction = xf86SetRealOption(dev->commonOptions,
      "RotateFrac",
      DEF_ROT_FRAC);
  mt->options.hold_time = xf86SetIntOption(dev->commonOptions,
      "HoldTime",
      DEF_HOLD_TIME_MS);
  mt->options.min_hold_dist_stylus = xf86SetIntOption(dev->commonOptions,
      "minStylusHold",
      DEF_MIN_STYLUS_HOLD);
  mt->options.min_hold_dist = xf86SetRealOption(dev->commonOptions,
      "minHoldMM",
      DEF_MIN_HOLD_MM);
  mt->options.vswipe_angle = xf86SetIntOption(dev->commonOptions,
      "VSwipeAngle",
      DEF_VSWIPE_ANGLE);
  mt->options.size_x_mm = xf86SetRealOption(dev->commonOptions,
      "SizeXMM",
      DEF_SIZE_X_MM);
  mt->options.size_y_mm = xf86SetRealOption(dev->commonOptions,
      "SizeYMM",
      DEF_SIZE_Y_MM);
  mt->options.res_x = xf86SetRealOption(dev->commonOptions,
      "ResX",
      DEF_RES_X);
  mt->options.res_y = xf86SetRealOption(dev->commonOptions,
      "ResY",
      DEF_RES_Y);
  mt->options.randr = xf86SetBoolOption(dev->commonOptions,
      "RandR",
      DEF_RANDR_OPT);
  mt->options.screenshot = xf86SetBoolOption(dev->commonOptions,
      "ScreenShot",
      DEF_SCREENSHOT_OPT);
  mt->options.grip_suppr = xf86SetBoolOption(dev->commonOptions,
      "GripSuppr",
      DEF_GRIPSUPPR_OPT);
  mt->options.debug = xf86SetBoolOption(dev->commonOptions,
      "Debug",
      DEF_DEBUG_OPT);
  mt->options.keypad = xf86SetStrOption(dev->commonOptions,
      "Keypad",
      DEF_KEYPAD_OPT);
  mt->options.stylus = xf86SetStrOption(dev->commonOptions,
      "Stylus",
      DEF_STYLUS_OPT);
  mt->options.device = xf86SetStrOption(dev->commonOptions,
      "Device",
      DEF_DEVICE_OPT);
  findEMRResolution(local, mt);
  printOptions(&mt->options);
  DEBUG_INFO(DEBUG_LLOG_PERF, "Stylus debug: device set options");

  xf86CollectInputOptions(local, NULL, NULL);
  xf86ProcessCommonOptions(local, local->options);

  local->flags |= XI86_CONFIGURED;
error:
  return local;
}

static void sylusUninit(InputDriverPtr drv, InputInfoPtr local, int flags)
{
  xfree(local->private);
  local->private = 0;
  xf86DeleteInput(local, 0);
  pthread_mutex_destroy(&ge_mutex);
}
static InputDriverRec MULTITOUCH = {
  1,
  "multitouch",
  NULL,
  preinit,
  uninit,
  NULL,
  0
};

static XF86ModuleVersionInfo VERSION = {
  "multitouch",
  MODULEVENDORSTRING,
  MODINFOSTRING1,
  MODINFOSTRING2,
  XORG_VERSION_CURRENT,
  0, 1, 0,
  ABI_CLASS_XINPUT,
  ABI_XINPUT_VERSION,
  MOD_CLASS_XINPUT,
  {0, 0, 0, 0}
};

static InputDriverRec STYLUS = {
  1,
  "stylus",
  NULL,
  sylusPreinit,
  sylusUninit,
  NULL,
  0
};

static pointer setup(pointer module, pointer options, int *errmaj, int *errmin)
{

  DEBUG_INFO(DEBUG_LLOG_PERF, "Touch debug: about to add input driver");
  xf86AddInputDriver(&MULTITOUCH, module, 0);
  xf86AddInputDriver(&STYLUS, module, 0);
  return module;
}

XF86ModuleData multitouchModuleData = {&VERSION, &setup, NULL };
