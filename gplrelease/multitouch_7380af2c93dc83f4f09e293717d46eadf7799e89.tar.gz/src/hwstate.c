/***************************************************************************
 *
 * Multitouch X driver
 * Copyright (C) 2008 Henrik Rydberg <rydberg@euromail.se>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 **************************************************************************/

#include "hwstate.h"
#include "gestures.h"
#include "log.h"
#include <pthread.h>
#include <sys/ioctl.h>
#include <linux/lab126_touch.h>
#include <linux/lab126_keypad.h>

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 3
#include <X11/Xatom.h>
#include <xserver-properties.h>
#include <multitouch-properties.h>
#define HAVE_PROPERTIES 1
#endif

static int enableTouchLogging = 0;

static void __attribute__ ((constructor)) initialize_multitouch(void) {
    struct stat statInfo;

    if (!stat("/var/local/ENABLE_TOUCH_PACKET_LOGGING", &statInfo)) {
        enableTouchLogging = 1;
    }

	if (!stat("/var/local/ENABLE_TOUCH_LOGGING", &statInfo)) {
        g_log_level = 0xFFFFFFFF;
    }
	
}

void init_hwstate(struct HWState *s, const struct Capabilities *caps)
{
	int i;
	memset(s, 0, sizeof(struct HWState));
	for (i = 0; i < DIM_FINGER; i++)
		s->data[i].tracking_id = caps->nullid;
}

static void finish_packet(struct HWState *s, const struct Capabilities *caps,
			  const struct input_event *syn)
{
	static const mstime_t ms = 1000;
	int i;
	foreach_bit(i, s->used) {
		if (!caps->has_abs[BIT_TOUCH_MINOR])
			s->data[i].touch_minor = s->data[i].touch_major;
		if (!caps->has_abs[BIT_WIDTH_MINOR])
			s->data[i].width_minor = s->data[i].width_major;
	}
	s->evtime = syn->time.tv_usec / ms + syn->time.tv_sec * ms;
}

int hwstate_read(struct HWState *s, const struct Capabilities *caps,
		 const struct input_event *ev)
{
	if (enableTouchLogging)
		syslog (6, "#####Multitouch type: %d, code %d, value %d", ev->type, ev->code, ev->value);

	switch (ev->type) {
	case EV_SYN:
		switch (ev->code) {
		case SYN_REPORT:
			finish_packet(s, caps, ev);
			return 1;
		}
		break;
	case EV_KEY:
		switch (ev->code) {
		case BTN_LEFT:
            syslog (6, "Multitouch hw_state BTN Left");
			MODBIT(s->button, MT_BUTTON_LEFT, ev->value);
			break;
    case BTN_TOOL_FINGER:
    syslog (6, "Multitouch hw_state Finger tool");
      MODBIT(s->button, MT_BUTTON_LEFT, ev->value);
      break;
    case BTN_MIDDLE:
			MODBIT(s->button, MT_BUTTON_MIDDLE, ev->value);
			break;
    case BTN_TOOL_DOUBLETAP:
      MODBIT(s->button, MT_BUTTON_MIDDLE, ev->value);
      break;
    /*case BTN_TOOL_TRIPLETAP:
      MODBIT(s->button, MT_BUTTON_RIGHT, ev->value);
      break;*/
		}
		break;
	case EV_ABS:
		switch (ev->code) {
		case ABS_MT_SLOT: //47
			if (ev->value >= 0 && ev->value < DIM_FINGER)
				s->slot = ev->value;
			break;
		case ABS_MT_TOUCH_MAJOR: //48
			s->data[s->slot].touch_major = ev->value;
			break;
		case ABS_MT_TOUCH_MINOR:  //49
			s->data[s->slot].touch_minor = ev->value;
			break;
		case ABS_MT_WIDTH_MAJOR:
			s->data[s->slot].width_major = ev->value;
			break;
		case ABS_MT_WIDTH_MINOR:
			s->data[s->slot].width_minor = ev->value;
			break;
		case ABS_MT_ORIENTATION:
			s->data[s->slot].orientation = ev->value;
			break;
		case ABS_MT_PRESSURE:
			s->data[s->slot].pressure = ev->value;
			break;
		case ABS_MT_POSITION_X:
			s->data[s->slot].position_x = ev->value;
			break;
		case ABS_MT_POSITION_Y:
			s->data[s->slot].position_y = ev->value;
			break;
		case ABS_MT_TRACKING_ID: //57
			s->data[s->slot].tracking_id = ev->value;
			MODBIT(s->used, s->slot,
			       ev->value != caps->nullid);

			//come out of PALM mode on receiving tracking id >= 0. JSIXTEEN-1088
			//the MT Firmware sends tool type change only when it uses a tracking id
			//if PALM was detected on slot 1 until it is using that slot for finger it wont send FINGER event
			if(ev->value >= 0 && g_MT_TOOL_TYPE!=MT_TOOL_FINGER)
			{
				g_MT_TOOL_TYPE=MT_TOOL_FINGER;
				syslog (6, "Multitouch switching back to FINGER mode");
			}

			break;

		case ABS_MT_TOOL_TYPE:
            g_MT_TOOL_TYPE=ev->value;
            break;

		}
		break;
	}
	return 0;
}

int stylus_hwstate_read(struct HWState *s, const struct Capabilities *caps,
		 const struct input_event *ev)
{

	if (enableTouchLogging)
		syslog (6, "##stylus: type %d, code %d, val %d", ev->type, ev->code, ev->value);

	switch (ev->type) {
	case EV_SYN:
		switch (ev->code) {
		case SYN_REPORT:
			finish_packet(s, caps, ev);
			return 1;
		}
		break;

	case EV_KEY:
		switch (ev->code) {
			case BTN_TOUCH: 
				s->stylus_data.on_display = ev->value;
				if (enableTouchLogging)
					syslog (6, "stylus on display, value: %d", ev->value);
				break;
			case BTN_TOOL_PEN:
			case BTN_TOOL_RUBBER:
				s->stylus_data.is_detected = ev->value;
				if(s->stylus_data.is_detected == 0){
					g_touch_suppression = TOUCH_SUPPR_OFF;
				}
				else {
					g_touch_suppression = TOUCH_SUPPR_ON;
				}
			}
			break;

	case EV_ABS:
	switch (ev->code) {
        	case ABS_X:
                	s->stylus_data.position_x = ev->value;
			break;
        	case ABS_Y: 
                	s->stylus_data.position_y = ev->value;
			break;
			//ToDo : handle 24 pressure and 25 distance events as required
		}
		break;
	}
	return 0;
}
