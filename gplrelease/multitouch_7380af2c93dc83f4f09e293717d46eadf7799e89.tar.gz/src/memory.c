/***************************************************************************
 *
 * Multitouch X driver
 * Copyright (C) 2008 Henrik Rydberg <rydberg@euromail.se>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 **************************************************************************/

#include "memory.h"
#include "mtouch.h"

#define use_tapping 1

/* click area definition */
#define CLICK_AREA(c) ((c->has_ibt ? 0.20 : 0.00) * get_cap_ysize(c))

#if defined(BELLATRIX) || defined(BELLATRIX4)
    /* Instead of treating  4% of x-axis pixels as grip suppression region in Bellatrix 
       it has been taken as 4.1% to match the grip suppression region
       with Stinger as Bellatrix's display is little smaller than Stinger
    */
    #define GRIP_AREA_X_LEFT(c) ((get_cap_xsize(c) * 0.041))
    #define GRIP_AREA_Y_TOP(c) ((get_cap_ysize(c) * 0.035))
#elif defined(BELLATRIX3)
    /*Barolo requires smaller grip suppression region as a % of screen
    TODO: As a general solution, convert grip suppression values to devcap
    */
    #define GRIP_AREA_X_LEFT(c) ((get_cap_xsize(c) * 0.027))
    #define GRIP_AREA_Y_TOP(c) ((get_cap_ysize(c) * 0.023))
#else
    #define GRIP_AREA_X_LEFT(c) ((get_cap_xsize(c) * 0.04))
    #define GRIP_AREA_Y_TOP(c) ((get_cap_ysize(c) * 0.035))
#endif

#define GRIP_AREA_X_RIGHT(c) ((get_cap_xsize(c) - GRIP_AREA_X_LEFT(c)))
#define GRIP_AREA_Y_BOTTOM(c) ((get_cap_ysize(c) - GRIP_AREA_Y_TOP(c)))

/* fraction of max movement threshold */
#define DELTA_CUT(x) (0.5 * (x))

/* fraction of tap movement threshold */
#define TAP_XMOVE(c) (0.02 * get_cap_xsize(c))
#define TAP_YMOVE(c) (0.02 * get_cap_ysize(c))

/* timer for cursor stability on finger touch/release */
static const int FINGER_ATTACK_MS = 0;
static const int FINGER_DECAY_MS  = 0;
static const int FINGER_CORNER_MS = 0;

/* tapping timings */
static const int TAP_SETTLE_MS = 0;
static const int TAP_TOUCH_MS  = 0;
static const int TAP_GAP_MS    = 0;
//static const int TAP_HOLD_MS   = 500;

static inline int dxval(const struct FingerState *a,
    const struct FingerState *b)
{
  return a->position_x - b->position_x;
}
static inline int dyval(const struct FingerState *a,
    const struct FingerState *b)
{
  return a->position_y - b->position_y;
}

static inline void relax_tapping(struct Memory *m, const struct MTState *state)
{
  m->tprelax = state->evtime + TAP_SETTLE_MS;
  m->wait = 0;
  m->ntap = 0;
}

static inline int unrelated_taps(const struct Memory *m,
    const struct Capabilities *caps)
{
  return abs(m->xdown - m->xup) > TAP_XMOVE(caps) ||
    abs(m->ydown - m->yup) > TAP_YMOVE(caps);
}

/**
 * init_memory
 */
void init_memory(struct Memory *mem)
{
  memset(mem, 0, sizeof(struct Memory));
  mem->stylus_xdown = -1;
  mem->stylus_ydown = -1;
  mem->stylus_dx = -1;
  mem->stylus_dy = -1;
  mem->stylus_xup = -1;
  mem->stylus_yup = -1;
}

/**
 * update_configuration
 *
 * Update the same, fingers, added, and thumb memory variables.
 *
 * Precondition: none
 *
 * Postcondition: same, fingers, added, thumb are set
 *
 */
static void update_configuration(struct Memory *m,
    const struct MTState *prev_state,
    const struct MTState *state)
{
  const struct FingerState *f = state->finger;
  bitmask_t fingers = BITONES(state->nfinger);
  int i;

  m->added = 0;
  // Add new fingers
  foreach_bit(i, fingers)
    if (!find_finger(prev_state, f[i].tracking_id))
    {
      SETBIT(m->added, i);
      m->touch_down[f[i].tracking_id] = state->evtime;
      m->down_pos[f[i].tracking_id].x = f[i].position_x;
      m->down_pos[f[i].tracking_id].y = f[i].position_y;
    }
  m->same = m->fingers == fingers && m->added == 0;
  m->fingers = fingers;

  m->active = 0;
  m->suppressed = 0;
  m->pointing = 0;
}

/**
 * update_pointers
 *
 * Update the pointing and ybar memory variables.
 *
 * Precondition: fingers, added, thumb are set
 *
 * Postcondition: pointing, ybar are set
 *
 */
static void update_pointers(struct Memory *m,
    const struct MTState *state,
    const struct Capabilities *caps,
    int grip_suppression)
{
  const struct FingerState *f = state->finger;
  int xleft   = GRIP_AREA_X_LEFT(caps);
  int xright  = GRIP_AREA_X_RIGHT(caps);
  int ytop    = GRIP_AREA_Y_TOP(caps);
  int ybottom = GRIP_AREA_Y_BOTTOM(caps);
  int i;

  if (state->nfinger <= 2) {
    foreach_bit(i, m->fingers) {

      if (!grip_suppression)
      {
        SETBIT(m->active, f[i].tracking_id);
        SETBIT(m->pointing, i);
        continue;
      }
      if (GETBIT(m->prev_active, f[i].tracking_id))
      {
        // If the finger was previously active, leave it that way
        SETBIT(m->active, f[i].tracking_id);
        SETBIT(m->pointing, i);
      }
      else if (f[i].position_x < xleft || f[i].position_x > xright ||
          f[i].position_y < ytop || f[i].position_y > ybottom)
      {
        // If not, suppress it
        SETBIT(m->suppressed, f[i].tracking_id);
      }
      else
      {
        SETBIT(m->active, f[i].tracking_id);
        SETBIT(m->pointing, i);
      }
    }
    return;
  }
}

/**
 * update_movement
 *
 * Update the pending, moving, mvhold, mvforget, dx and dy memory variables.
 *
 * When moving is nonzero, gestures can be extracted from the dx and dy
 * variables. These variables should be cleared after use.
 *
 * Precondition: fingers, added, thumb, pointing are set
 *
 * Postcondition: pending, moving, mvhold, mvforget, dx, dy are set
 *
 */
static void update_movement(struct Memory *m,
    const struct MTState *prev_state,
    const struct MTState *state,
    const struct Capabilities *caps)
{
  const struct FingerState *prev, *f = state->finger;
  int i, xcut, ycut, xmax = 0, ymax = 0;

  m->moving = 0;
  m->pending = 0;

  if (!m->same) {
    mstime_t d2, d2max = center_maxdist2(caps);
    mem_hold_movement(m, state->evtime + FINGER_ATTACK_MS);
    if (!m->added)
      mem_hold_movement(m, state->evtime + FINGER_DECAY_MS);
    foreach_bit(i, m->added) {
      d2 = center_dist2(&f[i], caps);
      d2 *= FINGER_CORNER_MS - FINGER_ATTACK_MS;
      d2 /= d2max;
      m->mvhold += d2;
    }
    memset(m->dx, 0, sizeof(m->dx));
    memset(m->dy, 0, sizeof(m->dy));
    return;
  }

  if (state->evtime < m->mvforget)
    return;

  foreach_bit(i, m->pointing) {
    int dx, dy;
    prev = find_finger(prev_state, f[i].tracking_id);
    dx = dxval(&f[i], prev);
    dy = dyval(&f[i], prev);
    m->dx[i] += dx;
    m->dy[i] += dy;
    xmax = maxval(xmax, abs(m->dx[i]));
    ymax = maxval(ymax, abs(m->dy[i]));
  }
  xcut = DELTA_CUT(xmax);
  ycut = DELTA_CUT(ymax);
  foreach_bit(i, m->pointing)
    if (abs(m->dx[i]) > xcut || abs(m->dy[i]) > ycut)
      SETBIT(m->pending, i);

  if (state->evtime < m->mvhold)
    return;

  m->moving = m->pending;
  if (bitcount(m->moving) > 0)
    m->ntap = 0;
}

/**
 * update_tapping
 *
 * Update tpdown, tpup, tprelax, wait, maxtap, ntap.
 *
 * Precondition: pointing and thumb are set
 *
 * Postcondition: tpdown, tpup, tprelax, wait, maxtap, ntap set
 *
 */
static void update_tapping(struct Memory *m,
    const struct MTState *prev_state,
    const struct MTState *state,
    const struct Capabilities *caps)
{
  int x, y, i, npoint = bitcount(m->pointing);
  int ptfound = 0;
  /* use a position independent on the number of fingers */

  if (state->nfinger) {
    for (i = 0; i < state->nfinger; i++) {
      if (GETBIT(m->suppressed, state->finger[i].tracking_id))
        continue;
      x = state->finger[i].position_x;
      y = state->finger[i].position_y;
    }

    for (i = 1; i < state->nfinger; i++) {
      if (GETBIT(m->suppressed, state->finger[i].tracking_id))
        continue;
      x = minval(x, state->finger[i].position_x);
      y = minval(y, state->finger[i].position_y);
    }
  }

  if (npoint && !bitcount(m->prev_active)) {
    m->tpdown = state->evtime;
    m->xdown = x;
    m->ydown = y;
    m->wait = 0;
    m->maxtap = npoint;
    m->xup = x;
    m->yup = y;
  }
  else if (npoint) {
    m->xup   = x;
    m->yup   = y;
    m->maxtap = maxval(m->maxtap, npoint);
  }
}

void refresh_memory(struct Memory *m,
    const struct MTState *prev_state,
    const struct MTState *state,
    const struct Capabilities *caps,
    int grip_suppression)
{
  update_configuration(m, prev_state, state);
  update_pointers(m, state, caps, grip_suppression);
  update_movement(m, prev_state, state, caps);
  if (use_tapping || !caps->has_left)
    update_tapping(m, prev_state, state, caps);
}

void refresh_stylus_memory(struct Memory *m, const struct HWState *hs, MOptions *options) {

    if(hs->stylus_data.on_display)
    {
        if(m->stylus_xdown == -1)
        {
            m->stylus_xdown = (hs->stylus_data.position_x*options->res_x)/options->wac_x_max;
            m->stylus_ydown = (hs->stylus_data.position_y*options->res_y)/options->wac_y_max;
        }
        else{
            m->stylus_dx = (hs->stylus_data.position_x*options->res_x)/options->wac_x_max;
            m->stylus_dy = (hs->stylus_data.position_y*options->res_y)/options->wac_y_max;
        }
    }
    else
    {
        m->stylus_xup = (hs->stylus_data.position_x*options->res_x)/options->wac_x_max;
        m->stylus_yup = (hs->stylus_data.position_y*options->res_y)/options->wac_y_max;
        m->stylus_xdown = -1;
	m->stylus_ydown = -1; //can be removed for performance as it is unused in decision making logic
        m->stylus_dx = -1;
      	m->stylus_dy = -1; ////can be removed for performance as it is unused in decision making logic
    }

    return;
}

void finalize_memory(struct Memory *m)
{
  m->prev_active = m->active;
  m->prev_suppressed = m->suppressed;
  m->prev_fingers = m->fingers;
}

void output_memory(const struct Memory *m)
{
  int i;
  xf86Msg(X_INFO, "btdata: %04x\n", m->btdata);
  xf86Msg(X_INFO, "fingers: %04x\n", m->fingers);
  xf86Msg(X_INFO, "added: %04x\n", m->added);
  xf86Msg(X_INFO, "pointing: %04x\n", m->pointing);
  xf86Msg(X_INFO, "pending: %04x\n", m->pending);
  xf86Msg(X_INFO, "moving: %04x\n", m->moving);
  xf86Msg(X_INFO, "ybar: %d\n", m->ybar);
}

void output_stylus_memory(const struct Memory *m)
{
  int i;
  xf86Msg(X_INFO, "x_down: %d\n", m->stylus_xdown);
  xf86Msg(X_INFO, "y_down: %d\n", m->stylus_ydown);
  xf86Msg(X_INFO, "dx: %d\n", m->stylus_dx);
  xf86Msg(X_INFO, "dy: %d\n", m->stylus_dy);
}
