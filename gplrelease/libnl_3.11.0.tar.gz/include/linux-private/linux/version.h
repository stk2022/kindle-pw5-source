#define LINUX_VERSION_CODE 394240
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + ((c) > 255 ? 255 : (c)))
#define LINUX_VERSION_MAJOR 6
#define LINUX_VERSION_PATCHLEVEL 4
#define LINUX_VERSION_SUBLEVEL 0
