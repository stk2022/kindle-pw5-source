/*
 * bootchartd_lib.c
 *
 * Copyright (c) 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifdef LAB126
#include <time.h>
#include "bootchartd_lib.h"

static long long timespec_to_usec_ll(struct timespec *ts)
{
    return (long long)ts->tv_sec * 1000 * 1000 + ts->tv_nsec / 1000;
}

/**
 * Bootchart's legacy time domain is boot-relative, as read either from /proc/uptime or
 * clock_gettime(CLOCK_MONOTONIC_RAW) -- ignoring precision issues for the moment.
 *
 * System log messages OTOH are typically stamped with UTC, in some format.
 *
 * The bootchart viewer would like to be able to present data carrying either kind
 * of timestamp on the common timeline.  Make this possible by providing a high-precision
 * representation of system boot time in the UTC domain -- represented here by
 * a 64-bit microsecond counter based at the "Unix epoch" of 12:00 midnight 1 Jan 1970.
 */
long long boot_time_as_usecs_since_epoch(void)
{
    const int LOOPS = 3;
    struct timespec ts_CLOCK_REALTIME[LOOPS];
    struct timespec ts_CLOCK_MONOTONIC_RAW[LOOPS];
    long long ll_CLOCK_MONOTONIC_RAW_mean;
    int i;

    /*
     * first LOOPS-2 iterations merely prime caches -- values returned are discarded
     */
    for (i=0; i<LOOPS; i++) {
        clock_gettime(CLOCK_REALTIME, &ts_CLOCK_REALTIME[i]);
        clock_gettime(CLOCK_MONOTONIC_RAW, &ts_CLOCK_MONOTONIC_RAW[i]);
    }

    /*
     * If calling clock_gettime() for either kind of clock takes exactly
     * the same time, then the timestamp of ts_CLOCK_MONOTONIC_RAW_mean
     * will exactly coincide with ts_CLOCK_REALTIME[2].  Otherwise, it won't ;-)
     */
    ll_CLOCK_MONOTONIC_RAW_mean = (
	timespec_to_usec_ll( &ts_CLOCK_MONOTONIC_RAW[LOOPS-2]) +
	timespec_to_usec_ll( &ts_CLOCK_MONOTONIC_RAW[LOOPS-1])) / 2;

    return timespec_to_usec_ll(&ts_CLOCK_REALTIME[2]) -	ll_CLOCK_MONOTONIC_RAW_mean;
}
#endif /* LAB126 */