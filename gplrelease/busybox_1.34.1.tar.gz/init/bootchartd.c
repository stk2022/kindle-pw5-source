/* vi: set sw=4 ts=4: */
/*
 * Licensed under GPLv2 or later, see file LICENSE in this source tree.
 */
//config:config BOOTCHARTD
//config:	bool "bootchartd (10 kb)"
//config:	default y
//config:	help
//config:	bootchartd is commonly used to profile the boot process
//config:	for the purpose of speeding it up. In this case, it is started
//config:	by the kernel as the init process. This is configured by adding
//config:	the init=/sbin/bootchartd option to the kernel command line.
//config:
//config:	It can also be used to monitor the resource usage of a specific
//config:	application or the running system in general. In this case,
//config:	bootchartd is started interactively by running bootchartd start
//config:	and stopped using bootchartd stop.
//config:
//config:config FEATURE_BOOTCHARTD_BLOATED_HEADER
//config:	bool "Compatible, bloated header"
//config:	default y
//config:	depends on BOOTCHARTD
//config:	help
//config:	Create extended header file compatible with "big" bootchartd.
//config:	"Big" bootchartd is a shell script and it dumps some
//config:	"convenient" info into the header, such as:
//config:		title = Boot chart for `hostname` (`date`)
//config:		system.uname = `uname -srvm`
//config:		system.release = `cat /etc/DISTRO-release`
//config:		system.cpu = `grep '^model name' /proc/cpuinfo | head -1` ($cpucount)
//config:		system.kernel.options = `cat /proc/cmdline`
//config:	This data is not mandatory for bootchart graph generation,
//config:	and is considered bloat. Nevertheless, this option
//config:	makes bootchartd applet to dump a subset of it.
//config:
//config:config FEATURE_BOOTCHARTD_CONFIG_FILE
//config:	bool "Support bootchartd.conf"
//config:	default y
//config:	depends on BOOTCHARTD
//config:	help
//config:	Enable reading and parsing of $PWD/bootchartd.conf
//config:	and /etc/bootchartd.conf files.

//applet:IF_BOOTCHARTD(APPLET(bootchartd, BB_DIR_SBIN, BB_SUID_DROP))

//kbuild:lib-$(CONFIG_BOOTCHARTD) += bootchartd.o

#include "libbb.h"
#include "common_bufsiz.h"
/* After libbb.h, since it needs sys/types.h on some systems */
#include <sys/utsname.h>

#ifdef __linux__
# include <sys/mount.h>
# ifndef MS_SILENT
#  define MS_SILENT      (1 << 15)
# endif
# ifndef MNT_DETACH
#  define MNT_DETACH 0x00000002
# endif
#endif

#if !ENABLE_TAR && !ENABLE_WERROR
# warning Note: bootchartd requires tar command, but you did not select it.
#elif !ENABLE_FEATURE_SEAMLESS_GZ && !ENABLE_WERROR
# warning Note: bootchartd requires tar -z support, but you did not select it.
#endif

#ifdef LAB126
#include "bootchartd_lib.h"

#define BC_VERSION_STR "0.8"__TIMESTAMP__
#else /* LAB126 */
#define BC_VERSION_STR "0.8"
#endif /* LAB126 */


/* For debugging, set to 0:
 * strace won't work with DO_SIGNAL_SYNC set to 1.
 */
#define DO_SIGNAL_SYNC 1


//$PWD/bootchartd.conf and /etc/bootchartd.conf:
//supported options:
//# Sampling period (in seconds)
//SAMPLE_PERIOD=0.2
//
//not yet supported:
//# tmpfs size
//# (32 MB should suffice for ~20 minutes worth of log data, but YMMV)
//TMPFS_SIZE=32m
//
//# Whether to enable and store BSD process accounting information.  The
//# kernel needs to be configured to enable v3 accounting
//# (CONFIG_BSD_PROCESS_ACCT_V3). accton from the GNU accounting utilities
//# is also required.
//PROCESS_ACCOUNTING="no"
//
//# Tarball for the various boot log files
//BOOTLOG_DEST=/var/log/bootchart.tgz
//
//# Whether to automatically stop logging as the boot process completes.
//# The logger will look for known processes that indicate bootup completion
//# at a specific runlevel (e.g. gdm-binary, mingetty, etc.).
//AUTO_STOP_LOGGER="yes"
//
//# Whether to automatically generate the boot chart once the boot logger
//# completes.  The boot chart will be generated in $AUTO_RENDER_DIR.
//# Note that the bootchart package must be installed.
//AUTO_RENDER="no"
//
//# Image format to use for the auto-generated boot chart
//# (choose between png, svg and eps).
//AUTO_RENDER_FORMAT="png"
//
//# Output directory for auto-generated boot charts
//AUTO_RENDER_DIR="/var/log"


/* Globals */
struct globals {
	char jiffy_line[COMMON_BUFSIZE];
} FIX_ALIASING;
#define G (*(struct globals*)bb_common_bufsiz1)
#define INIT_G() do { setup_common_bufsiz(); } while (0)

static void dump_file(FILE *fp, const char *filename)
{
	int fd = open(filename, O_RDONLY);
	if (fd >= 0) {
		fputs(G.jiffy_line, fp);
		fflush(fp);
		bb_copyfd_eof(fd, fileno(fp));
		close(fd);
		fputc('\n', fp);
	}
}

#ifdef LAB126
enum {
	STAT_pid =                                                   1,
	STAT_name_of_the_thread = 				     2,
	STAT_state = 						     3,
	STAT_ppid = 						     4,
	STAT_pgrp = 						     5,
	STAT_session = 						     6,
	STAT_tty_nr = 						     7,
	STAT_tpgid = 						     8,
	STAT_flags = 						     9,
	STAT_minflt = 						     10,
	STAT_cminflt = 						     11,
	STAT_majflt = 						     12,
	STAT_cmajflt = 						     13,
	STAT_utime = 						     14,
	STAT_stime = 						     15,
	STAT_cutime = 						     16,
	STAT_cstime = 						     17,
	STAT_priority = 					     18,
	STAT_nice = 						     19,
	STAT_num_threads = 					     20,
	STAT_itrealvalue = 					     21,
	STAT_time_in_jiffies_the_process_started_after_system_boot = 22,
	STAT_virtual_size = 					     23,
	STAT_RSS = 						     24,
	STAT_current_limit_in_bytes_on_the_rss_of_the_process =	     25,
	STAT_startcode = 					     26,
	STAT_endcode = 						     27,
	STAT_address_of_the_start_of_the_stack = 		     28,
	STAT_current_value_of_stack_pointer = 			     29,
	STAT_current_EIP_instruction_pointer = 			     30,
	STAT_bitmap_of_pending_signals = 			     31,
	STAT_bitmap_of_blocked_signals = 			     32,
	STAT_bitmap_of_ignored_signals = 			     33,
	STAT_bitmap_of_caught_signals = 			     34,
	STAT_wchan = 						     35,
	STAT_nswap = 						     36,
	STAT_cnswap = 						     37,
	STAT_exit_signal = 					     38,
	STAT_CPU_number_last_executed_on = 			     39,
	STAT_real_time__scheduling_priority = 			     40,
	STAT_scheduling_policy = 				     41,
	STAT_delayacct_blkio_ticks = 				     42,
	STAT_guest_time = 					     43,
	STAT_cguest_time = 					     44,
};

static const long long field_subset =
	(0LL << STAT_pid) |
	(0LL << STAT_name_of_the_thread) |
	(1LL << STAT_state) |
	(1LL << STAT_ppid) |
	(0LL << STAT_pgrp) |
	(0LL << STAT_session) |
	(0LL << STAT_tty_nr) |
	(0LL << STAT_tpgid) |
	(1LL << STAT_flags) |
	(0LL << STAT_minflt) |
	(0LL << STAT_cminflt) |
	(1LL << STAT_majflt) |
	(0LL << STAT_cmajflt) |
	(1LL << STAT_utime) |
	(1LL << STAT_stime) |
	(1LL << STAT_cutime) |
	(1LL << STAT_cstime) |
	(1LL << STAT_priority) |
	(1LL << STAT_nice) |
	(0LL << STAT_num_threads) |
	(0LL << STAT_itrealvalue) |
	(1LL << STAT_time_in_jiffies_the_process_started_after_system_boot) |
	(0LL << STAT_virtual_size) |
	(0LL << STAT_RSS) |
	(0LL << STAT_current_limit_in_bytes_on_the_rss_of_the_process) |
	(0LL << STAT_startcode) |
	(0LL << STAT_endcode) |
	(0LL << STAT_address_of_the_start_of_the_stack) |
	(0LL << STAT_current_value_of_stack_pointer) |
	(1LL << STAT_current_EIP_instruction_pointer) |
	(0LL << STAT_bitmap_of_pending_signals) |
	(0LL << STAT_bitmap_of_blocked_signals) |
	(0LL << STAT_bitmap_of_ignored_signals) |
	(0LL << STAT_bitmap_of_caught_signals) |
	(1LL << STAT_wchan) |
	(0LL << STAT_nswap) |
	(0LL << STAT_cnswap) |
	(0LL << STAT_exit_signal) |
	(0LL << STAT_CPU_number_last_executed_on) |
	(0LL << STAT_real_time__scheduling_priority) |
	(1LL << STAT_scheduling_policy) |
	(0LL << STAT_delayacct_blkio_ticks) |
	(0LL << STAT_guest_time) |
	(0LL << STAT_cguest_time)
;

static void parse_stat_line(FILE *fp, int pid, int tid, char *name, long long dump_fields)
{
	char *comm, *p;
	char stat_line[4*1024];
	int rd;
	int stat_fd = open(name, O_RDONLY);
	long long bits;

	if (stat_fd < 0)
		return;

	rd = safe_read(stat_fd, stat_line, sizeof(stat_line)-2);

	close(stat_fd);
	if (rd < 0)
		return;

	// find "comm" on the line
	comm = index(stat_line,'(');
	p = index(comm,')') + 1;
	*p = '\0';

	fprintf(fp, "%d %d %s", pid, tid, comm);

	p += 1; // points to "state" field

	for (bits = dump_fields>>STAT_state; bits != 0; bits >>= 1) {
		char *p1 = index(p,' ');
		if (bits&0x1) {
			fputc(' ', fp);
			*p1 = '\0';  // trust there's exactly one space, except for the last, but it's never reached
			fputs(p, fp);
		}
		p = p1 + 1;
	}
        fputc('\n', fp);

	// stat_line[rd] = '\0';
	// p = strchrnul(stat_line, '\n');
	// *p++ = '\n';
	// *p = '\0';
	// fputs(stat_line, fp);
}

static int dump_procs(FILE *fp, int dump_threads, long long dump_fields)
{
	struct dirent *proc_entry;
	DIR *proc_dir = opendir("/proc");

	fputs(G.jiffy_line, fp);
	while ((proc_entry = readdir(proc_dir)) != NULL) {
		unsigned pid;
		if (proc_entry->d_name[0] < '0' || proc_entry->d_name[0] > '9')
			continue;

		pid = bb_strtou(proc_entry->d_name, NULL, 10);
		if (errno)
			exit(3);

		if (dump_threads)
		{
			char task_dir_name[sizeof("/proc/123456789/taskXX")];
			DIR *task_dir;
			struct dirent *task_entry;

			snprintf(task_dir_name, sizeof(task_dir_name), "/proc/%u/task", pid);
			task_dir = opendir(task_dir_name);
			if (task_dir == NULL)
				//  XX  readdir(NULL) seen to seg-fault -- why is this not noted in the man page?
				continue;
			while ((task_entry = readdir(task_dir)) != NULL) {
				char task_name[sizeof("/proc/123456789/task/123456789/statXXXX")];
				unsigned tid = bb_strtou(task_entry->d_name, NULL, 10);
				snprintf(task_name, sizeof(task_name), "/proc/%u/task/%u/stat", pid, tid);
				parse_stat_line(fp, pid, tid, task_name, dump_fields);
			}
			closedir(task_dir);
		}
		else
		{
			char task_name[sizeof("/proc/123456789/statXXXX")];
			snprintf(task_name, sizeof(task_name), "/proc/%u/stat", pid);
			parse_stat_line(fp, pid, pid, task_name, dump_fields);
		}
	}
	closedir(proc_dir);
	fputc('\n', fp);
	return 0;
}
#else /* LAB126 */
static int dump_procs(FILE *fp, int look_for_login_process)
{
	struct dirent *entry;
	DIR *dir = opendir("/proc");
	int found_login_process = 0;

	fputs(G.jiffy_line, fp);
	while ((entry = readdir(dir)) != NULL) {
		char name[sizeof("/proc/%u/cmdline") + sizeof(int)*3];
		int stat_fd;
		unsigned pid = bb_strtou(entry->d_name, NULL, 10);
		if (errno)
			continue;

		/* Android's version reads /proc/PID/cmdline and extracts
		 * non-truncated process name. Do we want to do that? */

		sprintf(name, "/proc/%u/stat", pid);
		stat_fd = open(name, O_RDONLY);
		if (stat_fd >= 0) {
			char *p;
			char stat_line[4*1024];
			int rd = safe_read(stat_fd, stat_line, sizeof(stat_line)-2);

			close(stat_fd);
			if (rd < 0)
				continue;
			stat_line[rd] = '\0';
			p = strchrnul(stat_line, '\n');
			*p++ = '\n';
			*p = '\0';
			fputs(stat_line, fp);
			if (!look_for_login_process)
				continue;
			p = strchr(stat_line, '(');
			if (!p)
				continue;
			p++;
			strchrnul(p, ')')[0] = '\0';
			/* Is it gdm, kdm or a getty? */
			if (((p[0] == 'g' || p[0] == 'k' || p[0] == 'x')
			     && p[1] == 'd' && p[2] == 'm' && p[3] == '\0'
			    )
			 || strstr(p, "getty")
			) {
				found_login_process = 1;
			}
		}
	}
	closedir(dir);
	fputc('\n', fp);
	return found_login_process;
}
#endif /* LAB126 */

static char *make_tempdir(void)
{
	char template[] = "/tmp/bootchart.XXXXXX";
	char *tempdir = xstrdup(mkdtemp(template));
	if (!tempdir) {
#ifdef __linux__
		/* /tmp is not writable (happens when we are used as init).
		 * Try to mount a tmpfs, then cd and lazily unmount it.
		 * Since we unmount it at once, we can mount it anywhere.
		 * Try a few locations which are likely ti exist.
		 */
		static const char dirs[] ALIGN1 = "/mnt\0""/tmp\0""/boot\0""/proc\0";
		const char *try_dir = dirs;
		while (mount("none", try_dir, "tmpfs", MS_SILENT, "size=16m") != 0) {
			try_dir += strlen(try_dir) + 1;
			if (!try_dir[0])
				bb_perror_msg_and_die("can't %smount tmpfs", "");
		}
		//bb_error_msg("mounted tmpfs on %s", try_dir);
		xchdir(try_dir);
		if (umount2(try_dir, MNT_DETACH) != 0) {
			bb_perror_msg_and_die("can't %smount tmpfs", "un");
		}
#else
		bb_simple_perror_msg_and_die("can't create temporary directory");
#endif
	} else {
		xchdir(tempdir);
	}
	return tempdir;
}

#ifdef LAB126
static void do_logging(unsigned sample_period_us, int process_accounting, int dump_threads, long long dump_fields)
{
    const char *proc_ps_threads_name = "proc_ps_threads.log";
    const char *proc_ps_name = "proc_ps_compact.log";
	FILE *proc_stat = xfopen_for_write("proc_stat.log");
	FILE *proc_diskstats = xfopen_for_write("proc_diskstats.log");
	//FILE *proc_netdev = xfopen_for_write("proc_netdev.log");
	FILE *proc_ps = xfopen_for_write(proc_ps_name);
	FILE *proc_ps_threads;
	int look_for_login_process = (getppid() == 1);
	unsigned count = ~0;

	if (dump_threads)
	    proc_ps_threads = xfopen_for_write(proc_ps_threads_name);

	if (process_accounting) {
		close(xopen("kernel_pacct", O_WRONLY | O_CREAT | O_TRUNC));
		acct("kernel_pacct");
	}

	while (--count && !bb_got_signal) {
		char *p;
		int len = open_read_close("/proc/uptime", G.jiffy_line, sizeof(G.jiffy_line)-2);
		if (len < 0)
			goto wait_more;
		/* /proc/uptime has format "NNNNNN.MM NNNNNNN.MM" */
		/* we convert it to "NNNNNNMM\n" (using first value) */
		G.jiffy_line[len] = '\0';
		p = strchr(G.jiffy_line, '.');
		if (!p)
			goto wait_more;
		while (isdigit(*++p))
			p[-1] = *p;
		p[-1] = '\n';
		p[0] = '\0';

		dump_file(proc_stat, "/proc/stat");
		dump_file(proc_diskstats, "/proc/diskstats");
		//dump_file(proc_netdev, "/proc/net/dev");
		if (dump_procs(proc_ps, 0/*FALSE*/, dump_fields)) {
			/* dump_procs saw a getty or {g,k,x}dm
			 * stop logging in 2 seconds:
			 */
			if (count > 2*1000*1000 / sample_period_us)
				count = 2*1000*1000 / sample_period_us;
		}
		if (dump_threads)
		    dump_procs(proc_ps_threads, 1/*TRUE*/, dump_fields);
		fflush_all();
 wait_more:
		usleep(sample_period_us);
	}
}

#else /* LAB126 */
static void do_logging(unsigned sample_period_us, int process_accounting)
{
	FILE *proc_stat = xfopen_for_write("proc_stat.log");
	FILE *proc_diskstats = xfopen_for_write("proc_diskstats.log");
	//FILE *proc_netdev = xfopen_for_write("proc_netdev.log");
	FILE *proc_ps = xfopen_for_write("proc_ps.log");
	int look_for_login_process = (getppid() == 1);
	unsigned count = 60*1000*1000 / sample_period_us; /* ~1 minute */

	if (process_accounting) {
		close(xopen("kernel_pacct", O_WRONLY | O_CREAT | O_TRUNC));
		acct("kernel_pacct");
	}

	while (--count && !bb_got_signal) {
		char *p;
		int len = open_read_close("/proc/uptime", G.jiffy_line, sizeof(G.jiffy_line)-2);
		if (len < 0)
			goto wait_more;
		/* /proc/uptime has format "NNNNNN.MM NNNNNNN.MM" */
		/* we convert it to "NNNNNNMM\n" (using first value) */
		G.jiffy_line[len] = '\0';
		p = strchr(G.jiffy_line, '.');
		if (!p)
			goto wait_more;
		while (isdigit(*++p))
			p[-1] = *p;
		p[-1] = '\n';
		p[0] = '\0';

		dump_file(proc_stat, "/proc/stat");
		dump_file(proc_diskstats, "/proc/diskstats");
		//dump_file(proc_netdev, "/proc/net/dev");
		if (dump_procs(proc_ps, look_for_login_process)) {
			/* dump_procs saw a getty or {g,k,x}dm
			 * stop logging in 2 seconds:
			 */
			if (count > 2*1000*1000 / sample_period_us)
				count = 2*1000*1000 / sample_period_us;
		}
		fflush_all();
 wait_more:
		usleep(sample_period_us);
	}
}
#endif /* LAB126 */



static void finalize(char *tempdir, const char *prog, int process_accounting)
{
	//# Stop process accounting if configured
	//local pacct=
	//[ -e kernel_pacct ] && pacct=kernel_pacct

	FILE *header_fp = xfopen_for_write("header");

	if (process_accounting)
		acct(NULL);

	if (prog)
		fprintf(header_fp, "profile.process = %s\n", prog);

	fputs("version = "BC_VERSION_STR"\n", header_fp);
	if (ENABLE_FEATURE_BOOTCHARTD_BLOATED_HEADER) {
		char *hostname;
		char *kcmdline;
		time_t t;
		struct tm tm_time;
		/* x2 for possible localized weekday/month names */
		char date_buf[sizeof("Mon Jun 21 05:29:03 CEST 2010") * 2];
		struct utsname unamebuf;

		hostname = safe_gethostname();
		time(&t);
		localtime_r(&t, &tm_time);
		strftime(date_buf, sizeof(date_buf), "%a %b %e %H:%M:%S %Z %Y", &tm_time);
		fprintf(header_fp, "title = Boot chart for %s (%s)\n", hostname, date_buf);
		if (ENABLE_FEATURE_CLEAN_UP)
			free(hostname);

		uname(&unamebuf); /* never fails */
		/* same as uname -srvm */
		fprintf(header_fp, "system.uname = %s %s %s %s\n",
				unamebuf.sysname,
				unamebuf.release,
				unamebuf.version,
				unamebuf.machine
		);

		//system.release = `cat /etc/DISTRO-release`
		//system.cpu = `grep '^model name' /proc/cpuinfo | head -1` ($cpucount)

		kcmdline = xmalloc_open_read_close("/proc/cmdline", NULL);
		/* kcmdline includes trailing "\n" */
		fprintf(header_fp, "system.kernel.options = %s", kcmdline);
		if (ENABLE_FEATURE_CLEAN_UP)
			free(kcmdline);
	}
	#ifdef LAB126
	fprintf(header_fp, "boot_time_as_usecs_since_epoch = %lld\n", boot_time_as_usecs_since_epoch());
	#endif /* LAB126 */

	fclose(header_fp);

	/* Package log files */
	#ifdef LAB126
	system(xasprintf("tar -zcf /var/log/bootchart.tgz header %s *.log", process_accounting ? "kernel_pacct" : ""));
	#else
	system(xasprintf("tar -zcf /var/log/bootlog.tgz header %s *.log", process_accounting ? "kernel_pacct" : ""));
	#endif /* LAB126 */

	/* Clean up (if we are not in detached tmpfs) */
	if (tempdir) {
		unlink("header");
		unlink("proc_stat.log");
		unlink("proc_diskstats.log");
		//unlink("proc_netdev.log");
		unlink("proc_ps.log");
		#ifdef LAB126
		unlink("proc_ps_thread.log");
		#endif /* LAB126 */
		if (process_accounting)
			unlink("kernel_pacct");
		rmdir(tempdir);
	}

	/* shell-based bootchartd tries to run /usr/bin/bootchart if $AUTO_RENDER=yes:
	 * /usr/bin/bootchart -o "$AUTO_RENDER_DIR" -f $AUTO_RENDER_FORMAT "$BOOTLOG_DEST"
	 */
}

//usage:#define bootchartd_trivial_usage
//usage:       "start [PROG ARGS]|stop|init"
//usage:#define bootchartd_full_usage "\n\n"
//usage:       "Create /var/log/bootchart.tgz with boot chart data\n"
#ifdef LAB126
//usage:     "\nOptions:"
//usage:     "\n-p sample_period: units of seconds, decimal fractions permitted"
//usage:     "\ninit: start background logging; stop when getty/xdm or USR1 is seen (for init scripts)"
#else /* LAB126 */
//usage:     "\ninit: start background logging; stop when getty/xdm is seen (for init scripts)"
#endif /* LAB126 */
//usage:     "\nstart: start background logging; with PROG, run PROG, then kill logging with USR1"
//usage:     "\nstop: send USR1 to all bootchartd processes"
//usage:     "\nUnder PID 1: as init, then exec $bootchart_init, /init, /sbin/init"

int bootchartd_main(int argc, char **argv) MAIN_EXTERNALLY_VISIBLE;
int bootchartd_main(int argc UNUSED_PARAM, char **argv)
{
	unsigned sample_period_us;
	pid_t parent_pid, logger_pid;
	smallint cmd;
	int process_accounting;
	enum {
		CMD_STOP = 0,
		CMD_START,
		CMD_INIT,
		CMD_PID1, /* used to mark pid 1 case */
	};

	INIT_G();

	parent_pid = getpid();

	#ifdef LAB126
	int dump_threads = 0;
	long long dump_fields = (1ll << STAT_cguest_time)-1;
	sample_period_us = 200 * 1000;
	while (argv[1] && argv[1][0] == '-') {
		switch (argv[1][1]) {
		case 'p': {
			sample_period_us = atof(argv[2]) *1000*1000;
			argv+=1;
			break;
		}
		case 's': {
			dump_fields = field_subset;
			break;
		}
		case 't': {
			dump_threads = 1;
			break;
		}
		}
		argv+=1;
    }
    #endif /* LAB126 */

	if (argv[1]) {
		cmd = index_in_strings("stop\0""start\0""init\0", argv[1]);
		if (cmd < 0)
			bb_show_usage();
		if (cmd == CMD_STOP) {
			pid_t *pidList = find_pid_by_name("bootchartd");
			while (*pidList != 0) {
				if (*pidList != parent_pid)
					kill(*pidList, SIGUSR1);
				pidList++;
			}
			return EXIT_SUCCESS;
		}
	} else {
		if (parent_pid != 1)
			bb_show_usage();
		cmd = CMD_PID1;
	}

	/* Here we are in START, INIT or CMD_PID1 state */

	/* Read config file: */
	#ifndef LAB126
	sample_period_us = 200 * 1000;
	#endif /* LAB126 */
	process_accounting = 0;
	if (ENABLE_FEATURE_BOOTCHARTD_CONFIG_FILE) {
		char* token[2];
		parser_t *parser = config_open2("/etc/bootchartd.conf" + 5, fopen_for_read);
		if (!parser)
			parser = config_open2("/etc/bootchartd.conf", fopen_for_read);
		while (config_read(parser, token, 2, 0, "#=", PARSE_NORMAL & ~PARSE_COLLAPSE)) {
			if (strcmp(token[0], "SAMPLE_PERIOD") == 0 && token[1])
				sample_period_us = atof(token[1]) * 1000000;
			if (strcmp(token[0], "PROCESS_ACCOUNTING") == 0 && token[1]
			 && (strcmp(token[1], "on") == 0 || strcmp(token[1], "yes") == 0)
			) {
				process_accounting = 1;
			}
		}
		config_close(parser);
		if ((int)sample_period_us <= 0)
			sample_period_us = 1; /* prevent division by 0 */
	}

	/* Create logger child: */
	logger_pid = fork_or_rexec(argv);

	if (logger_pid == 0) { /* child */
		char *tempdir;

		bb_signals(0
			+ (1 << SIGUSR1)
			+ (1 << SIGUSR2)
			+ (1 << SIGTERM)
			+ (1 << SIGQUIT)
			+ (1 << SIGINT)
			+ (1 << SIGHUP)
			, record_signo);

		if (DO_SIGNAL_SYNC)
			/* Inform parent that we are ready */
			raise(SIGSTOP);

		/* If we are started by kernel, PATH might be unset.
		 * In order to find "tar", let's set some sane PATH:
		 */
		if (cmd == CMD_PID1 && !getenv("PATH"))
			putenv((char*)bb_PATH_root_path);

		tempdir = make_tempdir();
		#ifdef LAB126
		do_logging(sample_period_us, process_accounting, dump_threads, dump_fields);
		#else /* LAB126 */
		do_logging(sample_period_us, process_accounting);
		#endif /* LAB126 */
		finalize(tempdir, cmd == CMD_START ? argv[2] : NULL, process_accounting);
		return EXIT_SUCCESS;
	}

	/* parent */

	USE_FOR_NOMMU(argv[0][0] &= 0x7f); /* undo fork_or_rexec() damage */

	if (DO_SIGNAL_SYNC) {
		/* Wait for logger child to set handlers, then unpause it.
		 * Otherwise with short-lived PROG (e.g. "bootchartd start true")
		 * we might send SIGUSR1 before logger sets its handler.
		 */
		waitpid(logger_pid, NULL, WUNTRACED);
		kill(logger_pid, SIGCONT);
	}

	if (cmd == CMD_PID1) {
		char *bootchart_init = getenv("bootchart_init");
		if (bootchart_init)
			execl(bootchart_init, bootchart_init, NULL);
		execl("/init", "init", NULL);
		execl("/sbin/init", "init", NULL);
		bb_perror_msg_and_die("can't execute '%s'", "/sbin/init");
	}

	if (cmd == CMD_START && argv[2]) { /* "start PROG ARGS" */
		pid_t pid = xvfork();
		if (pid == 0) { /* child */
			argv += 2;
			BB_EXECVP_or_die(argv);
		}
		/* parent */
		waitpid(pid, NULL, 0);
		kill(logger_pid, SIGUSR1);
	}

	return EXIT_SUCCESS;
}
