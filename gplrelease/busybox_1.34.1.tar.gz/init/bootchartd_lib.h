/*
 * bootchartd_lib.h
 * ================
 *
 * Copyright (c) 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifdef LAB126
long long boot_time_as_usecs_since_epoch(void);
#endif /* LAB126 */
