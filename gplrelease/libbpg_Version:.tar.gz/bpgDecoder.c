/**
 * Simple decoder test program of bpg
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/stat.h>

#include <time.h>

#include "libbpg.h"

typedef struct {
    int         w;
    int         h;
    int         channel;
    uint8_t     *data;
} PNM;

#define ERROR_IF(c)     do { if((c)) { printf("Err on line %d\n", __LINE__); goto decodeDone; } } while(0)
static void bpgDecode(uint8_t *bpgBuf, size_t bpgBufSize, PNM *pPNM, int forceGray)
{
    int y, decodeOK = 0;
    BPGImageInfo imgInfo;
    BPGDecoderContext *bpgCtx = NULL;
    uint8_t *line;
    
    pPNM->data = NULL;

    bpgCtx = bpg_decoder_open();
    ERROR_IF(bpgCtx == NULL);
    
    ERROR_IF(0 > bpg_decoder_decode(bpgCtx, bpgBuf, bpgBufSize));
    
    ERROR_IF(0 > bpg_decoder_get_info(bpgCtx, &imgInfo));
    
    printf("Image: %d x %d [Format: %d] [alpha: %d]\n", imgInfo.width, imgInfo.height, imgInfo.format, imgInfo.has_alpha);
    
    pPNM->w = imgInfo.width;
    pPNM->h = imgInfo.height;
    pPNM->channel = (forceGray || imgInfo.format == BPG_FORMAT_GRAY)? 1 : 3;
    pPNM->data = (uint8_t *)malloc(pPNM->w * pPNM->h * pPNM->channel);
    ERROR_IF(pPNM->data == NULL);
    
    line = pPNM->data;
    bpg_decoder_start(bpgCtx, pPNM->channel == 1? BPG_OUTPUT_FORMAT_GRAY8 : BPG_OUTPUT_FORMAT_RGB24);
    for (y = 0; y < imgInfo.height; y++)
    {
        bpg_decoder_get_line(bpgCtx, line);
        line += pPNM->channel * pPNM->w;
    }
    
    decodeOK = 1;
    
decodeDone:
    if(!decodeOK && pPNM->data)
    {
        free(pPNM->data);
        pPNM->data = NULL;
    }
    
    if(bpgCtx)
        bpg_decoder_close(bpgCtx);
    
    return;
}

int main(int argc, char **argv)
{
    struct stat st;
    uint8_t *fileContent = NULL;
    size_t fileSize = 0;
    clock_t startClock, endClock;
    PNM PNMInfo = {0, 0, 0, NULL};
    
    if(argc < 2)
    {
        printf("Usage: %s INPUT.bpg [-gray: force grayscale]\n", argv[0]);
        return EXIT_FAILURE;
    }
    
    const char *file = argv[1];
    if(0 == stat(file, &st))
        fileSize = st.st_size;
    
    if(fileSize)
    {
        FILE *fp = fopen(file, "rb");
        if(fp)
        {
            fileContent = (uint8_t *)malloc(fileSize);
            fread(fileContent, 1, fileSize, fp);
            fclose(fp);
        } else
            printf("Can not open file: %s", file);
    }
    
    if(fileContent)
    {
        int forceGray = argc >= 3;
        startClock = clock();
        bpgDecode(fileContent, fileSize, &PNMInfo, forceGray);
        endClock = clock();
    
        printf("Spent: %d ms\n", (int)(1000 * (endClock - startClock)/CLOCKS_PER_SEC));
        
        if(PNMInfo.data)
        {
            FILE *fp = fopen(PNMInfo.channel == 1? "output.pgm" : "output.ppm", "w");
            if(fp)
            {
                fprintf(fp, "P%d\n%d %d\n255\n", PNMInfo.channel == 1? 5 : 6, PNMInfo.w, PNMInfo.h);
                fwrite(PNMInfo.data, 1, PNMInfo.w * PNMInfo.h * PNMInfo.channel, fp);
                fclose(fp);
            }
        }
        
        free(fileContent);
    }
    
    return EXIT_SUCCESS;
}
