
/* These are an dummy/empty implementation of all the libbpg APIs that we used */

#include "libbpg.h"

BPGDecoderContext *bpg_decoder_open(void) { return NULL; }
int bpg_decoder_decode(BPGDecoderContext *s, const uint8_t *buf, int buf_len) { return -1; }
int bpg_decoder_get_info(BPGDecoderContext *s, BPGImageInfo *p) { return -1; }
int bpg_decoder_start(BPGDecoderContext *s, BPGDecoderOutputFormat out_fmt) { return -1; }
int bpg_decoder_get_line(BPGDecoderContext *s, void *buf) { return -1; }
void bpg_decoder_close(BPGDecoderContext *s) {}

