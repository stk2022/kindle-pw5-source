
#ifndef _LIBBPG_H
#define _LIBBPG_H

#include <stdlib.h>
#include <stdint.h>

typedef void BPGDecoderContext;

typedef enum {
    BPG_FORMAT_GRAY,
    BPG_FORMAT_420, /* chroma at offset (0.5, 0.5) (JPEG) */
    BPG_FORMAT_422, /* chroma at offset (0.5, 0) (JPEG) */
    BPG_FORMAT_444,
    BPG_FORMAT_420_VIDEO, /* chroma at offset (0, 0.5) (MPEG2) */
    BPG_FORMAT_422_VIDEO, /* chroma at offset (0, 0) (MPEG2) */
} BPGImageFormatEnum;

typedef enum {
    BPG_OUTPUT_FORMAT_RGB24,
    BPG_OUTPUT_FORMAT_RGBA32, /* not premultiplied alpha */
    BPG_OUTPUT_FORMAT_RGB48,
    BPG_OUTPUT_FORMAT_RGBA64, /* not premultiplied alpha */
    BPG_OUTPUT_FORMAT_CMYK32,
    BPG_OUTPUT_FORMAT_CMYK64,
    BPG_OUTPUT_FORMAT_GRAY8,
} BPGDecoderOutputFormat;

typedef struct {
    uint32_t width;
    uint32_t height;
    uint8_t format; /* see BPGImageFormatEnum */
    uint8_t has_alpha; /* TRUE if an alpha plane is present */
    uint8_t color_space; /* see BPGColorSpaceEnum */
    uint8_t bit_depth;
    uint8_t premultiplied_alpha; /* TRUE if the color is alpha premultiplied */
    uint8_t has_w_plane; /* TRUE if a W plane is present (for CMYK encoding) */
    uint8_t limited_range; /* TRUE if limited range for the color */
    uint8_t has_animation; /* TRUE if the image contains animations */
    uint16_t loop_count; /* animations: number of loop, 0 = infinity */
} BPGImageInfo;

BPGDecoderContext *bpg_decoder_open(void);
int bpg_decoder_decode(BPGDecoderContext *s, const uint8_t *buf, int buf_len);
int bpg_decoder_get_info(BPGDecoderContext *s, BPGImageInfo *p);
int bpg_decoder_start(BPGDecoderContext *s, BPGDecoderOutputFormat out_fmt);
int bpg_decoder_get_line(BPGDecoderContext *s, void *buf);
void bpg_decoder_close(BPGDecoderContext *s);

#endif

