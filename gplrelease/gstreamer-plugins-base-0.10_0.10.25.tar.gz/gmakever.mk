# Return true if the version of make is at least 4.3 or greater

at_least=$(firstword $(sort $(MAKE_VERSION) 4.3))

ifneq ($(at_least),4.3)
err:
	@echo "$(MAKE_VERSION) is less than 4.3"
	@false
else
ok:
	@echo "$(MAKE_VERSION) "
endif
