/* ANSI-C code produced by gperf version 3.0.1 */
/* Command-line: gperf -LANSI-C -t -c -l -k1,3,5 -N find_macro  */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gnu-gperf@gnu.org>."
#endif


#include "macros.h"
struct macro_def { char *name; int id; int len; };

#define TOTAL_KEYWORDS 58
#define MIN_WORD_LENGTH 2
#define MAX_WORD_LENGTH 13
#define MIN_HASH_VALUE 3
#define MAX_HASH_VALUE 90
/* maximum key range = 88, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
hash (register const char *str, register unsigned int len)
{
  static unsigned char asso_values[] =
    {
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 25, 91, 15, 55,  0,
       0, 15, 30, 25, 91, 91,  5,  0,  0, 30,
      45, 91,  0,  5, 15, 10, 60,  0, 91,  5,
      91, 91, 91, 91, 91,  5, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91, 91, 91, 91, 91,
      91, 91, 91, 91, 91, 91
    };
  register int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[4]];
      /*FALLTHROUGH*/
      case 4:
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      /*FALLTHROUGH*/
      case 2:
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval;
}

#ifdef __GNUC__
__inline
#endif
static struct macro_def *
find_macro (register const char *str, register unsigned int len)
{
  static unsigned char lengthtable[] =
    {
       0,  0,  0,  3,  4,  5,  0,  7,  0,  9,  5,  0,  7,  0,
       9, 10,  0,  2,  3,  4, 10,  0,  7,  3,  4,  5,  0,  0,
       8,  0,  5,  0, 12,  3,  4,  5,  6,  7,  8,  4,  0,  6,
       0,  8,  4, 10,  6,  0, 13,  9, 10,  6,  0,  8,  0, 10,
       0,  0,  8,  0, 10,  0,  7,  3,  9,  5,  0,  0,  8,  9,
       5,  0,  0,  3,  4,  5,  6,  0,  8,  9,  0,  6,  7,  0,
       0,  0,  0,  7,  6,  0,  6
    };
  static struct macro_def wordlist[] =
    {
      {""}, {""}, {""},
      {"MIN", M_MIN, 3},
      {"MSEC", M_MSEC, 4},
      {"R_MIN", M_MIN_RECVD, 5},
      {""},
      {"R_MONTH", M_MONTH_RECVD, 7},
      {""},
      {"R_WEEKDAY", M_WEEKDAY_RECVD, 9},
      {"S_MIN", M_MIN_STAMP, 5},
      {""},
      {"S_MONTH", M_MONTH_STAMP, 7},
      {""},
      {"S_WEEKDAY", M_WEEKDAY_STAMP, 9},
      {"R_FULLDATE", M_FULLDATE_RECVD, 10},
      {""},
      {"TZ", M_TZ, 2},
      {"MSG", M_MESSAGE, 3},
      {"R_TZ", M_TZ_RECVD, 4},
      {"S_FULLDATE", M_FULLDATE_STAMP, 10},
      {""},
      {"MSGONLY", M_MSGONLY, 7},
      {"SEC", M_SEC, 3},
      {"S_TZ", M_TZ_STAMP, 4},
      {"R_SEC", M_SEC_RECVD, 5},
      {""}, {""},
      {"FACILITY", M_FACILITY, 8},
      {""},
      {"S_SEC", M_SEC_STAMP, 5},
      {""},
      {"FACILITY_NUM", M_FACILITY_NUM, 12},
      {"TAG", M_TAG, 3},
      {"YEAR", M_YEAR, 4},
      {"MONTH", M_MONTH, 5},
      {"R_YEAR", M_YEAR_RECVD, 6},
      {"MESSAGE", M_MESSAGE, 7},
      {"SOURCEIP", M_SOURCE_IP, 8},
      {"HOST", M_HOST, 4},
      {""},
      {"S_YEAR", M_YEAR_STAMP, 6},
      {""},
      {"FULLHOST", M_FULLHOST, 8},
      {"HOUR", M_HOUR, 4},
      {"R_UNIXTIME", M_UNIXTIME_RECVD, 10},
      {"R_HOUR", M_HOUR_RECVD, 6},
      {""},
      {"FULLHOST_FROM", M_FULLHOST_FROM, 13},
      {"HOST_FROM", M_HOST_FROM, 9},
      {"S_UNIXTIME", M_UNIXTIME_STAMP, 10},
      {"S_HOUR", M_HOUR_STAMP, 6},
      {""},
      {"TZOFFSET", M_TZOFFSET, 8},
      {""},
      {"R_TZOFFSET", M_TZOFFSET_RECVD, 10},
      {""}, {""},
      {"UNIXTIME", M_UNIXTIME, 8},
      {""},
      {"S_TZOFFSET", M_TZOFFSET_STAMP, 10},
      {""},
      {"WEEKDAY", M_WEEKDAY, 7},
      {"DAY", M_DAY, 3},
      {"R_ISODATE", M_ISODATE_RECVD, 9},
      {"R_DAY", M_DAY_RECVD, 5},
      {""}, {""},
      {"FULLDATE", M_FULLDATE, 8},
      {"S_ISODATE", M_ISODATE_STAMP, 9},
      {"S_DAY", M_DAY_STAMP, 5},
      {""}, {""},
      {"PRI", M_PRI, 3},
      {"DATE", M_DATE, 4},
      {"LEVEL", M_LEVEL, 5},
      {"R_DATE", M_DATE_RECVD, 6},
      {""},
      {"PRIORITY", M_LEVEL, 8},
      {"LEVEL_NUM", M_LEVEL_NUM, 9},
      {""},
      {"S_DATE", M_DATE_STAMP, 6},
      {"PROGRAM", M_PROGRAM, 7},
      {""}, {""}, {""}, {""},
      {"ISODATE", M_ISODATE, 7},
      {"R_MSEC", M_MSEC_RECVD, 6},
      {""},
      {"S_MSEC", M_MSEC_STAMP, 6}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        if (len == lengthtable[key])
          {
            register const char *s = wordlist[key].name;

            if (*str == *s && !memcmp (str + 1, s + 1, len - 1))
              return &wordlist[key];
          }
    }
  return 0;
}
