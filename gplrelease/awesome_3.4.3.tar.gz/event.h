/*
 * event.h - event handlers header
 *
 * Copyright © 2007-2008 Julien Danjou <julien@danjou.info>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

#ifndef AWESOME_EVENT_H
#define AWESOME_EVENT_H

#include "wibox.h"
#include "client.h"
#ifdef LAB126
#include "glib.h"

#if defined(TRACK_MEMORY)
//WANT TO TRACK FREEZE DETECTION MEMORY CONSUMPTION AS WELL
// so some insance number for timeout
#define WM_PING_TIMEOUT 107.0
#define WM_DAMAGE_TIMEOUT 103.0
#else
#define WM_PING_TIMEOUT 7.0
#define WM_DAMAGE_TIMEOUT 3.0
#endif

typedef enum {
    WAITING_FOR_DAMAGE,
    WAITING_FOR_PONG
} WMFreezeDetectionState;

typedef struct {
    long sec;
    long nsec;
    struct ev_timer *ev_ping_timeout;
} WMPingRequest;

typedef struct {
    client_t *client;
    WMFreezeDetectionState state;
    struct ev_timer *ev_damage_timeout;
    WMPingRequest *pingRequest;
} WMFreezeDetectionData;
#endif

static inline int
awesome_refresh(void)
{
    banning_refresh();
    wibox_refresh();
#ifdef LAB126
    /* check to see if the client stack was updated and send */
    /* signal */
    int clientStackUpdated = client_stack_refresh();
    int flushed = xcb_flush(globalconf.connection);
    if (clientStackUpdated){
        client_emit_stack_updated_signal();
    }

    return flushed;
#else
    client_stack_refresh();
    return xcb_flush(globalconf.connection);
#endif
}

void a_xcb_set_event_handlers(void);

#endif
// vim: filetype=c:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:encoding=utf-8:textwidth=80
