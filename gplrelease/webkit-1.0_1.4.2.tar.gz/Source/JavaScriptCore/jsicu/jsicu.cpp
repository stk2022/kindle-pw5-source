/*
 * jsicu.cpp
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
#include "jsicu.h"
#include "jsicuLocale.h"
#include "jsicuNumberFormat.h"
#include "jsicuDateFormat.h"
#include "jsicuCollator.h"
#include "jsicuMsgFormat.h"

#include "wtf/Assertions.h"
#include "wtf/Platform.h"

#include <sstream>
#include <iostream> // debugging only

using namespace std;
using namespace icu;

namespace jsicu {

//======================================================================================
// Master function for installing the ICU wrapper into the JavaScript execution context
//======================================================================================
void insertICUWrapperIntoGlobalContext(JSGlobalContextRef context) {
    JSObjectRef globalObject = JSContextGetGlobalObject(context);

    installLocaleObject(context, globalObject);
    installNumberFormatObject(context, globalObject);
    installDateFormatObject(context, globalObject);
    installCollatorObject(context, globalObject);
    installMsgFormatObject(context, globalObject);
}

//======================================================================================
// Utility functions for use by the JSICU implementation
//======================================================================================
/**
 * Creates a JSValueRef from a C++ std::string (characters in UTF-8).
 */
JSValueRef makeStringValue(JSContextRef context, const string& s) {
    JSStringRef jsString = JSStringCreateWithUTF8CString(s.c_str());
    JSValueRef strValue = JSValueMakeString(context, jsString);
    JSStringRelease(jsString);
    return strValue;
}

/**
 * Creates a JSValueRef from a UnicodeString object (characters in UTF-16).
 */
JSValueRef makeUStringValue(JSContextRef context, const UnicodeString& us) {
#if !COMPILER(CXX_ELEVEN)
    JSStringRef jsString = JSStringCreateWithCharacters(us.getBuffer(), us.length());
#else
    /*Since char16_t can't be implicitly cast to unsigned int and vice versa, using reinterpret_cast*/
    JSStringRef jsString = JSStringCreateWithCharacters(reinterpret_cast<const JSChar*>(us.getBuffer()), us.length());
#endif
    JSValueRef strValue = JSValueMakeString(context, jsString);
    JSStringRelease(jsString);
    return strValue;
}

/**
 * A wrapper for JSObjectSetProperty that takes the property name as a C++
 * std::string object rather than a JSStringRef.
 */
void addProperty(JSContextRef context, JSObjectRef object, const string& propertyName, JSValueRef value,
        JSPropertyAttributes attributes) {
    JSStringRef jsPropertyName = JSStringCreateWithUTF8CString(propertyName.c_str());
    JSObjectSetProperty(context, object, jsPropertyName, value, attributes, NULL);
    JSStringRelease(jsPropertyName);
}

/**
 * A wrapper for JSObjectGetProperty that takes the property name as a C++
 * std::string object rather than a JSStringRef.
 */
JSValueRef getProperty(JSContextRef context, JSObjectRef object, const std::string& propertyName) {
    JSStringRef jsPropertyName = JSStringCreateWithUTF8CString(propertyName.c_str());
    JSValueRef propertyValue = JSObjectGetProperty(context, object, jsPropertyName, NULL);
    JSStringRelease(jsPropertyName);
    return propertyValue;
}

/**
 * Creates a JavaScript Function object that calls the specified C++ callback function,
 * and adds it as a property to the specified object, with the specified property name.
 * @param context The JavaScript execution context.
 * @param object The object to add the function to as a property (global functions
 *               get added to the global object).
 * @param functionName The property name for the new property that will contain the
 *                     new function.
 * @param callback The C++ callback function that implements the function object.
 */
void addFunctionProperty(JSContextRef context, JSObjectRef object, const string& functionName,
        JSObjectCallAsFunctionCallback callback) {
    JSStringRef jsFunctionName = JSStringCreateWithUTF8CString(functionName.c_str());
    JSObjectSetProperty(context, object, jsFunctionName,
            JSObjectMakeFunctionWithCallback(context, jsFunctionName, callback), kJSPropertyAttributeNone, NULL);
    JSStringRelease(jsFunctionName);
}

/**
 * Creates a JavaScript Constructor object and adds it as a property to the specified
 * object, with the specified property name.
 * @param context The JavaScript execution context.
 * @param object The object to add the constructor to.  This will almost always be
 *               the global object.
 * @param constructorName The property name for the new constructor (i.e., the name
 *                        of the "class" of objects the constructor constructs).
 * @param jsClass The JSClass object containing the details of the implementation.
 *                If NULL, this is the default Object class.
 * @param callback The C++ callback function that implements the constructor.
 * @return The newly-created constructor object.
 */
JSObjectRef addConstructor(JSContextRef context, JSObjectRef object, const string& constructorName,
        JSClassRef jsClass, JSObjectCallAsConstructorCallback callback) {
    JSStringRef jsConstructorName = JSStringCreateWithUTF8CString(constructorName.c_str());
    JSObjectRef jsConstructor = JSObjectMakeConstructor(context, jsClass, callback);
    JSObjectSetProperty(context, object, jsConstructorName, jsConstructor, kJSPropertyAttributeNone, NULL);
    JSStringRelease(jsConstructorName);

    return jsConstructor;
}

/**
 * Converts a JSValueRef to a C++ string.  If the JSValueRef is a string, the
 * result is the same string.  If the JSValueRef is something else, the result
 * is a human-readable rendering of the value (usually in JSON format, except
 * for certain primitive values JSON doesn't recognize).
 */
string cppStringFromJSValue(const JSContextRef context, const JSValueRef value, bool quoteStrings) {
    string result;

    if (JSValueIsUndefined(context, value)) {
        return "(undefined)";
    }
    if (JSValueIsString(context, value) && !quoteStrings) {
        JSStringRef jsString = JSValueToStringCopy(context, value, NULL);
        result = cppStringFromJSString(context, jsString);
        JSStringRelease(jsString);
        return result;
    }
    if (JSValueIsObject(context, value)) {
        JSObjectRef valueAsObject = (JSObjectRef)value;
        if (JSObjectIsFunction(context, valueAsObject)) {
            return "(function)";
        }
    }

    JSStringRef valueStr = JSValueCreateJSONString(context, value, 0, NULL);
    result = cppStringFromJSString(context, valueStr);
    JSStringRelease(valueStr);

    return result;
}

/**
 * Converts a JSStringRef to a C++ string.
 */
string cppStringFromJSString(const JSContextRef context, const JSStringRef jsString) {
    size_t jsStrSize = JSStringGetMaximumUTF8CStringSize(jsString);
    char tempCharBuf[jsStrSize + 1];
    JSStringGetUTF8CString(jsString, tempCharBuf, jsStrSize);
    return tempCharBuf;
}

/**
 * Converts a JSStringRef to a UnicodeString.
 */
void unicodeStringFromJSValue(const JSContextRef context, const JSValueRef value, UnicodeString& result) {
    JSStringRef valueStr = JSValueToStringCopy(context, value, NULL);
    result.setTo(reinterpret_cast<const UChar *>(JSStringGetCharactersPtr(valueStr)), JSStringGetLength(valueStr));
    JSStringRelease(valueStr);
}

/**
 * Internal function called by isJSDate() and uDateFromJSDate().
 * Given a JSValueRef that allegedly refers to a JavaScript Date object,
 * this function converts it to a JSObjectRef and also returns a second
 * JSObjectRef referring to the Date object's getTime() method.
 * @param context The JavaScript execution context.
 * @param value The JSValueRef the caller thinks is a Date object.
 * @param jsDate Filled in with a JSObjectRef referring to the same
 *        object as the "value" parameter.  If "value" isn't an Object,
 *        or doesn't have a property called getTime.
 * @param getTimeMethod Filled in with a JSObjectRef referring to the
 *        Date object's getTime() method.  If jsDate is filled in with
 *        NULL, this parameter will be also.  It will also be NULL if
 *        jsDate's getTime property isn't a Function.
 */
static void getGetTimeMethod(JSContextRef context, JSValueRef value, JSObjectRef& jsDate,
        JSObjectRef& getTimeMethod) {
    jsDate = NULL;
    getTimeMethod = NULL;

    if (!JSValueIsObject(context, value)) {
        return;
    }
    jsDate = JSValueToObject(context, value, NULL);
    JSValueRef getTimeMethodVal = getProperty(context, jsDate, "getTime");
    if (!JSValueIsObject(context, getTimeMethodVal)) {
        jsDate = NULL;
        return;
    }
    getTimeMethod = JSValueToObject(context, getTimeMethodVal, NULL);
    if (!JSObjectIsFunction(context, getTimeMethod)) {
        getTimeMethod = NULL;
    }
}

/**
 * Returns true if "value" is a JavaScript Date object.
 */
bool isJSDate(JSContextRef context, JSValueRef value) {
    // there doesn't seem to be a way (that I could find, anyway)
    // to directly check if a JS object is a Date, so what this function
    // actually does is tell you whether the value passed in is
    // an object with a getTime method-- that's good enough for us
    JSObjectRef jsDate;
    JSObjectRef getTimeMethod;
    getGetTimeMethod(context, value, jsDate, getTimeMethod);
    return getTimeMethod != NULL;
}

/**
 * Converts a JavaScript Date object to a Unicode UDate value
 * referring to the same instant in time.
 */
UDate uDateFromJSDate(JSContextRef context, JSValueRef value) {
    UDate result = (UDate)0;
    JSObjectRef jsDate;
    JSObjectRef getTimeMethod;
    getGetTimeMethod(context, value, jsDate, getTimeMethod);
    if (getTimeMethod != NULL) {
        JSValueRef jsDateVal = JSObjectCallAsFunction(context, getTimeMethod, jsDate, 0, NULL, NULL);
        if (JSValueIsNumber(context, jsDateVal)) {
            result = (UDate)JSValueToNumber(context, jsDateVal, NULL);
        }
    }
    return result;
}

/**
 * Checks an ICU error code for failure, and creates a JavaScript Error object
 * if necessary.  Callback functions call this after performing an ICU operation
 * and pass their "exception" parameter to it-- this is how the callback functions
 * throw exceptions in the JavaScript environment.
 * @param err The ICU error code to chec.
 * @param context The JavaScript execution context.
 * @param exception A pointer to a JSValueRef.  If "err" represents a failure,
 *                  the variable pointed to by this parameter is filled in
 *                  with a new Error object with a message reporting an ICU
 *                  error.  (This parameter can be NULL, in which case no
 *                  Error object is created.)
 * @return True if "err" represented a failure; false if it didn't.
 */
bool checkICUError(UErrorCode err, JSContextRef context, JSValueRef* exception) {
    bool failed = U_FAILURE(err);
    if (failed && exception != NULL) {
        // JSObjectMakeError wants an array of arguments (with a separate length
        // parameter), but the Error constructor only takes one argument, so we
        // just make a one-element array for the arguments
        ostringstream message;
        message << "ICU Error: " << err;

        JSValueRef exceptArgs[1];
        exceptArgs[0] = makeStringValue(context, message.str());
        *exception = JSObjectMakeError(context, 1, exceptArgs, exception);
        LOG_ERROR("ICU error: %d", err);
    }
    return failed;
}

} // namespace jsicu
