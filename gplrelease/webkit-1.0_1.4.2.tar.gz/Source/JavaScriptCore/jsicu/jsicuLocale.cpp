/*
 * jsicuLocale.cpp
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
#include "jsicuLocale.h"

#include "jsicu.h"

#include "unicode/uloc.h"
#include "unicode/unistr.h"

#include "wtf/Assertions.h"

#include <stdexcept>
#include <cstring>
#include <iostream> // debugging only

using namespace std;

namespace jsicu {

//======================================================================================
// Locale JS class definition and installation code
//======================================================================================
/**
 * An array of JSStaticValue records describing the properties of the Locale object.
 */
JSStaticValue localeProperties[] = {
    { "locale", getLocaleCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "language", getLanguageCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "region", getRegionCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "script", getScriptCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { NULL, NULL, NULL, 0 }
};

/**
 * An array of JSStaticFunction records describing the methods of the Locale object.
 */
JSStaticFunction localeMethods[] = {
    { "availableLocales", availableLocalesCallback, 0 },
    { "maximizedLocale", maximizedLocaleCallback, 0 },
    { "minimizedLocale", minimizedLocaleCallback, 0 },
    { "displayLanguage", displayLanguageCallback, 0 },
    { "displayRegion", displayRegionCallback, 0 },
    { "displayScript", displayScriptCallback, 0 },
    { "displayName", displayNameCallback, 0 },
    { NULL, NULL, 0 }
};

// NOTE: This implementation isn't thread-safe-- do we care?
static JSClassRef localeClass = NULL;

/**
 * Returns the JSClassRef describing the methods and properties of the Locale object.
 * (The Locale JSClassRef is a singleton object, and this function lazy-creates it.)
 */
static JSClassRef getLocaleClass() {
    if (localeClass == NULL) {
        JSClassDefinition localeClassDef = kJSClassDefinitionEmpty;
        localeClassDef.className = "Locale";
        localeClassDef.initialize = initializeLocaleCallback;
        localeClassDef.finalize = finalizeLocaleCallback;
        localeClassDef.staticValues = localeProperties;
        localeClassDef.staticFunctions = localeMethods;

        localeClass = JSClassCreate(&localeClassDef);
    }
    return localeClass;
}

//======================================================================================
// Install function for Locale API
//======================================================================================
/**
 * Called by insertICUWrapperIntoGlobalContext() to install the Locale constructor
 * into the execution context's global object.
 */
void installLocaleObject(JSGlobalContextRef context, JSObjectRef globalObject) {
    addConstructor(context, globalObject, "Locale", getLocaleClass(), localeConstructorCallback);
}

//======================================================================================
// Utility functions
//======================================================================================
/**
 * Extracts the actual locale ID from the specified object's private-data area
 * and throws an exception if the specified object isn't a Locale object.
 * <p>(JSObjectRefs created from the Locale constructor have a locale ID (a
 * heap-allocated array of ASCII characters) stored in their private-data area).
 * @param context The JavaScript execution context
 * @param jsLocale The JavaScript object to extract the internal locale ID from.
 * @param exception Filled in with a JavaScript Error object if the specified
 *                  object isn't a Locale object or doesn't have the internal
 *                  locale ID.
 */
char* extractLocaleID(JSContextRef context, JSObjectRef jsLocale, JSValueRef* exception) {
    char* lid = NULL;
    if (context == NULL || JSValueIsObjectOfClass(context, jsLocale, getLocaleClass())) {
        lid = (char*)JSObjectGetPrivate(jsLocale);
    }

    if (lid == NULL && exception != NULL) {
        // JSObjectMakeError wants an array of arguments (with a separate length
        // parameter), but the Error constructor only takes one argument, so we
        // just make a one-element array for the arguments
        JSValueRef exceptArgs[1];
        exceptArgs[0] = makeStringValue(context, "Locale object does not contain implementation object");
        *exception = JSObjectMakeError(context, 1, exceptArgs, exception);
        LOG_ERROR("ICU locale ID not found in JS Locale");
    }
    return lid;
}

/**
 * Creates a new JavaScript Locale object from the specified internal locale ID.
 * The public constructor takes a BCP #47 language tag, which is different from
 * the internal locale ID; the public constructor, plus several other functions
 * that create new Locale objects, call this function to do the actual creation.
 * (The ICU locale ID is stored in the JSObjectRef's private-data area.)
 */
JSObjectRef makeJSLocaleObject(JSContextRef context, const string& rawID, JSValueRef* exception) {
    char* internalID = strdup(rawID.c_str());
    JSObjectRef newLocale = JSObjectMake(context, getLocaleClass(), internalID);
    return newLocale;
}

/**
 * Given a JSObjectRef referring to a JavaScript Locale object, returns an ICU
 * Locale object referring to the same locale.
 */
Locale makeICULocaleObject(JSContextRef context, JSObjectRef jsLocale, JSValueRef* exception) {
    if (jsLocale == NULL) {
        // NULL can be used to get the default locale-- this is a shortcut to
        // simplify the calling code
        return Locale::getDefault();
    }

    char* lid = extractLocaleID(context, jsLocale, exception);
    if (lid != NULL) {
        return Locale::createFromName(lid);
    } else {
        return NULL;
    }
}

/**
 * Given a JSObjectRef referring to a JavaScript Locale object, returns an ICU
 * Locale object referring to the same locale.
 */
Locale makeICULocaleObject(JSContextRef context, JSValueRef jsLocale, JSValueRef* exception) {
    // NULL can be used to get the default locale-- this is a shortcut to
    // simplify the calling code
    return makeICULocaleObject(context, (jsLocale != NULL) ? JSValueToObject(context, jsLocale, exception) : NULL,
            exception);
}

//======================================================================================
// Callback (implementation) functions for Locale API
//======================================================================================
/**
 * The callback function implementing the Locale constructor.  If the script
 * specifies a locale string (in BCP #47 format), this turns it into a Locale object.
 * If the script passes no parameters, this returns a Locale representing the
 * system default locale.
 */
JSObjectRef localeConstructorCallback(JSContextRef context, JSObjectRef constructorObj, size_t argumentCount,
        const JSValueRef arguments[], JSValueRef* exception) {
    if (argumentCount == 0) {
        return makeJSLocaleObject(context, uloc_getDefault(), exception);
    } else {
        string inLocale = cppStringFromJSValue(context, arguments[0]);
        char tempID[ULOC_FULLNAME_CAPACITY];
        UErrorCode err = U_ZERO_ERROR;
        uloc_forLanguageTag(inLocale.c_str(), tempID, ULOC_FULLNAME_CAPACITY, NULL, &err);

        if (checkICUError(err, context, exception)) {
            return NULL;
        } else {
            return makeJSLocaleObject(context, tempID, exception);
        }
    }
}

/**
 * Called by the JS runtime when a new Locale object is created.
 */
void initializeLocaleCallback(JSContextRef context, JSObjectRef newLocale) {
    // private data object is created in constructor callback
}

/**
 * Called by the JS runtime right before a Locale object is released
 * by the garbage collector.  This function releases the ICU locale
 * ID, which is stored in the object's private-data area.
 */
void finalizeLocaleCallback(JSObjectRef locale) {
    char* lid = extractLocaleID(NULL, locale, NULL);
    if (lid != NULL) {
        delete [] lid;
    }
}

/**
 * Implements the getProperty logic for the Locale object's "locale" property.
 * (This function converts the internal locale ID back to a BCP47 language tag
 * using uloc_toLanguageTag().)
 */
JSValueRef getLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    char* lid = extractLocaleID(context, thisObject, exception);
    char result[ULOC_FULLNAME_CAPACITY];
    UErrorCode err = U_ZERO_ERROR;
    uloc_toLanguageTag(lid, result, ULOC_FULLNAME_CAPACITY, false, &err);
    if (!checkICUError(err, context, exception)) {
        return makeStringValue(context, result);
    } else {
        return NULL;
    }
}

/**
 * Implements the getProperty logic for the Locale object's "language" property.
 * (This wraps ICU's uloc_getLanguage() function.)
 */
JSValueRef getLanguageCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    char* lid = extractLocaleID(context, thisObject, exception);
    char language[ULOC_LANG_CAPACITY];
    UErrorCode err = U_ZERO_ERROR;
    uloc_getLanguage(lid, language, ULOC_LANG_CAPACITY, &err);
    if (!checkICUError(err, context, exception)) {
        return makeStringValue(context, language);
    } else {
        return NULL;
    }
}

/**
 * Implements the getProperty logic for the Locale object's "region" property.
 * (This wraps ICU's uloc_getCountry() function.)
 */
JSValueRef getRegionCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    char* lid = extractLocaleID(context, thisObject, exception);
    char region[ULOC_COUNTRY_CAPACITY];
    UErrorCode err = U_ZERO_ERROR;
    uloc_getCountry(lid, region, ULOC_COUNTRY_CAPACITY, &err);
    if (!checkICUError(err, context, exception)) {
        return makeStringValue(context, region);
    } else {
        return NULL;
    }
}

/**
 * Implements the getProperty logic for the Locale object's "script" property.
 * (This wraps ICU's uloc_getScript() function.)
 */
JSValueRef getScriptCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    char* lid = extractLocaleID(context, thisObject, exception);
    char script[ULOC_SCRIPT_CAPACITY];
    UErrorCode err = U_ZERO_ERROR;
    uloc_getScript(lid, script, ULOC_SCRIPT_CAPACITY, &err);
    if (!checkICUError(err, context, exception)) {
        return makeStringValue(context, script);
    } else {
        return NULL;
    }
}

/**
 * Implements the Locale.prototype.availableLocales() method.  The list of available
 * locales is returned as a JS array of Locale objects.
 */
JSValueRef availableLocalesCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    int32_t numLocales = uloc_countAvailable();
    JSValueRef localesArray[numLocales];

    for (int32_t i = 0; i < numLocales && (exception == NULL || *exception == NULL); i++) {
        localesArray[i] = makeJSLocaleObject(context, uloc_getAvailable(i), exception);
    }
    return JSObjectMakeArray(context, numLocales, localesArray, exception);
}

/**
 * Implements the Locale.prototype.maximizedLocale() function.  This returns a
 * new Locale object that has all of its blank fields filled in with their
 * likely values (e.g., "en" turns into "en-Latn-US").  It's a wrapper around
 * ICU's uloc_addLikelySubtags() function.
 */
JSValueRef maximizedLocaleCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    char* lid = extractLocaleID(context, thisObject, exception);
    char newID[ULOC_FULLNAME_CAPACITY];
    UErrorCode err = U_ZERO_ERROR;
    uloc_addLikelySubtags(lid, newID, ULOC_FULLNAME_CAPACITY, &err);
    if (!checkICUError(err, context, exception)) {
        return makeJSLocaleObject(context, newID, exception);
    } else {
        return NULL;
    }
}

/**
 * Implements the Locale.prototype.minimizedLocale() function.  This returns a
 * new Locale object that has all "unnecessary" fields blanked out (e.g., "en-Latn-US" turns
 * into "en").  It's a wrapper around ICU's uloc_minimizeSubtags() function.
 */
JSValueRef minimizedLocaleCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    char* lid = extractLocaleID(context, thisObject, exception);
    char newID[ULOC_FULLNAME_CAPACITY];
    UErrorCode err = U_ZERO_ERROR;
    uloc_minimizeSubtags(lid, newID, ULOC_FULLNAME_CAPACITY, &err);
    if (!checkICUError(err, context, exception)) {
        return makeJSLocaleObject(context, newID, exception);
    } else {
        return NULL;
    }
}

/**
 * Implements the Locale.prototype.displayLanguage() method.  This returns a
 * human-readable string naming the specified Locale's language.  If the script
 * passes no parameters, the human-readable string is in the system default
 * locale; otherwise, it's in the locale the script specifies.
 */
JSValueRef displayLanguageCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    JSObjectRef jsDispLocale = (argumentCount > 0) ? JSValueToObject(context, arguments[0], exception) : NULL;
    Locale thisLocale = makeICULocaleObject(context, thisObject, exception);
    Locale dispLocale = makeICULocaleObject(context, jsDispLocale, exception);
    UnicodeString dispLanguage;
    thisLocale.getDisplayLanguage(dispLocale, dispLanguage);
    return makeUStringValue(context, dispLanguage);
}

/**
 * Implements the Locale.prototype.displayRegion() method.  This returns a
 * human-readable string naming the specified Locale's region.  If the script
 * passes no parameters, the human-readable string is in the system default
 * locale; otherwise, it's in the locale the script specifies.
 */
JSValueRef displayRegionCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    JSObjectRef jsDispLocale = (argumentCount > 0) ? JSValueToObject(context, arguments[0], exception) : NULL;
    Locale thisLocale = makeICULocaleObject(context, thisObject, exception);
    Locale dispLocale = makeICULocaleObject(context, jsDispLocale, exception);
    UnicodeString dispRegion;
    thisLocale.getDisplayCountry(dispLocale, dispRegion);
    return makeUStringValue(context, dispRegion);
}

/**
 * Implements the Locale.prototype.displayScript() method.  This returns a
 * human-readable string naming the specified Locale's script.  If the script
 * passes no parameters, the human-readable string is in the system default
 * locale; otherwise, it's in the locale the script specifies.
 */
JSValueRef displayScriptCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    JSObjectRef jsDispLocale = (argumentCount > 0) ? JSValueToObject(context, arguments[0], exception) : NULL;
    Locale thisLocale = makeICULocaleObject(context, thisObject, exception);
    Locale dispLocale = makeICULocaleObject(context, jsDispLocale, exception);
    UnicodeString dispScript;
    thisLocale.getDisplayScript(dispLocale, dispScript);
    return makeUStringValue(context, dispScript);
}

/**
 * Implements the Locale.prototype.displayName() method.  This returns a
 * human-readable string naming the specified Locale.  If the script
 * passes no parameters, the human-readable string is in the system default
 * locale; otherwise, it's in the locale the script specifies.
 */
JSValueRef displayNameCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    JSObjectRef jsDispLocale = (argumentCount > 0) ? JSValueToObject(context, arguments[0], exception) : NULL;
    Locale thisLocale = makeICULocaleObject(context, thisObject, exception);
    Locale dispLocale = makeICULocaleObject(context, jsDispLocale, exception);
    UnicodeString dispName;
    thisLocale.getDisplayName(dispLocale, dispName);
    return makeUStringValue(context, dispName);
}

} // namespace jsicu
