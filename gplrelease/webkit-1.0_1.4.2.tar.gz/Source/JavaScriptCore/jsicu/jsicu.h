/*
 * jsicu.h
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifndef JSICU_H_
#define JSICU_H_

#include "JavaScriptCore/JavaScript.h"
#include "unicode/utypes.h"
#include "unicode/unistr.h"

#include <string>

namespace jsicu {

// function to install ICU into the JS execution context
extern void insertICUWrapperIntoGlobalContext(JSGlobalContextRef context);

// utility functions
extern JSValueRef makeStringValue(JSContextRef context, const std::string& s);
extern JSValueRef makeUStringValue(JSContextRef context, const icu::UnicodeString& us);
extern void addProperty(JSContextRef context, JSObjectRef object, const std::string& propertyName,
        JSValueRef value, JSPropertyAttributes attributes = kJSPropertyAttributeNone);
extern JSValueRef getProperty(JSContextRef context, JSObjectRef object, const std::string& propertyName);
extern void addFunctionProperty(JSContextRef context, JSObjectRef object, const std::string& functionName,
        JSObjectCallAsFunctionCallback callback);
extern JSObjectRef addConstructor(JSContextRef context, JSObjectRef object, const std::string& constructorName,
        JSClassRef jsClass, JSObjectCallAsConstructorCallback callback);
extern std::string cppStringFromJSValue(const JSContextRef context, const JSValueRef value, bool quoteStrings = false);
extern std::string cppStringFromJSString(const JSContextRef context, const JSStringRef jsString);
extern void unicodeStringFromJSValue(const JSContextRef context, const JSValueRef value, icu::UnicodeString& result);
extern bool isJSDate(JSContextRef context, JSValueRef value);
extern UDate uDateFromJSDate(JSContextRef context, JSValueRef value);
extern bool checkICUError(UErrorCode err, JSContextRef context, JSValueRef* exception);

} // namespace jsicu

#endif /* JSICU_H_ */
