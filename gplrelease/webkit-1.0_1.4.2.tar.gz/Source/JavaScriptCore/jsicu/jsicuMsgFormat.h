/*
 * jsicuMsgFormat.h
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifndef JSICUMSGFORMAT_H_
#define JSICUMSGFORMAT_H_

#include "JavaScriptCore/JavaScript.h"

#include <string>

namespace jsicu {

// function to install the MessageFormat object into the JS execution context
extern void installMsgFormatObject(JSGlobalContextRef context, JSObjectRef globalObject);

//--------------------------------------
// callback (implementation) functions
//--------------------------------------

// constructor, initializer, finalizer
extern JSObjectRef msgFormatConstructorCallback(JSContextRef context, JSObjectRef constructorObj,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern void initializeMsgFormatCallback(JSContextRef context, JSObjectRef newLocale);
extern void finalizeMsgFormatCallback(JSObjectRef locale);

// property getters
extern JSValueRef getMFPatternCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getMFLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);

// Collator methods
extern JSValueRef formatMessageCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);

} // namespace jsicu

#endif /* JSICUMSGFORMAT_H_ */
