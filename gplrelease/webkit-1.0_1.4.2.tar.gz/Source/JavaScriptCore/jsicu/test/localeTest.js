/*
 * localeTest.js
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

// This is the unit test for the new Locale object

function checkLocaleProperties(message, locale, expLocale, expLanguage, expRegion, expScript) {
    assertEqual(message + ".locale", locale.locale, expLocale);
    assertEqual(message + ".language", locale.language, expLanguage);
    assertEqual(message + ".region", locale.region, expRegion);
    assertEqual(message + ".script", locale.script, expScript);
}

function checkLocaleDefaultDisplayNames(message, locale, expName, expLanguage, expRegion, expScript) {
    assertEqual(message + ".displayName", locale.displayName(), expName);
    assertEqual(message + ".displayLanguage", locale.displayLanguage(), expLanguage);
    assertEqual(message + ".displayRegion", locale.displayRegion(), expRegion);
    assertEqual(message + ".displayScript", locale.displayScript(), expScript);
}

function checkLocaleDisplayNames(message, locale, dispLocale, expName, expLanguage, expRegion, expScript) {
    assertEqual(message + ".displayName", locale.displayName(dispLocale), expName);
    assertEqual(message + ".displayLanguage", locale.displayLanguage(dispLocale), expLanguage);
    assertEqual(message + ".displayRegion", locale.displayRegion(dispLocale), expRegion);
    assertEqual(message + ".displayScript", locale.displayScript(dispLocale), expScript);
}

var defaultLocale = new Locale();
var german = new Locale("de-DE-u-co-phonebk");
var russian = new Locale("ru");
var maximizedRussian = russian.maximizedLocale();
var usEnglish = new Locale("en-Latn-US");
var minimizedUsEnglish = usEnglish.minimizedLocale();
var australianEnglish = new Locale("en-AU");
var minimizedAustralianEnglish = australianEnglish.minimizedLocale();

checkLocaleProperties("default", defaultLocale, "en-US", "en", "US", "");
checkLocaleProperties("de-DE-u-co-phonebk", german, "de-DE-u-co-phonebk", "de", "DE", "");
checkLocaleProperties("ru", russian, "ru", "ru", "", "");
checkLocaleProperties("ru.maximizedLocale()", maximizedRussian, "ru-Cyrl-RU", "ru", "RU", "Cyrl");
checkLocaleProperties("en-Latn-US", usEnglish, "en-Latn-US", "en", "US", "Latn");
checkLocaleProperties("en-Latn-US.minimizedLocale()", minimizedUsEnglish, "en", "en", "", "");
checkLocaleProperties("en-AU", australianEnglish, "en-AU", "en", "AU", "");
checkLocaleProperties("en-AU.minimizedLocale()", minimizedAustralianEnglish, "en-AU", "en", "AU", "");

checkLocaleDefaultDisplayNames("default", defaultLocale, "English (United States)", "English", "United States", "");
checkLocaleDefaultDisplayNames("de-DE", german, "German (Germany, Collation=Phonebook Sort Order)", "German", "Germany", "");
checkLocaleDefaultDisplayNames("ru-Cyrl-RU", maximizedRussian, "Russian (Cyrillic, Russia)", "Russian", "Russia", "Cyrillic");
checkLocaleDefaultDisplayNames("en-AU", australianEnglish, "English (Australia)", "English", "Australia", "");

checkLocaleDisplayNames("default[default]", defaultLocale, defaultLocale, "English (United States)", "English", "United States", "");
checkLocaleDisplayNames("de-DE[default]", german, defaultLocale, "German (Germany, Collation=Phonebook Sort Order)", "German", "Germany", "");
checkLocaleDisplayNames("default[de-DE]", defaultLocale, german, "Englisch (Vereinigte Staaten)", "Englisch", "Vereinigte Staaten", "");
checkLocaleDisplayNames("de-DE[de-DE]", german, german, "Deutsch (Deutschland, Sortierung=Telefonbuch-Sortierregeln)", "Deutsch", "Deutschland", "");
checkLocaleDisplayNames("default[ru-Cyrl-RU]", defaultLocale, maximizedRussian, "\u0430\u043d\u0433\u043b\u0438\u0439\u0441\u043a\u0438\u0439 (\u0421\u0428\u0410)", "\u0430\u043d\u0433\u043b\u0438\u0439\u0441\u043a\u0438\u0439", "\u0421\u0428\u0410", "");
checkLocaleDisplayNames("de-DE[ru-Cyrl-RU]", german, maximizedRussian, "\u043d\u0435\u043c\u0435\u0446\u043a\u0438\u0439 (\u0413\u0435\u0440\u043c\u0430\u043d\u0438\u044f, \u0421\u043e\u043f\u043e\u0441\u0442\u0430\u0432\u043b\u0435\u043d\u0438\u0435=\u043f\u043e\u0440\u044f\u0434\u043e\u043a \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u043d\u043e\u0439 \u043a\u043d\u0438\u0433\u0438)", "\u043d\u0435\u043c\u0435\u0446\u043a\u0438\u0439", "\u0413\u0435\u0440\u043c\u0430\u043d\u0438\u044f", "");
checkLocaleDisplayNames("ru-Cyrl-RU[ru-Cyrl-RU]", maximizedRussian, maximizedRussian, "\u0440\u0443\u0441\u0441\u043a\u0438\u0439 (\u041a\u0438\u0440\u0438\u043b\u043b\u0438\u0446\u0430, \u0420\u043e\u0441\u0441\u0438\u044f)", "\u0440\u0443\u0441\u0441\u043a\u0438\u0439", "\u0420\u043e\u0441\u0441\u0438\u044f", "\u041a\u0438\u0440\u0438\u043b\u043b\u0438\u0446\u0430");

var traditionalChinese = new Locale("zh-Hant");
var maximizedTraditionalChinese = traditionalChinese.maximizedLocale();
var minimizedTraditionalChinese = traditionalChinese.minimizedLocale();
var minimizedMaximizedTraditionalChinese = maximizedTraditionalChinese.minimizedLocale();

checkLocaleProperties("zh-Hant", traditionalChinese, "zh-Hant", "zh", "", "Hant");
checkLocaleProperties("zh-Hant.maximizedLocale()", maximizedTraditionalChinese, "zh-Hant-TW", "zh", "TW", "Hant");
checkLocaleProperties("zh-Hant.minimizedLocale()", minimizedTraditionalChinese, "zh-Hant", "zh", "", "Hant");
checkLocaleProperties("zh-Hant.maximizedLocale().minimizedLocale()", minimizedMaximizedTraditionalChinese, "zh-TW", "zh", "TW", "");
checkLocaleDefaultDisplayNames("zh-Hant.maximizedLocale()", maximizedTraditionalChinese,
    "Chinese (Traditional Han, Taiwan)", "Chinese", "Taiwan", "Traditional Han");
checkLocaleDisplayNames("zh-Hant.maximizedLocale()", maximizedTraditionalChinese, maximizedTraditionalChinese,
    "\u4e2d\u6587 (\u7e41\u9ad4\u4e2d\u6587\uff0c\u53f0\u7063)", "\u4e2d\u6587", "\u53f0\u7063", "\u7e41\u9ad4\u4e2d\u6587");

var availableLocales = Locale.prototype.availableLocales();
assertEqual("Locale.prototype.availableLocales().length", availableLocales.length, 435);
checkLocaleDefaultDisplayNames("Locale.prototype.availableLocales[0]", availableLocales[0], "Afrikaans", "Afrikaans", "", "");
checkLocaleDefaultDisplayNames("Locale.prototype.availableLocales[291]", availableLocales[291], "Nama (Namibia)", "Nama", "Namibia", "");

var garbage1 = new Locale("#$%@#%@#%@#$%$@#%@%@#$@");
var garbage2 = new Locale("en-Latn-booboobooboo-@#$@#$@#");
var garbage3 = new Locale(3);
checkLocaleProperties("#$%@#%@#%@#$%$@#%@%@#$@", garbage1, "und", "", "", "");
checkLocaleProperties("en-Latn-booboobooboo-@#$@#$@#", garbage2, "en-Latn", "en", "", "Latn");
checkLocaleProperties("3", garbage3, "und", "", "", "");
checkLocaleDisplayNames("default[3]", defaultLocale, garbage3, "en (US)", "en", "US", "");
