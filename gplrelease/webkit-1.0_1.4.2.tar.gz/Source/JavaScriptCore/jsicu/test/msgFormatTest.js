/*
 * msgFormatTest.js
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
 
function checkMessageFormatProperties(mf, message, expectedPattern, expectedLocale) {
    assertEqual(message + ".pattern", mf.pattern, expectedPattern);
    assertEqual(message + ".locale", mf.locale.locale, expectedLocale);
}

var mf = new MessageFormat("Waiter, there''s {vowel,select,yes {an {what}} other {a {what}}} in my {where}!");

checkMessageFormatProperties(mf, "new MessageFormat(\"Waiter, there''s {vowel,select,yes {an {what}} other {a {what}}} in my {where}!\")",
    "Waiter, there''s {vowelyes {an {what}} other {a {what}}} in my {where}!",
    "en-US"
);
assertEqual(
    "new MessageFormat(\"Waiter, there''s {vowel,select,vowel {an {what}} other {a {what}}} in my {where}!\").format( { what: \"fly\", where: \"soup\", vowel: \"no\: } )",
    mf.format( { what: "fly", where: "soup", vowel: "no" } ),
    "Waiter, there's a fly in my soup!"
);
assertEqual(
    "new MessageFormat(\"Waiter, there''s {vowel,select,vowel {an {what}} other {a {what}}} in my {where}!\").format( { what: \"orangutan\", where: \"bouillabaisse\", vowel: \"yes\" } )",
    mf.format( { what: "orangutan", where: "bouillabaisse", vowel: "yes" } ),
    "Waiter, there's an orangutan in my bouillabaisse!"
);

mf = new MessageFormat("Waiter, how come my {where} has this {what} in it?");
checkMessageFormatProperties(mf, "new MessageFormat(\"Waiter, how come my {where} has this {what} in it?\")",
    "Waiter, how come my {where} has this {what} in it?",
    "en-US"
);
assertEqual(
    "new MessageFormat(\"Waiter, how come my {where} has this {what} in it?\").format( { what: \"fly\", where: \"soup\", vowel:0 } )",
    mf.format( { what: "fly", where: "soup", vowel:0 } ),
    "Waiter, how come my soup has this fly in it?"
);
assertEqual(
    "new MessageFormat(\"Waiter, how come my {where} has this {what} in it?\").format( { what: \"orangutan\", where: \"bouillabaisse\", vowel:1 } )",
    mf.format( { what: "orangutan", where: "bouillabaisse", vowel:1 } ),
    "Waiter, how come my bouillabaisse has this orangutan in it?"
);

mf = new MessageFormat("Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}");

var testDate = new Date(Date.UTC(1967, 2, 10, 11, 30));

checkMessageFormatProperties(mf, "new MessageFormat(\"Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}\")",
    "Found {countone {# widget} other {# widgets}} at {when,time,short} on {when,date,full}",
    "en-US"
);
assertEqual(
    "new MessageFormat(\"Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}\").format( { when: testDate, count: 1536 } )",
    mf.format( { when: testDate, count: 1536 } ),
    "Found 1,536 widgets at 3:30 AM on Friday, March 10, 1967"
);
assertEqual(
    "new MessageFormat(\"Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}\").format( { when: testDate, count: 1 } )",
    mf.format( { when: testDate, count: 1 } ),
    "Found 1 widget at 3:30 AM on Friday, March 10, 1967"
);

mf = new MessageFormat("Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}", new Locale("fr-fr"));

checkMessageFormatProperties(mf, "new MessageFormat(\"Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}\"), new Locale(\"fr-fr\")",
    "Found {countone {# widget} other {# widgets}} at {when,time,short} on {when,date,full}",
    "fr-FR"
);
assertEqual(
    "new MessageFormat(\"Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}\", new Locale(\"fr-fr\")).format( { when: new Date(1967, 2, 10, 11, 30), count: 1536 } )",
    mf.format( { when: testDate, count: 1536 } ),
    "Found 1\u00a0536 widgets at 03:30 on vendredi 10 mars 1967"
);
assertEqual(
    "new MessageFormat(\"Found {count,plural,one {# widget} other {# widgets}} at {when,time,short} on {when,date,full}\", new Locale(\"fr-fr\")).format( { when: new Date(1967, 2, 10, 11, 30), count: 1 } )",
    mf.format( { when: testDate, count: 1 } ),
    "Found 1 widget at 03:30 on vendredi 10 mars 1967"
);

mf = new MessageFormat("foo = {foo}");
checkMessageFormatProperties(mf, "new MessageFormat(\"foo = {foo}\")",
    "foo = {foo}",
    "en-US"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format( { foo: \"foo\" } )",
    mf.format( { foo: "foo" } ),
    "foo = foo"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format( { foo: 12345.67 } )",
    mf.format( { foo: 12345.67 } ),
    "foo = 12,345.67"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format( { foo: new Date(1967, 2, 10, 11, 30) } )",
    mf.format( { foo: testDate } ),
    "foo = 3/10/67 3:30 AM"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format( { foo: null } )",
    mf.format( { foo: null } ),
    "foo = null"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format( { foo: { bar: 2, baz: 3 } )",
    mf.format( { foo: { bar: 2, baz: 3 } } ),
    "foo = [object Object]"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format( { bar: 2 } )",
    mf.format( { bar: 2 } ),
    "foo = {foo}"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format( {  } )",
    mf.format( {  } ),
    "foo = {foo}"
);
assertEqual(
    "new MessageFormat(\"foo = {foo}\").format(null)",
    mf.format(null),
    "foo = {foo}"
);

// try various illegal initialization parameters

function testBadInitialization(pattern, expectedMessage) {
    try {
        var mf = new MessageFormat(pattern);
        assert("No exception in \"new MessageFormat(" + pattern + ")\"", false);
    }
    catch (error) {
        assertEqual("Exception message for \"new MessageFormat(" + pattern + ")\"", error.message, expectedMessage);
    }
}

testBadInitialization("foo {wah,bleah}", "ICU Error: 1");
testBadInitialization("foo {wah,number,#0#}", "ICU Error: 65799");
testBadInitialization("foo {wah,plural,goo {goo}}", "ICU Error: 65806");
