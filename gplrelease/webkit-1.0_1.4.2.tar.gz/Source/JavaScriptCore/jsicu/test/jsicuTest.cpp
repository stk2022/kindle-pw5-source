/*
 * jsicuTest.cpp
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
#include "JavaScriptCore/JavaScript.h"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// forward declarations of utility functions
static string cppStringFromJSValue(const JSContextRef context, const JSValueRef value, bool quoteStrings = false);
static string cppStringFromJSString(const JSContextRef context, const JSStringRef jsString);
static void addFunctionProperty(JSContextRef context, JSObjectRef object, const string& functionName,
        JSObjectCallAsFunctionCallback callback);

// forward declarations of test functions
static void readStringFromFile(const string& filename, string& contents);
static void insertObjectsIntoGlobalContext(JSGlobalContextRef context);

// forward declarations of callback functions
static JSValueRef testPrintCallback(JSContextRef context, JSObjectRef object, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
static JSValueRef assertCallback(JSContextRef context, JSObjectRef object, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
static JSValueRef assertEqualCallback(JSContextRef context, JSObjectRef object, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);

static int assertCount = 0;
static int passCount = 0;

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cout << "Must supply name of script to execute!" << endl;
        return 1;
    }

    JSGlobalContextRef context = JSGlobalContextCreateInGroup(NULL, NULL);
    insertObjectsIntoGlobalContext(context);

    string scriptName(argv[1]);
    string script;
    cout << "Executing " << scriptName << "..." << endl;
    readStringFromFile(scriptName, script);
    JSStringRef jsScript = JSStringCreateWithUTF8CString(script.c_str());
    JSValueRef exception;

    JSValueRef result = JSEvaluateScript(context, jsScript, NULL, NULL, 1, &exception);
    if (result != NULL) {
        if (assertCount > 0) {
            if (assertCount == passCount) {
                cout << "All " << assertCount << " tests PASSED." << endl;
            } else {
                cout << (assertCount - passCount) << " out of " << assertCount << " tests FAILED." << endl;
            }
        } else {
            cout << "Script returned " << cppStringFromJSValue(context, result) << endl;
        }
    } else {
        cout << "Script terminated abnormally: Exception is " << cppStringFromJSValue(context, exception) << endl;
    }


    JSStringRelease(jsScript);
    JSGlobalContextRelease(context);

    if (result == NULL || (assertCount > 0 && assertCount != passCount)) {
        return 1;
    } else {
        return 0;
    }
}

//============================================
// utility functions
// (all of these are copied from jsicu.cpp/.h)
//============================================

string cppStringFromJSValue(const JSContextRef context, const JSValueRef value, bool quoteStrings) {
    string result;

    if (JSValueIsUndefined(context, value)) {
        return "(undefined)";
    }
    if (JSValueIsString(context, value) && !quoteStrings) {
        JSStringRef jsString = JSValueToStringCopy(context, value, NULL);
        result = cppStringFromJSString(context, jsString);
        JSStringRelease(jsString);
        return result;
    }
    if (JSValueIsObject(context, value)) {
        JSObjectRef valueAsObject = (JSObjectRef)value;
        if (JSObjectIsFunction(context, valueAsObject)) {
            return "(function)";
        }
    }

    JSStringRef valueStr = JSValueCreateJSONString(context, value, 0, NULL);
    result = cppStringFromJSString(context, valueStr);
    JSStringRelease(valueStr);

    return result;
}

string cppStringFromJSString(const JSContextRef context, const JSStringRef jsString) {
    size_t jsStrSize = JSStringGetMaximumUTF8CStringSize(jsString);
    char tempCharBuf[jsStrSize + 1];
    JSStringGetUTF8CString(jsString, tempCharBuf, jsStrSize);
    return tempCharBuf;
}

void addFunctionProperty(JSContextRef context, JSObjectRef object, const string& functionName,
        JSObjectCallAsFunctionCallback callback) {
    JSStringRef jsFunctionName = JSStringCreateWithUTF8CString(functionName.c_str());
    JSObjectSetProperty(context, object, jsFunctionName,
            JSObjectMakeFunctionWithCallback(context, jsFunctionName, callback), kJSPropertyAttributeNone, NULL);
    JSStringRelease(jsFunctionName);
}

//======================================
// test functions
//======================================

void readStringFromFile(const string& filename, string& contents) {
    ifstream in(filename.c_str());
    contents.erase();
    string line;
    while (in.good()) {
        getline(in, line);
        contents += line;
        contents += '\n';
    }
}

void insertObjectsIntoGlobalContext(JSGlobalContextRef context) {
//    insertICUWrapperIntoGlobalContext(context);
// (this should be happening inside JavaSciptCore now)

    JSObjectRef globalObject = JSContextGetGlobalObject(context);

    addFunctionProperty(context, globalObject, "testPrint", testPrintCallback);
    addFunctionProperty(context, globalObject, "assert", assertCallback);
    addFunctionProperty(context, globalObject, "assertEqual", assertEqualCallback);
}

//======================================
// callback functions
//======================================

static JSValueRef testPrintCallback(JSContextRef context, JSObjectRef object, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    for (size_t i = 0; i < argumentCount; i++) {
        if (i > 0) {
            cout << ", ";
        }
        cout << cppStringFromJSValue(context, arguments[i]);
    }
    cout << endl;
    return JSValueMakeUndefined(context);
}

static JSValueRef assertCallback(JSContextRef context, JSObjectRef object, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    if (argumentCount >= 2) {
        string message = cppStringFromJSValue(context, arguments[0]);
        bool assertSucceeded = JSValueToBoolean(context, arguments[1]);

        ++assertCount;
        passCount += (assertSucceeded ? 1 : 0);

        if (!assertSucceeded) {
            cout << "Assertion failed: " << message << endl;
        }
    }
    return JSValueMakeUndefined(context);
}

static JSValueRef assertEqualCallback(JSContextRef context, JSObjectRef object, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    if (argumentCount >= 3) {
        string message = cppStringFromJSValue(context, arguments[0]);
        bool assertSucceeded = JSValueIsEqual(context, arguments[1], arguments[2], exception);

        ++assertCount;
        passCount += (assertSucceeded ? 1 : 0);

        if (!assertSucceeded) {
            cout << "Assertion failed: " << message << ": expected " << cppStringFromJSValue(context, arguments[2], true)
                    << ", got " << cppStringFromJSValue(context, arguments[1], true) << endl;
        }
    }
    return JSValueMakeUndefined(context);
}
