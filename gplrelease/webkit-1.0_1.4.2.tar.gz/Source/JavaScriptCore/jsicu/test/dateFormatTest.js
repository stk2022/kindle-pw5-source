/*
 * dateFormatTest.js
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
 
// -----  Utility functions -----

// these test functions make sure we're always specifying the test date
// values in terms of UTC (the Date constructor takes its parameters
// in terms of the local time zone.)
function makeTestDate(y, m, d) {
    return new Date(Date.UTC(y, m, d));
}

function makeTestDateTime(y, m, d, h, mm, s) {
    return new Date(Date.UTC(y, m, d, h, mm, s));
}

// workaround for checking Date values-- the assertEquals() function
// checks object identity rather than semantic equality.  An easy
// workaround is to do toString() before calling assertEquals(). 
function checkParseResult(message, actual, expected) {
    if (actual instanceof Date && expected instanceof Date) {
        assertEqual(message, actual.toString(), expected.toString());
    } else {
        assertEqual(message, actual, expected);
    }
}

// all of this testing operates on the same basic time value;
// the other values are to allow parse testing to work properly
// with formats that don't preserve all the information in the
// original time value
var TEST_DATE_TIME = makeTestDateTime(1969, 6, 16, 20, 17, 40);
var TEST_DATE_TIME_NO_SECS = makeTestDateTime(1969, 6, 16, 20, 17, 0);
var TEST_DATE = makeTestDate(1969, 6, 16);
var TEST_TIME = makeTestDateTime(1970, 0, 1, 20, 17, 40);
var TEST_TIME_NO_SECS = makeTestDateTime(1970, 0, 1, 20, 17, 0);

// list of invalid input values to check, and the results
// they should produce (regardless of formatter properties)
var BAD_INPUTS = [ 5, "blah", undefined, null ];
var BAD_INPUT_FORMAT_RESULTS = [ "5", "blah", "undefined", "null" ];
    
// -----  Main test function  -----

function testDateTimeFormat(dtfName, dateTimeFormat, expectedPropertyValues, expectedFormatResult,
        expectedParseResult, goodParseInputs, badParseInputs) {
    // verify the expected property values
    assertEqual(dtfName + ".pattern", dateTimeFormat.pattern, expectedPropertyValues.pattern);
    assertEqual(dtfName + ".locale", dateTimeFormat.locale.locale, expectedPropertyValues.locale);
    assertEqual(dtfName + ".timeZone", dateTimeFormat.timeZone, expectedPropertyValues.timeZone);
    
    // format a real date and make sure we get the right result
    assertEqual(dtfName + ".format(" + TEST_DATE_TIME + ")", dateTimeFormat.format(TEST_DATE_TIME), expectedFormatResult);
    
    // try to format a bunch of non-dates and make sure the error gets reported appropriately
    for (var i = 0; i < BAD_INPUTS.length; i++) {
        assertEqual(dtfName + ".format(" + BAD_INPUTS[i] + ")", dateTimeFormat.format(BAD_INPUTS[i]),
            BAD_INPUT_FORMAT_RESULTS[i]);
    }
    
    if (expectedParseResult != undefined) {
        // parse a bunch of valid input strings and make sure they get the right result
        checkParseResult(dtfName + ".parse(format(" + TEST_DATE_TIME + ")", dateTimeFormat.parse(expectedFormatResult),
            expectedParseResult);
        for (var i = 0; i < goodParseInputs.length; i++) {
            checkParseResult(dtfName + ".parse(" + goodParseInputs[i] + ")", dateTimeFormat.parse(goodParseInputs[i]),
            expectedParseResult);
        }
        
        // parse a bunch of invalid inputs and make sure the error is reported appropriately
        for (var i = 0; i < badParseInputs.length; i++) {
            assertEqual(dtfName + ".parse(" + badParseInputs[i] + ")", dateTimeFormat.parse(badParseInputs[i]), undefined);
        }
        for (var i = 0; i < BAD_INPUTS.length; i++) {
            assertEqual(dtfName + ".parse(" + BAD_INPUTS[i] + ")", dateTimeFormat.parse(BAD_INPUTS[i]), undefined);
        }
    }
}

// -----  Individual tests  -----

// tests for canned date/time formats (in the local time zone)
testDateTimeFormat("new DateTimeFormat(\"short\")", new DateTimeFormat("short"),
    { pattern: "M/d/yy h:mm a", timeZone: "US/Pacific-New", locale: "en" },
    "7/16/69 1:17 PM", TEST_DATE_TIME_NO_SECS,
    [ "7/16/69 01:17 PM" ],
    [ "7/16/69 13:17" ]
);
testDateTimeFormat("new DateTimeFormat(\"medium\")", new DateTimeFormat("medium"),
    { pattern: "MMM d, y h:mm:ss a", timeZone: "US/Pacific-New", locale: "en" },
    "Jul 16, 1969 1:17:40 PM", TEST_DATE_TIME,
    [ "July 16, 1969 1:17:40 PM" ],
    [ ]
);
testDateTimeFormat("new DateTimeFormat(\"long\")", new DateTimeFormat("long"),
    { pattern: "MMMM d, y h:mm:ss a z", timeZone: "US/Pacific-New", locale: "en" },
    "July 16, 1969 1:17:40 PM GMT-07:00", TEST_DATE_TIME, 
    [ "July 16, 1969 1:17:40 PM PDT" ],
    [ "July 16, 1969 1:17:40 PM", "July 16 1969 1:17:40 PM PDT PDT", "July 16 1969, 1:17:40 PM PDT PM PDT" ]
);
testDateTimeFormat("new DateTimeFormat(\"full\")", new DateTimeFormat("full"),
    { pattern: "EEEE, MMMM d, y h:mm:ss a zzzz", timeZone: "US/Pacific-New", locale: "en" },
    "Wednesday, July 16, 1969 1:17:40 PM GMT-07:00", TEST_DATE_TIME,
    [ "Wednesday, July 16, 1969 1:17:40 PM PDT" ],
    [ "July 16, 1969 1:17:40 PM", "Wednesday July 16 1969 1:17:40 PM PDT" ]
);

// tests for canned date/time formats (in UTC)
testDateTimeFormat("new DateTimeFormat(\"short\", \"UTC\")", new DateTimeFormat("short", "UTC"),
    { pattern: "M/d/yy h:mm a", timeZone: "UTC", locale: "en" },
    "7/16/69 8:17 PM", TEST_DATE_TIME_NO_SECS,
    [ "07/16/69 08:17 PM" ],
    [ "7/16/69 20:17" ]
);
testDateTimeFormat("new DateTimeFormat(\"medium\", \"UTC\")", new DateTimeFormat("medium", "UTC"),
    { pattern: "MMM d, y h:mm:ss a", timeZone: "UTC", locale: "en" },
    "Jul 16, 1969 8:17:40 PM", TEST_DATE_TIME,
    [ "July 16, 1969 8:17:40 PM" ],
    [ ]
);
testDateTimeFormat("new DateTimeFormat(\"long\", \"UTC\")", new DateTimeFormat("long", "UTC"),
    { pattern: "MMMM d, y h:mm:ss a z", timeZone: "UTC", locale: "en" },
    "July 16, 1969 8:17:40 PM GMT+00:00", TEST_DATE_TIME, 
    [ "July 16, 1969 8:17:40 PM UTC", "July 16, 1969 8:17:40 PM GMT" ],
    [ "July 16, 1969 8:17:40 PM", "July 16 1969 8:17:40 PM GMT" ]
);
testDateTimeFormat("new DateTimeFormat(\"full\", \"UTC\")", new DateTimeFormat("full", "UTC"),
    { pattern: "EEEE, MMMM d, y h:mm:ss a zzzz", timeZone: "UTC", locale: "en" },
    "Wednesday, July 16, 1969 8:17:40 PM GMT+00:00", TEST_DATE_TIME,
    [ "Wednesday, July 16, 1969 8:17:40 PM UTC" ],
    [ "July 16, 1969 8:17:40 PM GMT", "Wednesday July 16 1969, 8:17:40 PM GMT" ]
);

// tests for canned date formats (in UTC)
testDateTimeFormat("new DateTimeFormat(\"short-date\", \"UTC\")", new DateTimeFormat("short-date", "UTC"),
    { pattern: "M/d/yy", timeZone: "UTC", locale: "en" },
    "7/16/69", TEST_DATE,
    [ "07/16/69" ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"medium-date\", \"UTC\")", new DateTimeFormat("medium-date", "UTC"),
    { pattern: "MMM d, y", timeZone: "UTC", locale: "en" },
    "Jul 16, 1969", TEST_DATE,
    [ "July 16, 1969" ],
    [ ]
);
testDateTimeFormat("new DateTimeFormat(\"long-date\", \"UTC\")", new DateTimeFormat("long-date", "UTC"),
    { pattern: "MMMM d, y", timeZone: "UTC", locale: "en" },
    "July 16, 1969", TEST_DATE,
    [  ],
    [ "July 16 1969" ]
);
testDateTimeFormat("new DateTimeFormat(\"full-date\", \"UTC\")", new DateTimeFormat("full-date", "UTC"),
    { pattern: "EEEE, MMMM d, y", timeZone: "UTC", locale: "en" },
    "Wednesday, July 16, 1969", TEST_DATE,
    [ "Wed, July 16, 1969", "Wednesday, Jul 16, 1969" ],
    [ "Wednesday July 16 1969" ]
);

// tests for canned time formats (in UTC)
testDateTimeFormat("new DateTimeFormat(\"short-time\", \"UTC\")", new DateTimeFormat("short-time", "UTC"),
    { pattern: "h:mm a", timeZone: "UTC", locale: "en" },
    "8:17 PM", TEST_TIME_NO_SECS,
    [ "08:17 PM" ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"medium-time\", \"UTC\")", new DateTimeFormat("medium-time", "UTC"),
    { pattern: "h:mm:ss a", timeZone: "UTC", locale: "en" },
    "8:17:40 PM", TEST_TIME,
    [ "08:17:40 PM" ],
    [ ]
);
testDateTimeFormat("new DateTimeFormat(\"long-time\", \"UTC\")", new DateTimeFormat("long-time", "UTC"),
    { pattern: "h:mm:ss a z", timeZone: "UTC", locale: "en" },
    "8:17:40 PM GMT+00:00", TEST_TIME,
    [ "8:17:40 PM UTC", "8:17:40 PM GMT" ],
    [ "8:17:40 PM", "20:17:40 UTC" ]
);
testDateTimeFormat("new DateTimeFormat(\"full-time\", \"UTC\")", new DateTimeFormat("full-time", "UTC"),
    { pattern: "h:mm:ss a zzzz", timeZone: "UTC", locale: "en" },
    "8:17:40 PM GMT+00:00", TEST_TIME,
    [ "8:17:40 PM UTC", "8:17:40 PM GMT" ],
    [ "8:17:40 PM", "20:17:40 UTC" ]
);

// tests for canned date/time formats in a non-English locale
testDateTimeFormat("new DateTimeFormat(\"short\", \"UTC\", \"fr-fr\")", new DateTimeFormat("short", "UTC", new Locale("fr-fr")),
    { pattern: "dd/MM/yy HH:mm", timeZone: "UTC", locale: "fr" },
    "16/07/69 20:17", TEST_DATE_TIME_NO_SECS,
    [  ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"medium\", \"UTC\", \"fr-fr\")", new DateTimeFormat("medium", "UTC", new Locale("fr-fr")),
    { pattern: "d MMM y HH:mm:ss", timeZone: "UTC", locale: "fr" },
    "16 juil. 1969 20:17:40", TEST_DATE_TIME,
    [  ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"long\", \"UTC\", \"fr-fr\")", new DateTimeFormat("long", "UTC", new Locale("fr-fr")),
    { pattern: "d MMMM y HH:mm:ss z", timeZone: "UTC", locale: "fr" },
    "16 juillet 1969 20:17:40 UTC+00:00", TEST_DATE_TIME, 
    [ "16 juillet 1969 20:17:40 UTC" ],
    [ "16 juillet, 1969 20:17:40 UTC", "16 juillet 1969, 20:17:40 UTC" ]
);
testDateTimeFormat("new DateTimeFormat(\"full\", \"UTC\", \"fr-fr\")", new DateTimeFormat("full", "UTC", new Locale("fr-fr")),
    { pattern: "EEEE d MMMM y HH:mm:ss zzzz", timeZone: "UTC", locale: "fr" },
    "mercredi 16 juillet 1969 20:17:40 UTC+00:00", TEST_DATE_TIME,
    [ "mercredi 16 juillet 1969 20:17:40 UTC" ],
    [ "mercredi, 16 juillet 1969 20:17:40 UTC+00:00", "mercredi 16 juillet 1969, 20:17:40 UTC+00:00" ]
);

// tests for canned date/time formats in a non-English locale and the local time zone
testDateTimeFormat("new DateTimeFormat(\"short\", \"localtime\", \"fr-fr\")", new DateTimeFormat("short", "localtime", new Locale("fr-fr")),
    { pattern: "dd/MM/yy HH:mm", timeZone: "US/Pacific-New", locale: "fr" },
    "16/07/69 13:17", TEST_DATE_TIME_NO_SECS,
    [  ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"medium\", \"localtime\", \"fr-fr\")", new DateTimeFormat("medium", "localtime", new Locale("fr-fr")),
    { pattern: "d MMM y HH:mm:ss", timeZone: "US/Pacific-New", locale: "fr" },
    "16 juil. 1969 13:17:40", TEST_DATE_TIME,
    [  ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"long\", \"localtime\", \"fr-fr\")", new DateTimeFormat("long", "localtime", new Locale("fr-fr")),
    { pattern: "d MMMM y HH:mm:ss z", timeZone: "US/Pacific-New", locale: "fr" },
    "16 juillet 1969 13:17:40 UTC-07:00", TEST_DATE_TIME, 
    [  ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"full\", \"localtime\", \"fr-fr\")", new DateTimeFormat("full", "localtime", new Locale("fr-fr")),
    { pattern: "EEEE d MMMM y HH:mm:ss zzzz", timeZone: "US/Pacific-New", locale: "fr" },
    "mercredi 16 juillet 1969 13:17:40 UTC-07:00", TEST_DATE_TIME,
    [  ],
    [  ]
);

// tests for custom patterns
testDateTimeFormat("new DateTimeFormat(\"MMMM yyyy dd (EEEE G)\", \"UTC\")",
    new DateTimeFormat("MMMM yyyy dd (EEEE G)", "UTC"),
    { pattern: "MMMM yyyy dd (EEEE G)", timeZone: "UTC", locale: "en" },
    "July 1969 16 (Wednesday AD)", TEST_DATE,
    [  ],
    [  ]
);
testDateTimeFormat("new DateTimeFormat(\"MMMM yyyy dd (EEEE G)\", \"UTC\", \"fr-fr\")",
    new DateTimeFormat("MMMM yyyy dd (EEEE G)", "UTC", new Locale("fr-fr")),
    { pattern: "MMMM yyyy dd (EEEE G)", timeZone: "UTC", locale: "fr" },
    "juillet 1969 16 (mercredi ap. J.-C.)", TEST_DATE,
    [  ],
    [  ]
);

// try various nonsensical initialization parameters

testDateTimeFormat("new DateTimeFormat(\"333???\")",
    new DateTimeFormat("333???"),
    { pattern: "333???", timeZone: "US/Pacific-New", locale: "en" },
    "333???"
);

testDateTimeFormat("new DateTimeFormat(\"MMM-BB-yyyy\")",
    new DateTimeFormat("MMM-BB-yyyy"),
    { pattern: "MMM-BB-yyyy", timeZone: "US/Pacific-New", locale: "en" },
    "Jul--"
);

testDateTimeFormat("new DateTimeFormat(\"short-date\", \"@@@@\")",
    new DateTimeFormat("short-date", "@@@@"),
    { pattern: "M/d/yy", timeZone: "GMT", locale: "en" },
    "7/16/69", TEST_DATE,
    [  ],
    [  ]
);
