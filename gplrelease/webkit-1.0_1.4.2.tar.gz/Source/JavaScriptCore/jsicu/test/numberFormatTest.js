/*
 * numberFormatTest.js
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

// This is the unit test for the new NumberFormat object

// first, check all the NumberFormat.Style constants
assertEqual("NumberFormat.Style.INTEGER", NumberFormat.Style.INTEGER, -1);
assertEqual("NumberFormat.Style.DECIMAL", NumberFormat.Style.DECIMAL, 0);
assertEqual("NumberFormat.Style.CURRENCY", NumberFormat.Style.CURRENCY, 1);
assertEqual("NumberFormat.Style.PERCENT", NumberFormat.Style.PERCENT, 2);
assertEqual("NumberFormat.Style.SCIENTIFIC", NumberFormat.Style.SCIENTIFIC, 3);
assertEqual("NumberFormat.Style.ISO_CURRENCY", NumberFormat.Style.ISO_CURRENCY, 4);

// canned lists of test values for formatting and parsing
var TEST_FORMAT_VALUES = [
    1234567.89,
    3,
    -2.7182818,
    5.396E12,
    "blah",
    undefined,
    null
];

var TEST_PARSE_VALUES = [
    "1,234,567.89",
    "1234567.89",
    "12,34,56,7.89",
    "3",
    "$1,234,567.89",
    "$3",
    "($3)",
    "123.45%",
    "-2.7182818",
    "1.0E3",
    "123abc",
    "abc",
    5,
    null,
    { foo: "foo", bar: 4 },
    undefined
];

// the actual testing code
function testNumberFormat(nfName, numberFormat, expectedPropertyValues, expectedFormatResults, expectedParseResults) {
    assertEqual(nfName + ".style", numberFormat.style, expectedPropertyValues.style);
    assertEqual(nfName + ".pattern", numberFormat.pattern, expectedPropertyValues.pattern);
    assertEqual(nfName + ".locale", numberFormat.locale.locale, expectedPropertyValues.locale);
    assertEqual(nfName + ".currency", numberFormat.currency, expectedPropertyValues.currency);
    
    for (var i = 0; i < TEST_FORMAT_VALUES.length; i++) {
        assertEqual(nfName + ".format(" + TEST_FORMAT_VALUES[i] + ")", numberFormat.format(TEST_FORMAT_VALUES[i]),
                expectedFormatResults[i]);
    }
    for (var i = 0; i < TEST_PARSE_VALUES.length; i++) {
        assertEqual(nfName + ".parse(" + JSON.stringify(TEST_PARSE_VALUES[i]) + ")", numberFormat.parse(TEST_PARSE_VALUES[i]),
                expectedParseResults[i]);
    }
}

// Run the canned lists through various number formatters

// test the default and all of the style constants
testNumberFormat("NumberFormat()", new NumberFormat(),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,##0.###", locale: "en", currency: "" },
    [ "1,234,567.89", "3", "-2.718", "5,396,000,000,000", "blah", "undefined", "null" ],
    [ 1234567.89, 1234567.89, 1234567.89, 3, undefined, undefined, undefined, 123.45, -2.7182818, 1000, 123,
      undefined, 5, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.DECIMAL)", new NumberFormat(NumberFormat.Style.DECIMAL),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,##0.###", locale: "en", currency: "" },
    [ "1,234,567.89", "3", "-2.718", "5,396,000,000,000", "blah", "undefined", "null" ],
    [ 1234567.89, 1234567.89, 1234567.89, 3, undefined, undefined, undefined, 123.45, -2.7182818, 1000, 123,
      undefined, 5, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.INTEGER)", new NumberFormat(NumberFormat.Style.INTEGER),
    { style: NumberFormat.Style.INTEGER, pattern: "#,##0", locale: "en", currency: "" },
    [ "1,234,568", "3", "-3", "5,396,000,000,000", "blah", "undefined", "null" ],
    [ 1234567, 1234567, 1234567, 3, undefined, undefined, undefined, 123, -2, 1, 123,
      undefined, 5, undefined, undefined, undefined ]
);

// test a NumberFormat with a currency unit specified

testNumberFormat("NumberFormat(NumberFormat.Style.DECIMAL, \"USD\", new Locale())",
    new NumberFormat(NumberFormat.Style.DECIMAL, "USD", new Locale()),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,##0.###", locale: "en", currency: "USD" },
    [ "1,234,567.89", "3", "-2.718", "5,396,000,000,000", "blah", "undefined", "null" ],
    [ 1234567.89, 1234567.89, 1234567.89, 3, undefined, undefined, undefined, 123.45, -2.7182818, 1000, 123,
      undefined, 5, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.DECIMAL, \"USD\", new Locale(\"fr-fr\"))",
    new NumberFormat(NumberFormat.Style.DECIMAL, "USD", new Locale("fr-fr")),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,##0.###", locale: "fr", currency: "USD" },
    [ "1\u00a0234\u00a0567,89", "3", "-2,718", "5\u00a0396\u00a0000\u00a0000\u00a0000", "blah", "undefined", "null" ],
    [ 1.234, 1234567, 12.34, 3, undefined, undefined, undefined, 123, -2, 1, 123,
      undefined, 5, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.INTEGER, \"USD\", new Locale(\"fr-fr\"))",
    new NumberFormat(NumberFormat.Style.INTEGER, "USD", new Locale("fr-fr")),
    { style: NumberFormat.Style.INTEGER, pattern: "#,##0", locale: "fr", currency: "USD" },
    [ "1\u00a0234\u00a0568", "3", "-3", "5\u00a0396\u00a0000\u00a0000\u00a0000", "blah", "undefined", "null" ],
    [ 1, 1234567, 12, 3, undefined, undefined, undefined, 123, -2, 1, 123,
      undefined, 5, undefined, undefined, undefined ]
);

// test currency formatting with various locales and currencies

testNumberFormat("NumberFormat(NumberFormat.Style.CURRENCY)", new NumberFormat(NumberFormat.Style.CURRENCY),
    { style: NumberFormat.Style.CURRENCY, pattern: "\u00a4#,##0.00;(\u00a4#,##0.00)", locale: "en", currency: "USD" },
    [ "$1,234,567.89", "$3.00", "($2.72)", "$5,396,000,000,000.00", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, 1234567.89, 3, -3, undefined, undefined,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.ISO_CURRENCY)", new NumberFormat(NumberFormat.Style.ISO_CURRENCY),
    { style: NumberFormat.Style.ISO_CURRENCY, pattern: "\u00a4\u00a4#,##0.00;(\u00a4\u00a4#,##0.00)", locale: "en", currency: "USD" },
    [ "USD1,234,567.89", "USD3.00", "(USD2.72)", "USD5,396,000,000,000.00", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, 1234567.89, 3, -3, undefined, undefined,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.CURRENCY, \"JPY\")",
    new NumberFormat(NumberFormat.Style.CURRENCY, "JPY"),
    { style: NumberFormat.Style.CURRENCY, pattern: "\u00a4#,##0;(\u00a4#,##0)", locale: "en", currency: "JPY" },
    [ "\u00a51,234,568", "\u00a53", "(\u00a53)", "\u00a55,396,000,000,000", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, 1234567.89, 3, -3, undefined, undefined,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.ISO_CURRENCY, \"JPY\")",
    new NumberFormat(NumberFormat.Style.ISO_CURRENCY, "JPY"),
    { style: NumberFormat.Style.ISO_CURRENCY, pattern: "\u00a4\u00a4#,##0;(\u00a4\u00a4#,##0)", locale: "en", currency: "JPY" },
    [ "JPY1,234,568", "JPY3", "(JPY3)", "JPY5,396,000,000,000", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, 1234567.89, 3, -3, undefined, undefined,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.CURRENCY, \"\", new Locale(\"ja-jp\")",
    new NumberFormat(NumberFormat.Style.CURRENCY, "", new Locale("ja-jp")),
    { style: NumberFormat.Style.CURRENCY, pattern: "\u00a4#,##0", locale: "ja", currency: "JPY" },
    [ "\uffe51,234,568", "\uffe53", "-\uffe53", "\uffe55,396,000,000,000", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, 1234567.89, 3, undefined, undefined, undefined,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

// try a couple of bogus currency symbols

testNumberFormat("NumberFormat(NumberFormat.Style.CURRENCY, \"blah\")", new NumberFormat(NumberFormat.Style.CURRENCY, "blah"),
    { style: NumberFormat.Style.CURRENCY, pattern: "\u00a4#,##0.00;(\u00a4#,##0.00)", locale: "en", currency: "USD" },
    [ "$1,234,567.89", "$3.00", "($2.72)", "$5,396,000,000,000.00", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, 1234567.89, 3, -3, undefined, undefined,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.CURRENCY, \"???\")", new NumberFormat(NumberFormat.Style.CURRENCY, "???"),
    { style: NumberFormat.Style.CURRENCY, pattern: "\u00a4#,##0.00;(\u00a4#,##0.00)", locale: "en", currency: "???" },
    [ "???1,234,567.89", "???3.00", "(???2.72)", "???5,396,000,000,000.00", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, 1234567.89, 3, -3, undefined, undefined,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

// test percentage and scientific-notation formatting

testNumberFormat("NumberFormat(NumberFormat.Style.PERCENT)", new NumberFormat(NumberFormat.Style.PERCENT),
    { style: NumberFormat.Style.PERCENT, pattern: "#,##0%", locale: "en", currency: "" },
    [ "123,456,789%", "300%", "-272%", "539,600,000,000,000%", "blah", "undefined", "null" ],
    [ undefined, undefined, undefined, undefined, undefined, undefined, undefined, 1.2345,
      undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(NumberFormat.Style.SCIENTIFIC)", new NumberFormat(NumberFormat.Style.SCIENTIFIC),
    { style: NumberFormat.Style.SCIENTIFIC, pattern: "#E0", locale: "en", currency: "" },
    [ "1.23456789E6", "3E0", "-2.7182818E0", "5.396E12", "blah", "undefined", "null" ],
    [ 1, 1234567.89, 12, 3, undefined, undefined, undefined, 123.45, -2.7182818, 1000, 123,
      undefined, 5, undefined, undefined, undefined ]
);

// test custom NumberFormat patterns with different locales

testNumberFormat("NumberFormat(\"#,##0.###\")", new NumberFormat("#,##0.###"),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,##0.###", locale: "en", currency: "" },
    [ "1,234,567.89", "3", "-2.718", "5,396,000,000,000", "blah", "undefined", "null" ],
    [ 1234567.89, 1234567.89, 1234567.89, 3, undefined, undefined, undefined, 123.45, -2.7182818, 1000, 123,
      undefined, 5, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(\"#,##0.###\"), \"\", new Locale(\"fr-fr\"))",
    new NumberFormat("#,##0.###", "", new Locale("fr-fr")),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,##0.###", locale: "fr", currency: "" },
    [ "1\u00a0234\u00a0567,89", "3", "-2,718", "5\u00a0396\u00a0000\u00a0000\u00a0000", "blah", "undefined", "null" ],
    [ 1.234, 1234567, 12.34, 3, undefined, undefined, undefined, 123, -2, 1, 123,
      undefined, 5, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(\"#,000.0##\")", new NumberFormat("#,000.0##"),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,000.0##", locale: "en", currency: "" },
    [ "1,234,567.89", "003.0", "-002.718", "5,396,000,000,000.0", "blah", "undefined", "null" ],
    [ 1234567.89, 1234567.89, 1234567.89, 3, undefined, undefined, undefined, 123.45, -2.7182818, 1000, 123,
      undefined, 5, undefined, undefined, undefined ]
);

testNumberFormat("NumberFormat(\"#,000.0##\", \"\", new Locale(\"fr-fr\"))",
    new NumberFormat("#,000.0##", "", new Locale("fr-fr")),
    { style: NumberFormat.Style.DECIMAL, pattern: "#,000.0##", locale: "fr", currency: "" },
    [ "1\u00a0234\u00a0567,89", "003,0", "-002,718", "5\u00a0396\u00a0000\u00a0000\u00a0000,0", "blah", "undefined", "null" ],
    [ 1.234, 1234567, 12.34, 3, undefined, undefined, undefined, 123, -2, 1, 123,
      undefined, 5, undefined, undefined, undefined ]
);

// try various illegal initialization parameters

function testBadInitialization(pattern, expectedMessage) {
    try {
        var nf = new NumberFormat(pattern);
        assert("No exception in \"new NumberFormat(" + pattern + ")\"", false);
    }
    catch (error) {
        assertEqual("Exception message for \"new NumberFormat(" + pattern + ")\"", error.message, expectedMessage);
    }
}

testBadInitialization(-333, "ICU Error: 1");
testBadInitialization(999, "ICU Error: 1");
testBadInitialization("0#0", "ICU Error: 65792");
testBadInitialization("##  ##", "ICU Error: 65555");
testBadInitialization("##abcd##", "ICU Error: 65555");
