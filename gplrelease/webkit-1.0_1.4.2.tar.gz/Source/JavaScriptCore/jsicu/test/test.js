// a test JavaScript fragment to generate the first 20 numbers in
// the Fibonacci series as an array

var result = [1, 1];

for (var i = 2; i < 20; i++) {
    result[i] = result[i - 2] + result[i - 1];
    testPrint(result[i]);
}

testPrint("Now is the time for all good men to come to the aid of their country", 47, true);

result;
