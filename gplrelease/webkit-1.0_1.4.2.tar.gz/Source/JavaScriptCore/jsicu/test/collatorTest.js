/*
 * collatorTest.js
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
 
// utility function for cloning an array (Array.prototype.sort() sorts in place, and I couldn't
// find a built-in function for cloning an object)
function copyArray(a) {
    var result = new Array();
    for (var i = 0; i < a.length; i++) {
        result[i] = a[i];
    }
    return result;
}

var TEST_LIST = [ "bim", "bam", "bom", "bum", "b", "bm", "boom", "bzm", "Bam", "BAM", "baam", "baem", "b\u00e4m", "b\u00e1m", "b\u00e1em", "ba\u00e9m" ];
var BOGUS_TEST_LIST = [ 5, "wahoo", "5", "null", "", null, undefined, { foo: 1, bar: 3 }, "undefined" ];
var SORTED_BOGUS_TEST_LIST = [ "", null, {"foo":1, "bar":3}, 5, "5", "null", "undefined", "wahoo", undefined ];

function testCollator(message, collator, expectedPropertyValues, expectedSortResults, expectedBamResults, expectedBaemResults) {
    assertEqual(message + ".options", JSON.stringify(collator.options), JSON.stringify(expectedPropertyValues.options));
    assertEqual(message + ".locale", collator.locale.locale, expectedPropertyValues.locale);

    var sorted = copyArray(TEST_LIST).sort(function(a, b) { return collator.compare(a, b); } );
    var bams = TEST_LIST.filter(function(a) { return collator.compare(a, "bam") == 0; } );
    var baems = TEST_LIST.filter(function(a) { return collator.compare(a, "baem") == 0; } );
    
    assertEqual(message + ".sort", sorted.toString(), expectedSortResults.toString());
    assertEqual(message + ".find(\"bam\")", bams.toString(), expectedBamResults.toString());
    assertEqual(message + ".find(\"baem\")", baems.toString(), expectedBaemResults.toString());
    
    var sortedBogusList = copyArray(BOGUS_TEST_LIST).sort(function(a, b) { return collator.compare(a, b); } );
    assertEqual(message + ".sort(bogus)", sortedBogusList.toString(), SORTED_BOGUS_TEST_LIST.toString());
}

// test the default collator
testCollator("new Collator()", new Collator(),
    { options: { strength: 3 }, locale: "root" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "bam", "Bam", "BAM", "b\u00e1m", "b\u00e4m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam" ],
    [ "baem" ]
);
testCollator("new Collator( { strength: 1 } )", new Collator( { strength: 1 } ),
    { options: { strength: 1 }, locale: "root" },
    [ "b", "baam", "baem", "b\u00e1em", "ba\u00e9m", "bam", "Bam", "BAM", "b\u00e4m", "b\u00e1m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam", "Bam", "BAM", "b\u00e4m", "b\u00e1m" ],
    [ "baem", "b\u00e1em", "ba\u00e9m" ]
);
testCollator("new Collator( { strength: 2 } )", new Collator( { strength: 2 } ),
    { options: { strength: 2 }, locale: "root" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "bam", "Bam", "BAM", "b\u00e1m", "b\u00e4m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam", "Bam", "BAM" ],
    [ "baem" ]
);
testCollator("new Collator( { strength: 3 } )", new Collator( { strength: 3 } ),
    { options: { strength: 3 }, locale: "root" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "bam", "Bam", "BAM", "b\u00e1m", "b\u00e4m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam" ],
    [ "baem" ]
);
testCollator("new Collator( { strength: 4 } )", new Collator( { strength: 4 } ),
    { options: { strength: 4 }, locale: "root" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "bam", "Bam", "BAM", "b\u00e1m", "b\u00e4m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam" ],
    [ "baem" ]
);
testCollator("new Collator( { strength: 5 } )", new Collator( { strength: 5 } ),
    { options: { strength: 5 }, locale: "root" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "bam", "Bam", "BAM", "b\u00e1m", "b\u00e4m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam" ],
    [ "baem" ]
);

// test the German collator
testCollator("new Collator( { strength: 1 }, new Locale(\"de-DE-u-co-phonebk\"))",
    new Collator( { strength: 1 }, new Locale("de-DE-u-co-phonebk")),
    { options: { strength: 1 }, locale: "de" },
    [ "b", "baam", "baem", "b\u00e4m", "b\u00e1em", "ba\u00e9m", "bam", "Bam", "BAM", "b\u00e1m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam", "Bam", "BAM", "b\u00e1m" ],
    [ "baem", "b\u00e4m", "b\u00e1em", "ba\u00e9m" ]
);
testCollator("new Collator( { strength: 2 }, new Locale(\"de-DE-u-co-phonebk\"))",
    new Collator( { strength: 2 }, new Locale("de-DE-u-co-phonebk")),
    { options: { strength: 2 }, locale: "de" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "b\u00e4m", "bam", "Bam", "BAM", "b\u00e1m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam", "Bam", "BAM" ],
    [ "baem" ]
);
testCollator("new Collator( { strength: 3 }, new Locale(\"de-DE-u-co-phonebk\"))",
    new Collator( { strength: 3 }, new Locale("de-DE-u-co-phonebk")),
    { options: { strength: 3 }, locale: "de" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "b\u00e4m", "bam", "Bam", "BAM", "b\u00e1m", "bim", "bm", "bom", "boom", "bum", "bzm" ],
    [ "bam" ],
    [ "baem" ]
);

// test the Swedish collator
testCollator("new Collator( { strength: 1 }, new Locale(\"sv-se\"))", new Collator( { strength: 1 }, new Locale("sv-se")),
    { options: { strength: 1 }, locale: "sv" },
    [ "b", "baam", "baem", "b\u00e1em", "ba\u00e9m", "bam", "Bam", "BAM", "b\u00e1m", "bim", "bm", "bom", "boom", "bum", "bzm", "b\u00e4m" ],
    [ "bam", "Bam", "BAM", "b\u00e1m" ],
    [ "baem", "b\u00e1em", "ba\u00e9m" ]
);
testCollator("new Collator( { strength: 2 }, new Locale(\"sv-se\"))", new Collator( { strength: 2 }, new Locale("sv-se")),
    { options: { strength: 2 }, locale: "sv" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "bam", "Bam", "BAM", "b\u00e1m", "bim", "bm", "bom", "boom", "bum", "bzm", "b\u00e4m" ],
    [ "bam", "Bam", "BAM" ],
    [ "baem" ]
);
testCollator("new Collator( { strength: 3 }, new Locale(\"sv-se\"))", new Collator( { strength: 3 }, new Locale("sv-se")),
    { options: { strength: 3 }, locale: "sv" },
    [ "b", "baam", "baem", "ba\u00e9m", "b\u00e1em", "bam", "Bam", "BAM", "b\u00e1m", "bim", "bm", "bom", "boom", "bum", "bzm", "b\u00e4m" ],
    [ "bam" ],
    [ "baem" ]
);
