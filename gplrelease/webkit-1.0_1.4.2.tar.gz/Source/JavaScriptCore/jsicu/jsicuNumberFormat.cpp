/*
 * jsicuNumberFormat.cpp
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
#include "jsicuNumberFormat.h"

#include "jsicu.h"
#include "jsicuLocale.h"

#include "unicode/numfmt.h"
#include "unicode/decimfmt.h"
#include "unicode/dcfmtsym.h"
#include "unicode/unistr.h"
#include "unicode/fmtable.h"
#include "unicode/locid.h"

#include "wtf/Assertions.h"

#include <iostream> // debugging only

using namespace std;

namespace jsicu {

//======================================================================================
// NumberFormat JS class definition and installation code
//======================================================================================
/**
 * An array of JSStaticValue records describing the properties of the NumberFormat object.
 */
JSStaticValue numberFormatProperties[] = {
    { "pattern", getNFPatternCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "currency", getCurrencyCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "locale", getNFLocaleCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    // (there's also a "style" property, which is implemented in numberFormatConstructorCallback() )
    { NULL, NULL, NULL, 0 }
};

/**
 * An array of JSStaticFunction records describing the methods of the NumberFormat object.
 */
JSStaticFunction numberFormatMethods[] = {
    { "format", formatNumberCallback, 0 },
    { "parse", parseNumberCallback, 0 },
    { NULL, NULL, 0 }
};

// NOTE: This implementation isn't thread-safe-- do we care?
static JSClassRef numberFormatClass = NULL;

/**
 * Returns the JSClassRef describing the methods and properties of the
 * NumberFormat object. (The NumberFormat JSClassRef is a singleton object,
 * and this function lazy-creates it.)
 */
static JSClassRef getNumberFormatClass() {
    if (numberFormatClass == NULL) {
        JSClassDefinition nfClassDef = kJSClassDefinitionEmpty;
        nfClassDef.className = "NumberFormat";
        nfClassDef.initialize = initializeNumberFormatCallback;
        nfClassDef.finalize = finalizeNumberFormatCallback;
        nfClassDef.staticValues = numberFormatProperties;
        nfClassDef.staticFunctions = numberFormatMethods;

        numberFormatClass = JSClassCreate(&nfClassDef);
    }
    return numberFormatClass;
}

//======================================================================================
// Install function for NumberFormat API
//======================================================================================
/**
 * Called by insertICUWrapperIntoGlobalContext() to install the NumberFormat
 * constructor into the execution context's global object.
 */
void installNumberFormatObject(JSGlobalContextRef context, JSObjectRef globalObject) {
    JSObjectRef constructor = addConstructor(context, globalObject, "NumberFormat", getNumberFormatClass(),
            numberFormatConstructorCallback);

    // the NumberFormat constructor has a member called Style, which has
    // several members with numeric values-- it's essentially an enum with
    // constants for the various canned NumberFormat types
    JSObjectRef styleObject = JSObjectMake(context, NULL, NULL);
    addProperty(context, styleObject, "INTEGER", JSValueMakeNumber(context, -1.0));
    addProperty(context, styleObject, "DECIMAL", JSValueMakeNumber(context, 0.0));
    addProperty(context, styleObject, "CURRENCY", JSValueMakeNumber(context, 1.0));
    addProperty(context, styleObject, "PERCENT", JSValueMakeNumber(context, 2.0));
    addProperty(context, styleObject, "SCIENTIFIC", JSValueMakeNumber(context, 3.0));
    addProperty(context, styleObject, "ISO_CURRENCY", JSValueMakeNumber(context, 4.0));

    addProperty(context, constructor, "Style", styleObject);
}

//======================================================================================
// Utility functions
//======================================================================================
/**
 * Extracts the actual NumberFormat object from the specified object's
 * private-data area and throws an exception if the specified object
 * isn't a NumberFormat object.
 * @param context The JavaScript execution context
 * @param jsnf The JavaScript object to extract the internal
 *             NumberFormat object from.
 * @param exception Filled in with a JavaScript Error object if the specified
 *                  object isn't a NumberFormat object or doesn't have the
 *                  internal ICU NumberFormat object.
 */
static NumberFormat* extractNumberFormat(JSContextRef context, JSObjectRef jsnf, JSValueRef* exception) {
    NumberFormat* nf = NULL;
    if (context == NULL || JSValueIsObjectOfClass(context, jsnf, getNumberFormatClass())) {
        nf = (NumberFormat*)JSObjectGetPrivate(jsnf);
    }

    if (nf == NULL && exception != NULL) {
        // JSObjectMakeError wants an array of arguments (with a separate length
        // parameter), but the Error constructor only takes one argument, so we
        // just make a one-element array for the arguments
        JSValueRef exceptArgs[1];
        exceptArgs[0] = makeStringValue(context, "NumberFormat object does not contain implementation object");
        *exception = JSObjectMakeError(context, 1, exceptArgs, exception);
        LOG_ERROR("ICU NumberFormat not found in JS NumberFormat");
    }
    return nf;
}
//======================================================================================
// Callback (implementation) functions for NumberFormat API
//======================================================================================
/**
 * The implementation of the NumberFormat constructor.  The NumberFormat constructor
 * takes up to three arguments, all optional:
 * - pattern or style: This is either a string, which is interpreted as an
 *   ICU DecimalFormat pattern (for more info, see the ICU documentation),
 *   or a constant from NumberFormat.Style specifying a canned style.  If
 *   omitted, defaults to NumberFormat.Style.DECIMAL.
 * - currency: A three-letter ISO 4217 currency code.  This is ignored if
 *   the formatter isn't a currency formatter.  If omitted, and the
 *   formatter is a currency formatter, defaults to the default currency
 *   for the specified locale.
 * - locale: A Locale object specifying the appropriate locale to use
 *   for the NumberFormat.  If omitted, defaults to the system default locale.
 */
JSObjectRef numberFormatConstructorCallback(JSContextRef context, JSObjectRef constructorObj, size_t argumentCount,
        const JSValueRef arguments[], JSValueRef* exception) {
    JSValueRef styleOrPattern = (argumentCount >= 1) ? arguments[0] : JSValueMakeNumber(context, 0.0);
    JSValueRef jsCurrency = (argumentCount >= 2) ? arguments[1] : NULL;
    JSValueRef jsLocale = (argumentCount >= 3) ? arguments[2] : NULL;

    // get the currency string out of the argument list (we use NULL
    // to represent the default currency here)
    UnicodeString currency;
    if (jsCurrency != NULL) {
        unicodeStringFromJSValue(context, jsCurrency, currency);
    }
    if (currency.length() != 3) {
        currency.remove();  // set back to the empty string
    }

    // get the locale out of the argument list
    Locale locale = makeICULocaleObject(context, jsLocale, exception);

    // create the actual NumberFormat object: If the styleOrPattern
    // parameter is a number, we interpret it as a style ID;
    // otherwise, we convert it into a string and interpret it
    // as a DecimalFormat pattern
    int style = UNUM_DECIMAL;
    UErrorCode err = U_ZERO_ERROR;
    NumberFormat* nf = NULL;
    if (JSValueIsNumber(context, styleOrPattern)) {
        style = (int)JSValueToNumber(context, styleOrPattern, exception);
        if (style == -1) {
            // special-case code to handle the INTEGER style, which doesn't
            // exist in the ICU API
            nf = NumberFormat::createInstance(locale, err);
            if (U_SUCCESS(err)) {
                nf->setMaximumFractionDigits(0);
                nf->setParseIntegerOnly(true);
            }
        } else {
            nf = NumberFormat::createInstance(locale, (UNumberFormatStyle)style, err);
        }
    } else {
        UnicodeString pattern;
        unicodeStringFromJSValue(context, styleOrPattern, pattern);
        nf = new DecimalFormat(pattern, new DecimalFormatSymbols(locale, err), err);
    }

    // set the currency on the NumberFormat if the user specified one
    if (!currency.isEmpty()) {
        nf->setCurrency(currency.getTerminatedBuffer(), err);
    }

    // dump out early (and throw an exception) if ICU
    // couldn't create the NumberFormat
    if (checkICUError(err, context, exception)) {
        return NULL;
    }

    // create the JavaScript NumberFormat object-- the ICU NumberFormat
    // object lives in its private-data area
    JSObjectRef newNF = JSObjectMake(context, getNumberFormatClass(), nf);

    // the ICU NumberFormat classes don't have getStyle() methods on them,
    // so we just stash the style in an ordinary JavaScript property
    // at construction time
    addProperty(context, newNF, "style", JSValueMakeNumber(context, style),
            kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete);

    return newNF;
}

/**
 * Called by the JS runtime when a new NumberFormat object is created.
 */
void initializeNumberFormatCallback(JSContextRef context, JSObjectRef newNF) {
    // private data object is created in constructor callback
}

/**
 * Called by the JS runtime right before a NumberFormat object is
 * released by the garbage collector.  This function releases the
 * ICU NumberFormat object, which is stored in the object's
 * private-data area.
 */
void finalizeNumberFormatCallback(JSObjectRef jsnf) {
    NumberFormat* nf = extractNumberFormat(NULL, jsnf, NULL);
    if (nf != NULL) {
        delete nf;
    }
}

/**
 * Implements the getProperty logic for the NumberFormat object's "pattern" property.
 */
JSValueRef getNFPatternCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    NumberFormat* nf = extractNumberFormat(context, thisObject, exception);

    // only instances of DecimalFormat have a pattern; this function
    // returns the empty string if the underlying NumberFormat isn't
    // a DecimalFormat.  In practice, it should always be a
    // DecimalFormat.
    if (nf->getDynamicClassID() == DecimalFormat::getStaticClassID()) {
        DecimalFormat* df = (DecimalFormat*)nf;
        UnicodeString pattern;
        df->toPattern(pattern);
        return makeUStringValue(context, pattern);
    } else {
        return makeStringValue(context, "");
    }
}

/**
 * Implements the getProperty logic for the NumberFormat object's "currency" property.
 */
JSValueRef getCurrencyCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    NumberFormat* nf = extractNumberFormat(context, thisObject, exception);
    return makeUStringValue(context, nf->getCurrency());
}

/**
 * Implements the getProperty logic for the NumberFormat object's "locale" property.
 * <p>NOTE: This is NOT the "locale" value the caller passed to the constructor; it's
 * the actual locale ID of the underlying resources used by this object-- this may
 * be a more general locale ID than specified, or it might be a fallback locale
 */
JSValueRef getNFLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    NumberFormat* nf = extractNumberFormat(context, thisObject, exception);
    if (nf != NULL) {
        UErrorCode err = U_ZERO_ERROR;
        string localeID = nf->getLocaleID(ULOC_ACTUAL_LOCALE, err);
        if (localeID.empty() && nf->getDynamicClassID() == DecimalFormat::getStaticClassID()) {
            DecimalFormat* df = (DecimalFormat*)nf;
            localeID = df->getDecimalFormatSymbols()->getLocale(ULOC_ACTUAL_LOCALE, err).getName();
        }
        if (!checkICUError(err, context, exception)) {
            return makeJSLocaleObject(context, localeID.c_str(), exception);
        } else {
            // if we get here, ICU is throwing an exception
            return NULL;
        }
    } else {
        return NULL;
    }
}

/**
 * Implements the NumberFormat.prototype.format() method.
 * The first argument is converted to a string using the internal
 * ICU NumberFormat object, if possible.
 */
JSValueRef formatNumberCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    if (argumentCount > 0 && JSValueIsNumber(context, arguments[0])) {
        // if the first argument to format() is a Number, use the underlying
        // NumberFormat object to convert it into a string and return
        // that string.
        NumberFormat* nf = extractNumberFormat(context, thisObject, exception);
        double number = JSValueToNumber(context, arguments[0], exception);
        UnicodeString result;
        nf->format(number, result);
        return makeUStringValue(context, result);
    } else {
        // if the first argument is anything else, or is missing, just use
        // JavaScript's internal ToString() to produce a string (a missing
        // argument is the same as "undefined")
        JSValueRef value = (argumentCount > 0) ? arguments[0] : JSValueMakeUndefined(context);
        JSStringRef str = JSValueToStringCopy(context, value, exception);
        JSValueRef result = JSValueMakeString(context, str);
        JSStringRelease(str);
        return result;
    }
}

/**
 * Implements the NumberFormat.prototype.parse() method.  The first argument,
 * if there is one, is converted to a string, and the underlying ICU
 * NumberFormat object is used to convert it into a number.  If there's
 * no argument, or the string can't be parsed as a number, this function
 * returns "undefined".
 */
JSValueRef parseNumberCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    UnicodeString s;
    if (argumentCount > 0) {
        unicodeStringFromJSValue(context, arguments[0], s);
    }
    NumberFormat* nf = extractNumberFormat(context, thisObject, exception);
    Formattable tempResult;
    UErrorCode err = U_ZERO_ERROR;
    nf->parse(s, tempResult, err);
    double result = tempResult.getDouble(err);
    if (err == U_INVALID_FORMAT_ERROR) {
        // if we get a parsing error, don't throw an exception;
        // just return undefined
        return JSValueMakeUndefined(context);
    }
    if (checkICUError(err, context, exception)) {
        // if we get any other ICU error, throw an exception
        return JSValueMakeUndefined(context);
    } else {
        return JSValueMakeNumber(context, result);
    }
}

} // namespace jsicu
