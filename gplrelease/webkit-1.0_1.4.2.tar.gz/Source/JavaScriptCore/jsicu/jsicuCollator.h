/*
 * jsicuCollator.h
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifndef JSICUCOLLATOR_H_
#define JSICUCOLLATOR_H_

#include "JavaScriptCore/JavaScript.h"

#include <string>

namespace jsicu {

// function to install the Collator object into the JS execution context
extern void installCollatorObject(JSGlobalContextRef context, JSObjectRef globalObject);

//--------------------------------------
// callback (implementation) functions
//--------------------------------------

// constructor, initializer, finalizer
extern JSObjectRef collatorConstructorCallback(JSContextRef context, JSObjectRef constructorObj,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern void initializeCollatorCallback(JSContextRef context, JSObjectRef newColl);
extern void finalizeCollatorCallback(JSObjectRef locale);

// property getters
extern JSValueRef getOptionsCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getCollLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);

// Collator methods
extern JSValueRef compareCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);

} // namespace jsicu

#endif // JSICUCOLLATOR_H_
