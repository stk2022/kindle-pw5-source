/*
 * jsicuDateFormat.cpp
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
#include "jsicuDateFormat.h"

#include "jsicu.h"
#include "jsicuLocale.h"

#include "unicode/datefmt.h"
#include "unicode/smpdtfmt.h"
#include "unicode/timezone.h"
#include "unicode/dtfmtsym.h"
#include "unicode/locid.h"

#include "wtf/Assertions.h"

#include <iostream> // debugging only

using namespace std;

namespace jsicu {

//======================================================================================
// DateTimeFormat JS class definition and installation code
//======================================================================================
/**
 * An array of JSStaticValue records describing the properties of the DateTimeFormat object.
 */
JSStaticValue dateFormatProperties[] = {
    { "pattern", getDFPatternCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "timeZone", getTimeZoneCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "locale", getDFLocaleCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { NULL, NULL, NULL, 0 }
};

/**
 * An array of JSStaticFunction records describing the methods of the DateTimeFormat object.
 */
JSStaticFunction dateFormatMethods[] = {
    { "format", formatDateCallback, 0 },
    { "parse", parseDateCallback, 0 },
    { NULL, NULL, 0 }
};

// NOTE: This implementation isn't thread-safe-- do we care?
static JSClassRef dateFormatClass = NULL;

/**
 * Returns the JSClassRef describing the methods and properties of the
 * DateTimeFormat object. (The DateTimeFormat JSClassRef is a singleton object,
 * and this function lazy-creates it.)
 */
static JSClassRef getDateFormatClass() {
    if (dateFormatClass == NULL) {
        JSClassDefinition nfClassDef = kJSClassDefinitionEmpty;
        nfClassDef.className = "DateTimeFormat";
        nfClassDef.initialize = initializeDateFormatCallback;
        nfClassDef.finalize = finalizeDateFormatCallback;
        nfClassDef.staticValues = dateFormatProperties;
        nfClassDef.staticFunctions = dateFormatMethods;

        dateFormatClass = JSClassCreate(&nfClassDef);
    }
    return dateFormatClass;
}

//======================================================================================
// Install function for DateTimeFormat API
//======================================================================================
/**
 * Called by insertICUWrapperIntoGlobalContext() to install the DateTimeFormat
 * constructor into the execution context's global object.
 */
void installDateFormatObject(JSGlobalContextRef context, JSObjectRef globalObject) {
    addConstructor(context, globalObject, "DateTimeFormat", getDateFormatClass(),
            dateFormatConstructorCallback);
}

//======================================================================================
// Utility functions
//======================================================================================
/**
 * Extracts the actual ICU DateFormat object from the specified object's
 * private-data area and throws an exception if the specified object
 * isn't a DateFormat object.
 * @param context The JavaScript execution context
 * @param jsdtf The JavaScript object to extract the internal
 *              DateFormat object from.
 * @param exception Filled in with a JavaScript Error object if the specified
 *                  object isn't a DateTimeFormat object or doesn't have the
 *                  internal ICU DateFormat object.
 */
static DateFormat* extractDateFormat(JSContextRef context, JSObjectRef jsdtf, JSValueRef* exception) {
    DateFormat* df = NULL;
    if (context == NULL || JSValueIsObjectOfClass(context, jsdtf, getDateFormatClass())) {
        df = (DateFormat*)JSObjectGetPrivate(jsdtf);
    }

    if (df == NULL && exception != NULL) {
        // JSObjectMakeError wants an array of arguments (with a separate length
        // parameter), but the Error constructor only takes one argument, so we
        // just make a one-element array for the arguments
        JSValueRef exceptArgs[1];
        exceptArgs[0] = makeStringValue(context, "DateTimeFormat object does not contain implementation object");
        *exception = JSObjectMakeError(context, 1, exceptArgs, exception);
        LOG_ERROR("ICU DateFormat not found in JS DateTimeFormat");
    }
    return df;
}

//======================================================================================
// Callback (implementation) functions for DateTimeFormat API
//======================================================================================
/**
 * The implementation of the DateTimeFormat constructor.
 * The DateTimeFormat constructor takes three arguments, all of
 * which are optional:
 * - styleOrPattern: This is a string, which is either an ICU DateFormat
 *   pattern or the name of one of the canned formatters: date, time,
 *   short, medium, long, full, short-date, medium-date, long-date,
 *   full-date, short-time, medium-time, long-time, or full-time.
 *   (If "date" and "time" are both omitted, you get a formatter
 *   that formats both date and time; if the short/medium/long/full
 *   piece is missing, you get the ICU default.)
 * - timeZone: The ICU time zone ID, which is usually in the form
 *   "region/city" (e.g., "America/Los_Angeles" or "Asia/Tokyo").
 *   "UTC" means Coordinated Universal Time; "localtime" is the
 *   system default time zone ("localtime" is the default).
 * - locale: The locale to use for formatting; if omitted, this
 *   is the system default locale.
 */
JSObjectRef dateFormatConstructorCallback(JSContextRef context, JSObjectRef constructorObj, size_t argumentCount,
        const JSValueRef arguments[], JSValueRef* exception) {
    JSValueRef jsStyleOrPattern = (argumentCount >= 1) ? arguments[0] : NULL;
    JSValueRef jsTimeZone = (argumentCount >= 2) ? arguments[1] : NULL;
    JSValueRef jsLocale = (argumentCount >= 3) ? arguments[2] : NULL;

    // get the time zone name out of the argument list
    UnicodeString timeZoneName;
    if (jsTimeZone != NULL) {
        unicodeStringFromJSValue(context, jsTimeZone, timeZoneName);
    }

    // get the locale out of the argument list
    Locale locale = makeICULocaleObject(context, jsLocale, exception);

    // create the actual ICU DateFormat object: the styleOrPattern
    // argument can either be a SimpleDateFormat pattern or the
    // name of a canned format
    UnicodeString styleOrPattern;
    if (jsStyleOrPattern != NULL) {
        unicodeStringFromJSValue(context, jsStyleOrPattern, styleOrPattern);
    }
    DateFormat::EStyle style = DateFormat::kNone;
    DateFormat* df = NULL;
    if (styleOrPattern.isEmpty() || styleOrPattern == "date" || styleOrPattern == "time") {
        style = DateFormat::kDefault;
    } else if (styleOrPattern.startsWith("short")) {
        style = DateFormat::kShort;
    } else if (styleOrPattern.startsWith("medium")) {
        style = DateFormat::kMedium;
    } else if (styleOrPattern.startsWith("long")) {
        style = DateFormat::kLong;
    } else if (styleOrPattern.startsWith("full")) {
        style = DateFormat::kFull;
    }
    if (style != DateFormat::kNone) {
        // if we get here, the styleOrFormat argument was the
        // name of a canned style, so we can use one of the
        // factory methods on DateFormat to constructor
        // our DateFormat object
        if (styleOrPattern.endsWith("date")) {
            df = DateFormat::createDateInstance(style, locale);
        } else if (styleOrPattern.endsWith("time")) {
            df = DateFormat::createTimeInstance(style, locale);
        } else {
            df = DateFormat::createDateTimeInstance(style, style, locale);
        }
    } else {
        // if we get to here, the styleOrPattern argument
        // is a (possibly illegal) SimpleDateFormat pattern,
        // so we create our DateFormat using the SimpleDateFormat
        // constructor, taking care to catch any resulting errors
        // and throw corresponding exceptions
        UErrorCode err = U_ZERO_ERROR;
        df = new SimpleDateFormat(styleOrPattern, locale, err);
        if (checkICUError(err, context, exception)) {
            delete df;
            return NULL;    // checkICUError is throwing an exception
        }
    }

    // if we successfully constructed a DateFormat and the user
    // specified a time zone, set the DateFormat's time zone
    if (!timeZoneName.isEmpty() && timeZoneName != "localtime") {
        df->adoptTimeZone(TimeZone::createTimeZone(timeZoneName));
    }

    // create the JavaScript NumberFormat object-- the ICU NumberFormat
    // object lives in its private-data area
    JSObjectRef newDTF = JSObjectMake(context, getDateFormatClass(), df);

    return newDTF;
}

/**
 * Called by the JS runtime when a new DateTimeFormat object is created.
 */
void initializeDateFormatCallback(JSContextRef context, JSObjectRef newDTF) {
    // private data object is created in constructor callback
}

/**
 * Called by the JS runtime right before a DateTimeFormat object is
 * released by the garbage collector.  This function releases the
 * ICU DateFormat object, which is stored in the object's
 * private-data area.
 */
void finalizeDateFormatCallback(JSObjectRef jsdtf) {
    DateFormat* df = extractDateFormat(NULL, jsdtf, NULL);
    if (df != NULL) {
        delete df;
    }
}

/**
 * Implements the getProperty logic for the DateTimeFormat object's "format" property.
 */
JSValueRef getDFPatternCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    DateFormat* df = extractDateFormat(context, thisObject, exception);

    // only instances of SimpleDateFormat have a pattern; this function
    // returns the empty string if the underlying DateFormat isn't
    // a SimpleDateFormat.  In practice, it'll always be a
    // SimpleDateFormat.
    if (df->getDynamicClassID() == SimpleDateFormat::getStaticClassID()) {
        SimpleDateFormat* sdf = (SimpleDateFormat*)df;
        UnicodeString pattern;
        sdf->toPattern(pattern);
        return makeUStringValue(context, pattern);
    } else {
        return makeStringValue(context, "");
    }
}

/**
 * Implements the getProperty logic for the DateTimeFormat object's "timeZone" property.
 */
JSValueRef getTimeZoneCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    DateFormat* df = extractDateFormat(context, thisObject, exception);
    if (df != NULL) {
        UnicodeString zoneName;
        df->getTimeZone().getID(zoneName);
        return makeUStringValue(context, zoneName);
    } else {
        return NULL;
        // if we get here, extractDateFormat() is throwing an exception
    }
}

/**
 * Implements the getProperty logic for the DateTimeFormat object's "locale" property.
 * <p>NOTE: This is NOT the "locale" value the caller passed to the constructor; it's
 * the actual locale ID of the underlying resources used by this object-- this may
 * be a more general locale ID than specified, or it might be a fallback locale
 */
JSValueRef getDFLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    DateFormat* df = extractDateFormat(context, thisObject, exception);
    if (df != NULL) {
        UErrorCode err = U_ZERO_ERROR;
        string localeID = df->getLocaleID(ULOC_ACTUAL_LOCALE, err);
        if (localeID.empty() && df->getDynamicClassID() == SimpleDateFormat::getStaticClassID()) {
            SimpleDateFormat* sdf = (SimpleDateFormat*)df;
            localeID = sdf->getDateFormatSymbols()->getLocale(ULOC_ACTUAL_LOCALE, err).getName();
        }
        if (!checkICUError(err, context, exception)) {
            return makeJSLocaleObject(context, localeID.c_str(), exception);
        } else {
            // if we get here, ICU is throwing an exception
            return NULL;
        }
    } else {
        return NULL;
    }
}

/**
 * Implements the DateTimeFormat.prototype.format() method.
 * Takes a JavaScript Date object and returns a String containing the
 * formatted version of the specified date.  If the input argument
 * is omitted or isn't a Date, this function converts the input
 * object to a string using the default ToString() operation.
 */
JSValueRef formatDateCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    UDate date;
    if (argumentCount >= 1 && isJSDate(context, arguments[0])) {
        date = uDateFromJSDate(context, arguments[0]);

        DateFormat* df = extractDateFormat(context, thisObject, exception);
        if (df != NULL) {
            UnicodeString result;
            df->format(date, result);
            return makeUStringValue(context, result);
        } else {
            return NULL;
            // (if we get here, extractDateFormat() is throwing an exception)
        }
    } else {
        // if the first argument is not a Date object, or is missing, just use
        // JavaScript's internal ToString() to produce a string (a missing
        // argument is the same as "undefined")
        JSValueRef value = (argumentCount > 0) ? arguments[0] : JSValueMakeUndefined(context);
        JSStringRef str = JSValueToStringCopy(context, value, exception);
        JSValueRef result = JSValueMakeString(context, str);
        JSStringRelease(str);
        return result;
    }
}

/**
 * Implements the DateTimeFormat.prototype.parse() method.
 * Converts the specified string into a Date object using the
 * same procedures (in reverse) that this formatter uses to
 * convert dates to strings.  If the input argument is omitted,
 * isn't a string, or can't be parsed properly, this function
 * returns the undefined value.
 */
JSValueRef parseDateCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    UnicodeString s;
    if (argumentCount > 0) {
        unicodeStringFromJSValue(context, arguments[0], s);
    }
    UDate date;
    DateFormat* df = extractDateFormat(context, thisObject, exception);
    UErrorCode err = U_ZERO_ERROR;
    date = df->parse(s, err);
    if (err == U_ILLEGAL_ARGUMENT_ERROR) {
        // if we get a parsing error, don't throw an exception;
        // just return undefined
        return JSValueMakeUndefined(context);
    }
    if (checkICUError(err, context, exception)) {
        // if we get any other ICU error, throw an exception
        return JSValueMakeUndefined(context);
    } else {
        JSValueRef jsDate[1];
        jsDate[0] = JSValueMakeNumber(context, date);
        return JSObjectMakeDate(context, 1, jsDate, exception);
    }
}

} // namespace jsicu
