/*
 * jsicuCollator.cpp
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
#include "jsicuCollator.h"

#include "jsicu.h"
#include "jsicuLocale.h"

#include "unicode/coll.h"

#include "wtf/Assertions.h"

#include <iostream> // debugging only

using namespace std;

namespace jsicu {

//======================================================================================
// Collator JS class definition and installation code
//======================================================================================
/**
 * An array of JSStaticValue records describing the properties of the Collator object.
 */
JSStaticValue collatorProperties[] = {
    { "options", getOptionsCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "locale", getCollLocaleCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { NULL, NULL, NULL, 0 }
};

/**
 * An array of JSStaticFunction records describing the methods of the Collator object.
 */
JSStaticFunction collatorMethods[] = {
    { "compare", compareCallback, 0 },
    { NULL, NULL, 0 }
};

// NOTE: This implementation isn't thread-safe-- do we care?
static JSClassRef collatorClass = NULL;

/**
 * Returns the JSClassRef describing the methods and properties of the
 * Collator object. (The Collator JSClassRef is a singleton object,
 * and this function lazy-creates it.)
 */
static JSClassRef getCollatorClass() {
    if (collatorClass == NULL) {
        JSClassDefinition collClassDef = kJSClassDefinitionEmpty;
        collClassDef.className = "Collator";
        collClassDef.initialize = initializeCollatorCallback;
        collClassDef.finalize = finalizeCollatorCallback;
        collClassDef.staticValues = collatorProperties;
        collClassDef.staticFunctions = collatorMethods;

        collatorClass = JSClassCreate(&collClassDef);
    }
    return collatorClass;
}

//======================================================================================
// Install function for Collator API
//======================================================================================
/**
 * Called by insertICUWrapperIntoGlobalContext() to install the Collator
 * constructor into the execution context's global object.
 */
void installCollatorObject(JSGlobalContextRef context, JSObjectRef globalObject) {
    addConstructor(context, globalObject, "Collator", getCollatorClass(),
            collatorConstructorCallback);
}

//======================================================================================
// Utility functions
//======================================================================================
/**
 * Extracts the actual ICU Collator object from the specified object's
 * private-data area and throws an exception if the specified object
 * isn't a Collator object.
 * @param context The JavaScript execution context
 * @param jsColl The JavaScript object to extract the internal
 *                 Collator object from.
 * @param exception Filled in with a JavaScript Error object if the specified
 *                  object isn't a Collator object or doesn't have the
 *                  internal ICU Collator object.
 */
static Collator* extractCollator(JSContextRef context, JSObjectRef jsColl, JSValueRef* exception) {
    Collator* coll = NULL;
    if (context == NULL || JSValueIsObjectOfClass(context, jsColl, getCollatorClass())) {
        coll = (Collator*)JSObjectGetPrivate(jsColl);
    }

    if (coll == NULL && exception != NULL) {
        // JSObjectMakeError wants an array of arguments (with a separate length
        // parameter), but the Error constructor only takes one argument, so we
        // just make a one-element array for the arguments
        JSValueRef exceptArgs[1];
        exceptArgs[0] = makeStringValue(context, "Collator object does not contain implementation object");
        *exception = JSObjectMakeError(context, 1, exceptArgs, exception);
        LOG_ERROR("ICU Collator not found in JS Collator");
    }
    return coll;
}

//======================================================================================
// Callback (implementation) functions for Collator API
//======================================================================================
/**
 * The implementation of the Collator constructor.
 * The Collator constructor takes two parameters, both of which are optional:
 * - options: This is an ordinary JavaScript Object; its properties specify
 *            the names and values of options to set on the Collator object.
 *            Currently, only one option is specified:
 *            - strength: This is an integer from 1 to 5 specifying the
 *                        collation strength: 1 is primary, 2 is secondary,
 *                        3 is tertiary, 4 is quaternary, and 5 is identical.
 *                        If not specified, or if the integer is out of range,
 *                        this defaults to tertiary strength.
 * - locale: A Locale object specifying the locale for the collator.  If not
 *           specified, this defaults to the system default locale.
 */
JSObjectRef collatorConstructorCallback(JSContextRef context, JSObjectRef constructorObj, size_t argumentCount,
        const JSValueRef arguments[], JSValueRef* exception) {
    JSValueRef jsOptions = (argumentCount >= 1) ? arguments[0] : NULL;
    JSValueRef jsLocale = (argumentCount >= 2) ? arguments[1] : NULL;

    if (jsOptions == NULL) {
        JSObjectRef tempOptions = JSObjectMake(context, NULL, NULL);
        addProperty(context, tempOptions, "strength", JSValueMakeNumber(context, 3.0));
        jsOptions = tempOptions;
    }

    Locale locale = makeICULocaleObject(context, jsLocale, exception);

    UErrorCode err = U_ZERO_ERROR;
    Collator* coll = Collator::createInstance(locale, err);
    if (!checkICUError(err, context, exception) && JSValueIsObject(context, jsOptions)) {
        JSValueRef jsStrength = getProperty(context, JSValueToObject(context, jsOptions, exception), "strength");
        if (JSValueIsNumber(context, jsStrength)) {
            UErrorCode err = U_ZERO_ERROR;
            int strength = (int)(JSValueToNumber(context, jsStrength, exception));
            switch (strength) {
            case 1:
                coll->setAttribute(UCOL_STRENGTH, UCOL_PRIMARY, err);
                break;
            case 2:
                coll->setAttribute(UCOL_STRENGTH, UCOL_SECONDARY, err);
                break;
            case 3:
                coll->setAttribute(UCOL_STRENGTH, UCOL_TERTIARY, err);
                break;
            case 4:
                coll->setAttribute(UCOL_STRENGTH, UCOL_QUATERNARY, err);
                break;
            case 5:
                coll->setAttribute(UCOL_STRENGTH, UCOL_IDENTICAL, err);
                break;
            default:
                break;
            }
        }
        if (!checkICUError(err, context, exception)) {
            return JSObjectMake(context, getCollatorClass(), coll);
        } else {
            return NULL;
        }
    } else {
        return NULL;
    }
}

/**
 * Called by the JS runtime when a new Collator object is created.
 */
void initializeCollatorCallback(JSContextRef context, JSObjectRef newColl) {
    // private data object is created in constructor callback
}

/**
 * Called by the JS runtime right before a Collator object is
 * released by the garbage collector.  This function releases the
 * ICU Collator object, which is stored in the object's
 * private-data area.
 */
void finalizeCollatorCallback(JSObjectRef jsColl) {
    Collator* coll = extractCollator(NULL, jsColl, NULL);
    if (coll != NULL) {
        delete coll;
    }
}

/**
 * Implements the getProperty logic for the Collator object's "options" property.
 */
JSValueRef getOptionsCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    Collator* coll = extractCollator(context, thisObject, exception);
    if (coll == NULL) {
        return NULL;
    }

    UErrorCode err = U_ZERO_ERROR;
    UColAttributeValue strength = coll->getAttribute(UCOL_STRENGTH, err);
    int jsStrength;
    switch (strength) {
    case UCOL_PRIMARY:
        jsStrength = 1;
        break;
    case UCOL_SECONDARY:
        jsStrength = 2;
        break;
    case UCOL_TERTIARY:
        jsStrength = 3;
        break;
    case UCOL_QUATERNARY:
        jsStrength = 4;
        break;
    case UCOL_IDENTICAL:
        jsStrength = 5;
        break;
    default:
        break;
    }

    JSObjectRef jsOptions = JSObjectMake(context, NULL, NULL);
    addProperty(context, jsOptions, "strength", JSValueMakeNumber(context, jsStrength));
    return jsOptions;
}

/**
 * Implements the getProperty logic for the Collator object's "locale" property.
 * <p>NOTE: This is NOT the "locale" value the caller passed to the constructor; it's
 * the actual locale ID of the underlying resources used by this object-- this may
 * be a more general locale ID than specified, or it might be a fallback locale
 */
JSValueRef getCollLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    Collator* coll = extractCollator(context, thisObject, exception);
    if (coll != NULL) {
        UErrorCode err = U_ZERO_ERROR;
        Locale result = coll->getLocale(ULOC_ACTUAL_LOCALE, err);
        if (!checkICUError(err, context, exception)) {
            return makeJSLocaleObject(context, result.getName(), exception);
        }
    }
    return NULL;
}

/**
 * Implements the Collator.prototype.compare() method.
 * This function takes two arguments; if either is unspecified, it defaults to
 * "undefined".  Both arguments are converted to strings using the internal
 * JS ToString() operation and compared using the Collator's locale-specific
 * rules.
 * <p>The return value indicates which of the two arguments should come first
 * in a sorted list: a negative result means the first argument should come
 * first; a positive result means the second argument should come first.
 * Zero means the collator considers the two arguments "equivalent"; this is
 * useful mostly for implementing loose matching in search operations.
 * <p>This function treats null and undefined as equivalent to the empty
 * string for the purposes of comparison-- that is, any null or undefined
 * values will sort to the top of the list (rather than sorting with the
 * words "null" and "undefined").
 */
JSValueRef compareCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    Collator* coll = extractCollator(context, thisObject, exception);
    if (coll != NULL) {
        JSValueRef value1 = (argumentCount >= 1) ? arguments[0] : makeStringValue(context, "");
        JSValueRef value2 = (argumentCount >= 2) ? arguments[1] : makeStringValue(context, "");

        UnicodeString s1;
        UnicodeString s2;
        if (!JSValueIsUndefined(context, value1) && !JSValueIsNull(context, value1)) {
            unicodeStringFromJSValue(context, value1, s1);
        }
        if (!JSValueIsUndefined(context, value2) && !JSValueIsNull(context, value2)) {
            unicodeStringFromJSValue(context, value2, s2);
        }
        return JSValueMakeNumber(context, coll->compare(s1, s2));
    } else {
        return NULL;
    }
}

} // namespace jsicu
