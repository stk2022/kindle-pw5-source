/*
 * jsicuDateFormat.h
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifndef JSICUDATEFORMAT_H_
#define JSICUDATEFORMAT_H_

#include "JavaScriptCore/JavaScript.h"

#include <string>

namespace jsicu {

// function to install the DateFormat object into the JS execution context
extern void installDateFormatObject(JSGlobalContextRef context, JSObjectRef globalObject);

//--------------------------------------
// callback (implementation) functions
//--------------------------------------

// constructor, initializer, finalizer
extern JSObjectRef dateFormatConstructorCallback(JSContextRef context, JSObjectRef constructorObj,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern void initializeDateFormatCallback(JSContextRef context, JSObjectRef newDTF);
extern void finalizeDateFormatCallback(JSObjectRef locale);

// property getters
extern JSValueRef getDFPatternCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getTimeZoneCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getDFLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);

// DateFormat methods
extern JSValueRef formatDateCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef parseDateCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);

} // namespace jsicu

#endif /* JSICUDATEFORMAT_H_ */
