/*
 * jsicuNumberFormat.h
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifndef JSICUNUMBERFORMAT_H_
#define JSICUNUMBERFORMAT_H_

#include "JavaScriptCore/JavaScript.h"

#include <string>

namespace jsicu {

// function to install the NumberFormat object into the JS execution context
extern void installNumberFormatObject(JSGlobalContextRef context, JSObjectRef globalObject);

//--------------------------------------
// callback (implementation) functions
//--------------------------------------

// constructor, initializer, finalizer
extern JSObjectRef numberFormatConstructorCallback(JSContextRef context, JSObjectRef constructorObj,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern void initializeNumberFormatCallback(JSContextRef context, JSObjectRef newNF);
extern void finalizeNumberFormatCallback(JSObjectRef locale);

// property getters
extern JSValueRef getNFPatternCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getCurrencyCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getNFLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);

// NumberFormat methods
extern JSValueRef formatNumberCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef parseNumberCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);

} // namespace jsicu

#endif /* JSICUNUMBERFORMAT_H_ */
