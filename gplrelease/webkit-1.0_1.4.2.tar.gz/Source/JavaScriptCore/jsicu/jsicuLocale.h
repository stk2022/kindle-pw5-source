/*
 * jsicuLocale.h
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */

#ifndef JSICULOCALE_H_
#define JSICULOCALE_H_

#include "JavaScriptCore/JavaScript.h"

#include "unicode/locid.h"

#include <string>

namespace jsicu {

// function to install the Locale object into the JS execution context
extern void installLocaleObject(JSGlobalContextRef context, JSObjectRef globalObject);

// utility functions
extern char* extractLocaleID(JSContextRef context, JSObjectRef jsLocale, JSValueRef* exception);
extern JSObjectRef makeJSLocaleObject(JSContextRef context, const std::string& rawID, JSValueRef* exception);
extern icu::Locale makeICULocaleObject(JSContextRef context, JSObjectRef jsLocale, JSValueRef* exception);
extern icu::Locale makeICULocaleObject(JSContextRef context, JSValueRef jsLocale, JSValueRef* exception);

//--------------------------------------
// callback (implementation) functions
//--------------------------------------

// constructor, initializer, finalizer
extern JSObjectRef localeConstructorCallback(JSContextRef context, JSObjectRef constructorObj, size_t argumentCount,
        const JSValueRef arguments[], JSValueRef* exception);
extern void initializeLocaleCallback(JSContextRef context, JSObjectRef newLocale);
extern void finalizeLocaleCallback(JSObjectRef locale);

// property getters
extern JSValueRef getLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getLanguageCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getRegionCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);
extern JSValueRef getScriptCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception);

// Locale methods
extern JSValueRef availableLocalesCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef maximizedLocaleCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef minimizedLocaleCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef displayLanguageCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef displayRegionCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef displayScriptCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);
extern JSValueRef displayNameCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception);

} // namespace jsicu

#endif /* JSICULOCALE_H_ */
