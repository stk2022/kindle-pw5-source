/*
 * jsicuMsgFormat.cpp
 *
 * Copyright (c) 2011 Amazon Technologies, Inc.  All rights reserved.
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * Use is subject to license terms.
 */
#include "jsicuMsgFormat.h"

#include "jsicu.h"
#include "jsicuLocale.h"

#include "unicode/msgfmt.h"

#include <iostream> // debugging only

using namespace std;

namespace jsicu {

//======================================================================================
// MessageFormat JS class definition and installation code
//======================================================================================
/**
 * An array of JSStaticValue records describing the properties of the MessageFormat object.
 */
JSStaticValue msgFormatProperties[] = {
    { "pattern", getMFPatternCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { "locale", getMFLocaleCallback, NULL, kJSPropertyAttributeReadOnly | kJSPropertyAttributeDontDelete },
    { NULL, NULL, NULL, 0 }
};

/**
 * An array of JSStaticFunction records describing the methods of the MessageFormat object.
 */
JSStaticFunction msgFormatMethods[] = {
    { "format", formatMessageCallback, 0 },
    { NULL, NULL, 0 }
};

// NOTE: This implementation isn't thread-safe-- do we care?
static JSClassRef msgFormatClass = NULL;

/**
 * Returns the JSClassRef describing the methods and properties of the
 * MessageFormat object. (The MessageFormat JSClassRef is a singleton
 * object, and this function lazy-creates it.)
 */
static JSClassRef getMsgFormatClass() {
    if (msgFormatClass == NULL) {
        JSClassDefinition mfClassDef = kJSClassDefinitionEmpty;
        mfClassDef.className = "MessageFormat";
        mfClassDef.initialize = initializeMsgFormatCallback;
        mfClassDef.finalize = finalizeMsgFormatCallback;
        mfClassDef.staticValues = msgFormatProperties;
        mfClassDef.staticFunctions = msgFormatMethods;

        msgFormatClass = JSClassCreate(&mfClassDef);
    }
    return msgFormatClass;
}

//======================================================================================
// Install function for MessageFormat API
//======================================================================================
/**
 * Called by insertICUWrapperIntoGlobalContext() to install the MessageFormat
 * constructor into the execution context's global object.
 */
void installMsgFormatObject(JSGlobalContextRef context, JSObjectRef globalObject) {
    addConstructor(context, globalObject, "MessageFormat", getMsgFormatClass(),
            msgFormatConstructorCallback);
}

//======================================================================================
// Utility functions
//======================================================================================
/**
 * Extracts the actual ICU MessageFormat object from the specified object's
 * private-data area and throws an exception if the specified object
 * isn't a MessageFormat object.
 * @param context The JavaScript execution context
 * @param jsmf The JavaScript object to extract the internal
 *             MessageFormat object from.
 * @param exception Filled in with a JavaScript Error object if the specified
 *                  object isn't a MessageFormat object or doesn't have the
 *                  internal ICU MessageFormat object.
 */
static MessageFormat* extractMsgFormat(JSContextRef context, JSObjectRef jsmf, JSValueRef* exception) {
    MessageFormat* mf = NULL;
    if (context == NULL || JSValueIsObjectOfClass(context, jsmf, getMsgFormatClass())) {
        mf = (MessageFormat*)JSObjectGetPrivate(jsmf);
    }

    if (mf == NULL && exception != NULL) {
        // JSObjectMakeError wants an array of arguments (with a separate length
        // parameter), but the Error constructor only takes one argument, so we
        // just make a one-element array for the arguments
        JSValueRef exceptArgs[1];
        exceptArgs[0] = makeStringValue(context, "MessageFormat object does not contain implementation object");
        *exception = JSObjectMakeError(context, 1, exceptArgs, exception);
    }
    return mf;
}

//======================================================================================
// Callback (implementation) functions for MessageFormat API
//======================================================================================
/**
 * The implementation of the MessageFormat constructor.
 * This constructor takes two arguments:
 * - pattern: This is a MessageFormat pattern as described in the ICU documentation.
 *            If not specified, this defaults to the empty string (which means
 *            MessageFormat.prototype.format() will always return the empty string).
 * - locale: This is a Locale object specifying the Locale to use for formatting
 *           any numbers or dates.  If not specified, this defaults to the
 *           system default locale.
 */
JSObjectRef msgFormatConstructorCallback(JSContextRef context, JSObjectRef constructorObj, size_t argumentCount,
        const JSValueRef arguments[], JSValueRef* exception) {
    JSValueRef jsPattern = (argumentCount >= 1) ? arguments[0] : makeStringValue(context, "");
    JSValueRef jsLocale = (argumentCount >= 2) ? arguments[1] : NULL;
    Locale locale = makeICULocaleObject(context, jsLocale, exception);

    UErrorCode err = U_ZERO_ERROR;
    UnicodeString pattern;
    unicodeStringFromJSValue(context, jsPattern, pattern);
    MessageFormat* mf = new MessageFormat(pattern, locale, err);
    if (!checkICUError(err, context, exception)) {
        return JSObjectMake(context, getMsgFormatClass(), mf);
    } else {
        return NULL;
    }
}

/**
 * Called by the JS runtime when a new MessageFormat object is created.
 */
void initializeMsgFormatCallback(JSContextRef context, JSObjectRef newMF) {
    // private data object is created in constructor callback
}

/**
 * Called by the JS runtime right before a MessageFormat object is
 * released by the garbage collector.  This function releases the
 * ICU MessageFormat object, which is stored in the object's
 * private-data area.
 */
void finalizeMsgFormatCallback(JSObjectRef jsmf) {
    MessageFormat* mf = extractMsgFormat(NULL, jsmf, NULL);
    if (mf != NULL) {
        delete mf;
    }
}

/**
 * Implements the getProperty logic for the MessageFormat object's "pattern" property.
 */
JSValueRef getMFPatternCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    MessageFormat* mf = extractMsgFormat(context, thisObject, exception);
    if (mf == NULL) {
        return NULL;
    }

    UnicodeString pattern;
    mf->toPattern(pattern);
    return makeUStringValue(context, pattern);
}

/**
 * Implements the getProperty logic for the MessageFormat object's "locale" property.
 * <p>NOTE: This is NOT the "locale" value the caller passed to the constructor; it's
 * the actual locale ID of the underlying resources used by this object-- this may
 * be a more general locale ID than specified, or it might be a fallback locale
 */
JSValueRef getMFLocaleCallback(JSContextRef context, JSObjectRef thisObject, JSStringRef propertyName,
        JSValueRef* exception) {
    MessageFormat* mf = extractMsgFormat(context, thisObject, exception);
    if (mf != NULL) {
        return makeJSLocaleObject(context, mf->getLocale().getName(), exception);
    } else {
        return NULL;
    }
}

/**
 * Implements the MessageFormat.prototype.format() method.
 * This function takes a single argument, which is a JavaScript Object.
 * The property names are matched up with the names of the substitutions
 * in the MessageFormat pattern, and the property values are the
 * values that are substituted in.  That is, if the pattern is
 * "Found {count} instances of {key} in {filename}", the values
 * of the supplied object's "count", "key", and "filename" properties
 * will be substituted into the pattern.  Substitutions that don't
 * have matching properties in the argument are left alone.  Anything
 * other than an Object as the first argument to this function is
 * treated the same as a newly-created Object (i.e., you get back
 * the pattern string).
 */
JSValueRef formatMessageCallback(JSContextRef context, JSObjectRef functionObj, JSObjectRef thisObject,
        size_t argumentCount, const JSValueRef arguments[], JSValueRef* exception) {
    MessageFormat* mf = extractMsgFormat(context, thisObject, exception);
    if (mf == NULL) {
        return NULL;
    }

    JSObjectRef args;
    if (argumentCount >= 1 && JSValueIsObject(context, arguments[0])) {
        args = JSValueToObject(context, arguments[0], exception);
    } else {
        // if the user didn't supply any arguments, create an empty
        // object as a dummy argument holder
        args = JSObjectMake(context, NULL, NULL);
    }

    JSPropertyNameArrayRef properties = JSObjectCopyPropertyNames(context, args);
    size_t numProperties = JSPropertyNameArrayGetCount(properties);
    UnicodeString mfArgNames[numProperties];
    Formattable mfArgs[numProperties];
    for (size_t i = 0; i < numProperties; i++) {
        JSStringRef propertyName = JSPropertyNameArrayGetNameAtIndex(properties, i);
        mfArgNames[i] = UnicodeString(reinterpret_cast<const UChar *>(JSStringGetCharactersPtr(propertyName)), JSStringGetLength(propertyName));

        JSValueRef propertyValue = JSObjectGetProperty(context, args, propertyName, exception);
        if (JSValueIsNumber(context, propertyValue)) {
            mfArgs[i] = Formattable(JSValueToNumber(context, propertyValue, exception));
        } else if (isJSDate(context, propertyValue)) {
            UDate date = uDateFromJSDate(context, propertyValue);
            mfArgs[i] = Formattable(date, Formattable::kIsDate);
        } else {
            UnicodeString uPropertyValue;
            unicodeStringFromJSValue(context, propertyValue, uPropertyValue);
            mfArgs[i] = Formattable(uPropertyValue);
        }
    }
    JSPropertyNameArrayRelease(properties);

    UErrorCode err = U_ZERO_ERROR;
    UnicodeString result;
    mf->format(mfArgNames, mfArgs, numProperties, result, err);

    if (!checkICUError(err, context, exception)) {
        return makeUStringValue(context, result);
    } else {
        return NULL;
    }
}

} // namespace jsicu
