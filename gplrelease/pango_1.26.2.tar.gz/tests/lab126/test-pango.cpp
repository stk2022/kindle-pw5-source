#include <cairo.h>
#include <pango/pangocairo.h>
#include <fontconfig/fontconfig.h>
#include <string>

/*  To compile: g++ test-pango.cpp -o test-pango `pkg-config --cflags --libs fontconfig pangocairo` */
int main(int argc, char* argv[])
{
        int width;

        FcInitReinitialize();

        cairo_surface_t *surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 300, 300);
        cairo_t *cr = cairo_create (surface);

        PangoFontDescription *font_description  = pango_font_description_new ();
        pango_font_description_set_family (font_description, "bookerly");
        pango_font_description_set_weight (font_description, PANGO_WEIGHT_NORMAL);
        pango_font_description_set_absolute_size (font_description, 55 * PANGO_SCALE);

        PangoFontMap *awtpango_global_fontmap = pango_cairo_font_map_get_default();
        PangoContext *awtpango_global_context = pango_font_map_create_context(awtpango_global_fontmap);     ;
        awtpango_global_fontmap;

        PangoFont *font = pango_font_map_load_font(awtpango_global_fontmap, awtpango_global_context, font_description);
        pango_font_description_free(font_description);
        font_description = pango_font_describe(font);

        printf("---> Font %p<----\n", font);
        cairo_scaled_font_t *scaledFont = pango_cairo_font_get_scaled_font((PangoCairoFont *) font);
        printf("---> Scaled Font %p<----\n", scaledFont);
        PangoLayout *layout  = pango_cairo_create_layout (cr);
        printf("---> Create Layout %p<----\n", layout);

        pango_layout_set_font_description (layout, font_description);
        // Sample text to print using pango
        std::string mystr = "\u0412";
        char text[128] ;
        sprintf(text, "%s к\nB к", mystr.c_str());
        pango_layout_set_text (layout, text, -1);

        pango_layout_get_pixel_size(layout, &width, NULL);
        printf("---->Width is %d<----\n", width);

        cairo_set_source_rgb (cr, 0, 0,0);
        cairo_move_to (cr, 10.0, 50.0);

        pango_cairo_show_layout (cr, layout);

         if (cairo_surface_write_to_png (surface, "/tmp/test.png") == CAIRO_STATUS_SUCCESS)
            printf("Success writing to PNG: /tmp/test.png\n");

        pango_font_description_free (font_description);
        g_object_unref(font);
        g_object_unref(layout);
        g_object_unref(awtpango_global_context);
        cairo_destroy (cr);
        cairo_surface_destroy (surface);

        return 0;
}
