/* Pango
 * indic-xft.c:
 *
 * Copyright (C) 2001, 2002 IBM Corporation
 * Author: Eric Mader <mader@jtcsv.com>
 * Based on arabic-xft.c by Owen Taylor <otaylor@redhat.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include "config.h"

#include <string.h>
#ifdef LAB126
#ifdef HAVE_HARFBUZZNG
#include <ng/hb.h>
#include <ng/hb-ft.h>
#include <ng/hb-ot.h>
#endif // HAVE_HARFBUZZNG
#endif // LAB126

#include "indic-ot.h"
#include "pango-engine.h"
#include "pango-ot.h"
#include "pango-utils.h"
#include "pangofc-font.h"

typedef struct _PangoIndicInfo PangoIndicInfo;

typedef struct _IndicEngineFc IndicEngineFc;
typedef PangoEngineShapeClass IndicEngineFcClass ; /* No extra fields needed */

struct _IndicEngineFc
{
  PangoEngineShape shapeEngine;
  const IndicOTClassTable *classTable;
};

#define ENGINE_SUFFIX "ScriptEngineFc"
#define RENDER_TYPE PANGO_RENDER_TYPE_FC

#define INDIC_ENGINE_INFO(script) {#script ENGINE_SUFFIX, PANGO_ENGINE_TYPE_SHAPE, RENDER_TYPE, script##_scripts, G_N_ELEMENTS(script##_scripts)}

#define INDIC_OT_CLASS_TABLE(script) &script##_class_table

static PangoEngineScriptInfo deva_scripts[] = {
  { PANGO_SCRIPT_DEVANAGARI, "*" }
};

static PangoEngineScriptInfo beng_scripts[] = {
  {PANGO_SCRIPT_BENGALI, "*" }
};

static PangoEngineScriptInfo guru_scripts[] = {
  { PANGO_SCRIPT_GURMUKHI, "*" }
};

static PangoEngineScriptInfo gujr_scripts[] = {
  { PANGO_SCRIPT_GUJARATI, "*" }
};

static PangoEngineScriptInfo orya_scripts[] = {
  { PANGO_SCRIPT_ORIYA, "*" }
};

static PangoEngineScriptInfo taml_scripts[] = {
  { PANGO_SCRIPT_TAMIL, "*" }
};

static PangoEngineScriptInfo telu_scripts[] = {
  { PANGO_SCRIPT_TELUGU, "*" }
};

static PangoEngineScriptInfo knda_scripts[] = {
  { PANGO_SCRIPT_KANNADA, "*" }
};

static PangoEngineScriptInfo mlym_scripts[] = {
  { PANGO_SCRIPT_MALAYALAM, "*" }
};

static PangoEngineScriptInfo sinh_scripts[] = {
  { PANGO_SCRIPT_SINHALA, "*" }
};

static PangoEngineInfo script_engines[] = {
  INDIC_ENGINE_INFO(deva), INDIC_ENGINE_INFO(beng), INDIC_ENGINE_INFO(guru),
  INDIC_ENGINE_INFO(gujr), INDIC_ENGINE_INFO(orya), INDIC_ENGINE_INFO(taml),
  INDIC_ENGINE_INFO(telu), INDIC_ENGINE_INFO(knda), INDIC_ENGINE_INFO(mlym),
  INDIC_ENGINE_INFO(sinh)
};

/*
 * WARNING: These entries need to be in the same order as the entries
 * in script_engines[].
 *
 * FIXME: remove this requirement, either by encapsulating the order
 * in a macro that calls a body macro that can be redefined, or by
 * putting the pointers to the PangoEngineInfo in PangoIndicInfo...
 */
static const IndicOTClassTable *indic_ot_class_tables[] = {
  INDIC_OT_CLASS_TABLE(deva), INDIC_OT_CLASS_TABLE(beng), INDIC_OT_CLASS_TABLE(guru),
  INDIC_OT_CLASS_TABLE(gujr), INDIC_OT_CLASS_TABLE(orya), INDIC_OT_CLASS_TABLE(taml),
  INDIC_OT_CLASS_TABLE(telu), INDIC_OT_CLASS_TABLE(knda), INDIC_OT_CLASS_TABLE(mlym),
  INDIC_OT_CLASS_TABLE(sinh)
};

static const PangoOTFeatureMap gsub_features[] =
{
  {"ccmp", PANGO_OT_ALL_GLYPHS},
  {"locl", PANGO_OT_ALL_GLYPHS},
  {"init", init},
  {"nukt", nukt},
  {"akhn", akhn},
  {"rphf", rphf},
  {"blwf", blwf},
  {"half", half},
  {"pstf", pstf},
  {"vatu", vatu},
  {"pres", pres},
  {"blws", blws},
  {"abvs", abvs},
  {"psts", psts},
  {"haln", haln},
  {"calt", PANGO_OT_ALL_GLYPHS}
};

static const PangoOTFeatureMap gpos_features[] =
{
  {"blwm", blwm},
  {"abvm", abvm},
  {"dist", dist},
  {"kern", PANGO_OT_ALL_GLYPHS},
  {"mark", PANGO_OT_ALL_GLYPHS},
  {"mkmk", PANGO_OT_ALL_GLYPHS}
};


static void
set_glyphs (PangoFont      *font,
	    const gunichar *wcs,
	    gulong         *tags,
	    glong           n_glyphs,
	    PangoOTBuffer  *buffer,
	    gboolean        process_zwj)
{
  gint i;
  PangoFcFont *fc_font;

  g_assert (font);

  fc_font = PANGO_FC_FONT (font);
  for (i = 0; i < n_glyphs; i++)
    {
      guint glyph;

      if (pango_is_zero_width (wcs[i]) &&
	  (!process_zwj || wcs[i] != 0x200D))
	glyph = PANGO_GLYPH_EMPTY;
      else
	{
	  glyph = pango_fc_font_get_glyph (fc_font, wcs[i]);
	  if (!glyph)
	    glyph = PANGO_GET_UNKNOWN_GLYPH ( wcs[i]);
	}
      pango_ot_buffer_add_glyph (buffer, glyph, tags[i], i);
    }
}

/*
 * FIXME: should this check for null pointers, etc.?
 */
static gunichar *
expand_text(const gchar *text, glong length, glong **offsets, glong *n_chars)
{
  const gchar *p;
  gunichar *wcs, *wco;
  glong i, *oo;

  *n_chars = g_utf8_strlen (text, length);
  wcs      = g_new (gunichar, *n_chars);
  *offsets = g_new (glong, *n_chars + 1);

  p   = text;
  wco = wcs;
  oo  = *offsets;
  for (i = 0; i < *n_chars; i++)
    {
      *wco++ = g_utf8_get_char (p);
      *oo++  = p - text;

      p = g_utf8_next_char (p);
    }

  *oo = p - text;

  return wcs;
}

#ifdef LAB126
#ifdef HAVE_HARFBUZZNG
/*
 * Following are the call back functions set for the harfbuzz Ng to get font info 
 */

/**
 * The context passed from pango to Harfbuzz , which in turn can be used in the callbacks provided to Harfbuzz Ng.
 * This context is generic enough to to be used for all the harfbuzz callback routines 
 */
typedef struct _PangoFcHbContext {
  FT_Face ft_face;
  PangoFcFont *fc_font;
  gboolean vertical;
  double x_scale, y_scale; /* CTM scales. */
} PangoFcHbContext;

static hb_bool_t
pango_fc_hb_font_get_glyph (hb_font_t *font, void *font_data,
          hb_codepoint_t unicode, hb_codepoint_t variation_selector,
          hb_codepoint_t *glyph,
          void *user_data G_GNUC_UNUSED)
{
  PangoFcHbContext *context = (PangoFcHbContext *) font_data;
  PangoFcFont *fc_font = context->fc_font;

  *glyph = pango_fc_font_get_glyph (fc_font, unicode);
  if (G_LIKELY (*glyph))
    return TRUE;

  *glyph = PANGO_GET_UNKNOWN_GLYPH (unicode);

  /* We draw our own invalid-Unicode shape, so prevent HarfBuzz
   * from using REPLACEMENT CHARACTER. */
  if (unicode > 0x10FFFF)
    return TRUE;

  return FALSE;
}

// Though these are already defined in pango-fc private headers, its messey to reuse them
// So redefining these here for ease of use
#ifndef PANGO_SCALE_26_6 
#define PANGO_SCALE_26_6 (PANGO_SCALE / (1<<6))
#define PANGO_PIXELS_26_6(d)        \
  (((d) >= 0) ?           \
   ((d) + PANGO_SCALE_26_6 / 2) / PANGO_SCALE_26_6 :  \
   ((d) - PANGO_SCALE_26_6 / 2) / PANGO_SCALE_26_6)
#define PANGO_UNITS_26_6(d) (PANGO_SCALE_26_6 * (d))
#endif

static hb_position_t
pango_fc_hb_font_get_h_kerning (hb_font_t *font, void *font_data,
        hb_codepoint_t left_glyph, hb_codepoint_t right_glyph,
        void *user_data G_GNUC_UNUSED)
{
  PangoFcHbContext *context = (PangoFcHbContext *) font_data;
  PangoFcFont *fc_font = context->fc_font;
  FT_Face ft_face = pango_fc_font_lock_face (fc_font);
  
  FT_Vector kerning;

  if (FT_Get_Kerning (ft_face, left_glyph, right_glyph, FT_KERNING_DEFAULT, &kerning))
    return 0;
  
  pango_fc_font_unlock_face (fc_font);

  return PANGO_UNITS_26_6 (kerning.x * context->x_scale);
}

static hb_position_t
pango_fc_hb_font_get_glyph_advance (hb_font_t *font, void *font_data,
            hb_codepoint_t glyph,
            void *user_data G_GNUC_UNUSED)
{
  PangoFcHbContext *context = (PangoFcHbContext *) font_data;
  PangoFcFont *fc_font = context->fc_font;
  PangoRectangle logical;
  pango_font_get_glyph_extents ((PangoFont *) fc_font, glyph, NULL, &logical);
  return logical.width;
}

static hb_bool_t
pango_fc_hb_font_get_glyph_extents (hb_font_t *font,  void *font_data,
            hb_codepoint_t glyph,
            hb_glyph_extents_t *extents,
            void *user_data G_GNUC_UNUSED)
{
  PangoFcHbContext *context = (PangoFcHbContext *) font_data;
  PangoFcFont *fc_font = context->fc_font;
  PangoRectangle ink;

  pango_font_get_glyph_extents ((PangoFont *) fc_font, glyph, &ink, NULL);

  //TODO: Need to handle vertical writing of Indic. But not doing that in the first part
  //Will do this once we have some solid test data for the same
  extents->x_bearing  = ink.x;
  extents->y_bearing  = ink.y;
  extents->width      = ink.width;
  extents->height     = ink.height;

  return TRUE;
}

static hb_bool_t
pango_fc_hb_font_get_glyph_h_origin (hb_font_t *font, void *font_data,
             hb_codepoint_t glyph,
             hb_position_t *x, hb_position_t *y,
             void *user_data G_GNUC_UNUSED)
{
  PangoFcHbContext *context = (PangoFcHbContext *) font_data;
  FT_Face ft_face = context->ft_face;
  int load_flags = FT_LOAD_DEFAULT;

  if (!context->vertical) return TRUE;

  if (FT_Load_Glyph (ft_face, glyph, load_flags))
    return FALSE;

  /* Note: FreeType's vertical metrics grows downward while other FreeType coordinates
   * have a Y growing upward.  Hence the extra negation. */
  *x = PANGO_UNITS_26_6 (ft_face->glyph->metrics.horiBearingX -   ft_face->glyph->metrics.vertBearingX);
  *y = PANGO_UNITS_26_6 (ft_face->glyph->metrics.horiBearingY - (-ft_face->glyph->metrics.vertBearingY));

  *x = -*x;
  *y =  *y;

  return TRUE;
}

static hb_bool_t
pango_fc_hb_font_get_glyph_v_origin (hb_font_t *font, void *font_data,
             hb_codepoint_t glyph,
             hb_position_t *x, hb_position_t *y,
             void *user_data G_GNUC_UNUSED)
{
  PangoFcHbContext *context = (PangoFcHbContext *) font_data;
  FT_Face ft_face = context->ft_face;
  int load_flags = FT_LOAD_DEFAULT;

  /* pangocairo-fc configures font in vertical origin for vertical writing. */
  if (context->vertical) return TRUE;

  if (FT_Load_Glyph (ft_face, glyph, load_flags))
    return FALSE;

  /* Note: FreeType's vertical metrics grows downward while other FreeType coordinates
   * have a Y growing upward.  Hence the extra negation. */
  *x = PANGO_UNITS_26_6 (ft_face->glyph->metrics.horiBearingX -   ft_face->glyph->metrics.vertBearingX);
  *y = PANGO_UNITS_26_6 (ft_face->glyph->metrics.horiBearingY - (-ft_face->glyph->metrics.vertBearingY));

  return TRUE;
}

//Utility function to translate from old pango enums to new harfbuzz enums
//Auto generated using the following command
//for i in `cut -d"," -f1  pangoscript.h | grep PANGO | cut -d"_" -f3-`; do hbscr=`grep $i hbscipt.h | cut -f1 | grep HB`; if [ -z $hbscr ]; then echo $i::; else echo "case PANGO_SCRIPT_$i: return $hbscr;" | grep case; fi; done;
hb_script_t pango_script_to_hb_ng_script(const PangoScript pango_script) {
  switch(pango_script) {
    case PANGO_SCRIPT_ARMENIAN: return HB_SCRIPT_ARMENIAN;
    case PANGO_SCRIPT_BENGALI: return HB_SCRIPT_BENGALI;
    case PANGO_SCRIPT_BOPOMOFO: return HB_SCRIPT_BOPOMOFO;
    case PANGO_SCRIPT_CHEROKEE: return HB_SCRIPT_CHEROKEE;
    case PANGO_SCRIPT_COPTIC: return HB_SCRIPT_COPTIC;
    case PANGO_SCRIPT_CYRILLIC: return HB_SCRIPT_CYRILLIC;
    case PANGO_SCRIPT_DESERET: return HB_SCRIPT_DESERET;
    case PANGO_SCRIPT_DEVANAGARI: return HB_SCRIPT_DEVANAGARI;
    case PANGO_SCRIPT_ETHIOPIC: return HB_SCRIPT_ETHIOPIC;
    case PANGO_SCRIPT_GEORGIAN: return HB_SCRIPT_GEORGIAN;
    case PANGO_SCRIPT_GOTHIC: return HB_SCRIPT_GOTHIC;
    case PANGO_SCRIPT_GREEK: return HB_SCRIPT_GREEK;
    case PANGO_SCRIPT_GUJARATI: return HB_SCRIPT_GUJARATI;
    case PANGO_SCRIPT_GURMUKHI: return HB_SCRIPT_GURMUKHI;
    case PANGO_SCRIPT_HANGUL: return HB_SCRIPT_HANGUL;
    case PANGO_SCRIPT_HEBREW: return HB_SCRIPT_HEBREW;
    case PANGO_SCRIPT_HIRAGANA: return HB_SCRIPT_HIRAGANA;
    case PANGO_SCRIPT_KANNADA: return HB_SCRIPT_KANNADA;
    case PANGO_SCRIPT_KATAKANA: return HB_SCRIPT_KATAKANA;
    case PANGO_SCRIPT_KHMER: return HB_SCRIPT_KHMER;
    case PANGO_SCRIPT_LAO: return HB_SCRIPT_LAO;
    case PANGO_SCRIPT_LATIN: return HB_SCRIPT_LATIN;
    case PANGO_SCRIPT_MALAYALAM: return HB_SCRIPT_MALAYALAM;
    case PANGO_SCRIPT_MONGOLIAN: return HB_SCRIPT_MONGOLIAN;
    case PANGO_SCRIPT_MYANMAR: return HB_SCRIPT_MYANMAR;
    case PANGO_SCRIPT_OGHAM: return HB_SCRIPT_OGHAM;
    case PANGO_SCRIPT_OLD_ITALIC: return HB_SCRIPT_OLD_ITALIC;
    case PANGO_SCRIPT_ORIYA: return HB_SCRIPT_ORIYA;
    case PANGO_SCRIPT_RUNIC: return HB_SCRIPT_RUNIC;
    case PANGO_SCRIPT_SINHALA: return HB_SCRIPT_SINHALA;
    case PANGO_SCRIPT_SYRIAC: return HB_SCRIPT_SYRIAC;
    case PANGO_SCRIPT_TAMIL: return HB_SCRIPT_TAMIL;
    case PANGO_SCRIPT_TELUGU: return HB_SCRIPT_TELUGU;
    case PANGO_SCRIPT_THAANA: return HB_SCRIPT_THAANA;
    case PANGO_SCRIPT_THAI: return HB_SCRIPT_THAI;
    case PANGO_SCRIPT_TIBETAN: return HB_SCRIPT_TIBETAN;
    case PANGO_SCRIPT_YI: return HB_SCRIPT_YI;
    case PANGO_SCRIPT_TAGALOG: return HB_SCRIPT_TAGALOG;
    case PANGO_SCRIPT_HANUNOO: return HB_SCRIPT_HANUNOO;
    case PANGO_SCRIPT_BUHID: return HB_SCRIPT_BUHID;
    case PANGO_SCRIPT_TAGBANWA: return HB_SCRIPT_TAGBANWA;
    case PANGO_SCRIPT_BRAILLE: return HB_SCRIPT_BRAILLE;
    case PANGO_SCRIPT_CYPRIOT: return HB_SCRIPT_CYPRIOT;
    case PANGO_SCRIPT_LIMBU: return HB_SCRIPT_LIMBU;
    case PANGO_SCRIPT_OSMANYA: return HB_SCRIPT_OSMANYA;
    case PANGO_SCRIPT_SHAVIAN: return HB_SCRIPT_SHAVIAN;
    case PANGO_SCRIPT_LINEAR_B: return HB_SCRIPT_LINEAR_B;
    case PANGO_SCRIPT_TAI_LE: return HB_SCRIPT_TAI_LE;
    case PANGO_SCRIPT_UGARITIC: return HB_SCRIPT_UGARITIC;
    case PANGO_SCRIPT_NEW_TAI_LUE: return HB_SCRIPT_NEW_TAI_LUE;
    case PANGO_SCRIPT_BUGINESE: return HB_SCRIPT_BUGINESE;
    case PANGO_SCRIPT_GLAGOLITIC: return HB_SCRIPT_GLAGOLITIC;
    case PANGO_SCRIPT_TIFINAGH: return HB_SCRIPT_TIFINAGH;
    case PANGO_SCRIPT_SYLOTI_NAGRI: return HB_SCRIPT_SYLOTI_NAGRI;
    case PANGO_SCRIPT_OLD_PERSIAN: return HB_SCRIPT_OLD_PERSIAN;
    case PANGO_SCRIPT_KHAROSHTHI: return HB_SCRIPT_KHAROSHTHI;
    case PANGO_SCRIPT_BALINESE: return HB_SCRIPT_BALINESE;
    case PANGO_SCRIPT_CUNEIFORM: return HB_SCRIPT_CUNEIFORM;
    case PANGO_SCRIPT_PHOENICIAN: return HB_SCRIPT_PHOENICIAN;
    case PANGO_SCRIPT_PHAGS_PA: return HB_SCRIPT_PHAGS_PA;
    case PANGO_SCRIPT_NKO: return HB_SCRIPT_NKO;
    case PANGO_SCRIPT_KAYAH_LI: return HB_SCRIPT_KAYAH_LI;
    case PANGO_SCRIPT_LEPCHA: return HB_SCRIPT_LEPCHA;
    case PANGO_SCRIPT_REJANG: return HB_SCRIPT_REJANG;
    case PANGO_SCRIPT_SUNDANESE: return HB_SCRIPT_SUNDANESE;
    case PANGO_SCRIPT_SAURASHTRA: return HB_SCRIPT_SAURASHTRA;
    case PANGO_SCRIPT_CHAM: return HB_SCRIPT_CHAM;
    case PANGO_SCRIPT_OL_CHIKI: return HB_SCRIPT_OL_CHIKI;
    case PANGO_SCRIPT_VAI: return HB_SCRIPT_VAI;
    case PANGO_SCRIPT_CARIAN: return HB_SCRIPT_CARIAN;
    case PANGO_SCRIPT_LYCIAN: return HB_SCRIPT_LYCIAN;
    case PANGO_SCRIPT_LYDIAN: return HB_SCRIPT_LYDIAN;
    default:
      return HB_SCRIPT_UNKNOWN;
  }
}

//HB buffer that would be cached (would be usable by onely one thread at a time).
//If there is another thread tring to shape at that time, then it would need to create 
//new buffer & destroy that.
static hb_buffer_t *cached_hb_buffer; 
G_LOCK_DEFINE_STATIC (cached_hb_buffer);

hb_buffer_t* get_hb_buffer (gboolean *using_cached_buffer) 
{
  if(G_LIKELY (G_TRYLOCK (cached_hb_buffer))) 
  {
    if (G_UNLIKELY (!cached_hb_buffer)) 
      cached_hb_buffer = hb_buffer_create ();
    //Mark that we are using the cache
    *using_cached_buffer = TRUE;
  } else 
  {
    *using_cached_buffer = FALSE;
    return hb_buffer_create ();
  }
  return cached_hb_buffer;
}

void free_hb_buffer (hb_buffer_t* buffer, gboolean using_cached_buffer)
{
  if(G_LIKELY (using_cached_buffer)) 
  {
    hb_buffer_reset(buffer);
    G_UNLOCK(cached_hb_buffer);
  } else
  {
    hb_buffer_destroy(buffer);
  }
}

hb_font_funcs_t* get_hb_font_functions() 
{
  static hb_font_funcs_t* s_hb_callbk_ffuncs;
  if(G_UNLIKELY (!s_hb_callbk_ffuncs)) {
    s_hb_callbk_ffuncs = hb_font_funcs_create ();
    hb_font_funcs_set_glyph_func (s_hb_callbk_ffuncs, pango_fc_hb_font_get_glyph, NULL, NULL);
    hb_font_funcs_set_glyph_h_advance_func (s_hb_callbk_ffuncs, pango_fc_hb_font_get_glyph_advance, NULL, NULL);
    hb_font_funcs_set_glyph_h_origin_func (s_hb_callbk_ffuncs, pango_fc_hb_font_get_glyph_h_origin, NULL, NULL);
    hb_font_funcs_set_glyph_v_origin_func (s_hb_callbk_ffuncs, pango_fc_hb_font_get_glyph_v_origin, NULL, NULL);
    hb_font_funcs_set_glyph_extents_func (s_hb_callbk_ffuncs, pango_fc_hb_font_get_glyph_extents, NULL, NULL);
    hb_font_funcs_set_glyph_h_kerning_func (s_hb_callbk_ffuncs, pango_fc_hb_font_get_h_kerning, NULL, NULL);
  } 
  return s_hb_callbk_ffuncs;
}

#endif //HAVE_HARFBUZZNG
#endif //LAB126

/* analysis->shape_engine has the PangoEngine... */
static void
indic_engine_shape (PangoEngineShape *engine,
		    PangoFont        *font,
		    const char       *text,
		    gint              length,
		    const PangoAnalysis *analysis,
		    PangoGlyphString *glyphs)
{
  #ifdef LAB126
  #ifdef HAVE_HARFBUZZNG
    //Create the harfbuzz font & face objects
    PangoFcFont *fc_font = PANGO_FC_FONT (font);
    FT_Face ft_face = pango_fc_font_lock_face (fc_font);
    // Note: If in the future, we switch back to using hb_ft_face_create_cached, there needs to be additional functionality added
    // to free the internal FT_FACE, else there will be a memory leak.
    hb_face_t *hb_face = hb_ft_face_create_referenced (ft_face);
    hb_font_t *hb_font = hb_font_create (hb_face);
    //Create the context info needed for the callbacks
    PangoFcHbContext context;
    double x_scale_inv = 1.0;
    double y_scale_inv = 1.0;
    pango_ot_get_scale_factor(fc_font, &x_scale_inv, &y_scale_inv);
    //For non LTR negate these values
    if (analysis->gravity == PANGO_GRAVITY_WEST || analysis->gravity == PANGO_GRAVITY_NORTH)
    {
      x_scale_inv = -x_scale_inv;
      y_scale_inv = -y_scale_inv;
    }
    context.x_scale = 1. / x_scale_inv;
    context.y_scale = 1. / y_scale_inv;
    context.ft_face = ft_face;
    context.fc_font = fc_font;
    context.vertical = PANGO_GRAVITY_IS_VERTICAL (analysis->gravity);
    //Setup the callback function for getting glyph info
    hb_font_set_funcs (hb_font, get_hb_font_functions(), &context, NULL);
    //Set the scaling factor for mapping from em space to device space
    hb_font_set_scale (hb_font,
         +(((gint64) ft_face->size->metrics.x_scale * ft_face->units_per_EM) >> 12) * context.x_scale,
         -(((gint64) ft_face->size->metrics.y_scale * ft_face->units_per_EM) >> 12) * context.y_scale);
    //Set the PPEM for hinting
    hb_font_set_ppem (hb_font,
        ft_face->size->metrics.x_ppem,
        ft_face->size->metrics.y_ppem);
    //Create the Harbuff buffer and set it up 
    gboolean using_cached_buffer;
    hb_buffer_t *hb_buffer = get_hb_buffer(&using_cached_buffer);
    hb_buffer_set_direction (hb_buffer, ((analysis->level % 2) != 0) ? HB_DIRECTION_RTL : HB_DIRECTION_LTR);
    hb_buffer_set_script (hb_buffer, pango_script_to_hb_ng_script (analysis->script));
    //hb_buffer_set_language (hb_buffer, hb_language_from_string (pango_language_to_string (analysis->language), -1));
    //Set the text that needs to be shaped
    hb_buffer_add_utf8 (hb_buffer, text, length, 0, length);
    //Actual magic is done by this
    hb_shape (hb_font, hb_buffer, NULL, 0) ;
    //Get the harfbuzz output and translate that into pango glyph string
    unsigned int num_glyphs = hb_buffer_get_length (hb_buffer);
    hb_glyph_info_t *hb_glyph = hb_buffer_get_glyph_infos (hb_buffer, NULL);
    pango_glyph_string_set_size (glyphs, num_glyphs);
    hb_glyph_position_t *hb_position = hb_buffer_get_glyph_positions (hb_buffer, NULL);

    int last_cluster = -1, i =0;
    for ( i = 0; i < num_glyphs; i++)
    {
      glyphs->glyphs[i].glyph = hb_glyph[i].codepoint;
      glyphs->log_clusters[i] = hb_glyph[i].cluster;
      if (glyphs->log_clusters[i] != last_cluster)
        glyphs->glyphs[i].attr.is_cluster_start = 1;
      else
        glyphs->glyphs[i].attr.is_cluster_start = 0;
      //for enabling faster glyph indx to cluster mapping
      last_cluster = glyphs->log_clusters[i];
      //Check if we have valid (non zero) glyph id  
      if (glyphs->glyphs[i].glyph)
      {
        glyphs->glyphs[i].geometry.width = hb_position[i].x_advance;
        glyphs->glyphs[i].geometry.x_offset = hb_position[i].x_offset;
        glyphs->glyphs[i].geometry.y_offset = hb_position[i].y_offset;
      }
      else 
      {
        //Not sure what this is, so just don't move the pen
        //TODO: Is there any better way of capturing these error cases?
        glyphs->glyphs[i].geometry.width = 0;
        glyphs->glyphs[i].geometry.x_offset = 0;
        glyphs->glyphs[i].geometry.y_offset = 0;
      }
    }
    //Cleanup the harfbuzz objects
    free_hb_buffer(hb_buffer, using_cached_buffer);
    hb_font_destroy(hb_font);
    hb_face_destroy(hb_face);
    //Release the fc font object
    pango_fc_font_unlock_face (fc_font);
  #else
    PangoFcFont *fc_font;
    FT_Face face;
    PangoOTRulesetDescription desc;
    const PangoOTRuleset *ruleset;
    PangoOTBuffer *buffer;
    glong i, n_chars, n_glyphs;
    gulong *tags = NULL;
    gunichar *wc_in = NULL, *wc_out = NULL;
    glong *utf8_offsets = NULL;
    glong *indices = NULL;
    IndicEngineFc *indic_shape_engine = NULL;
    MPreFixups *mprefixups;

    g_return_if_fail (font != NULL);
    g_return_if_fail (text != NULL);
    g_return_if_fail (length >= 0);
    g_return_if_fail (analysis != NULL);

    fc_font = PANGO_FC_FONT (font);
    face = pango_fc_font_lock_face (fc_font);
    if (!face)
      return;

    indic_shape_engine = (IndicEngineFc *) engine;

    wc_in    = expand_text (text, length, &utf8_offsets, &n_chars);

    n_glyphs = indic_ot_reorder (wc_in, utf8_offsets, n_chars, indic_shape_engine->classTable, NULL, NULL, NULL, NULL);

    wc_out  = g_new (gunichar, n_glyphs);
    indices = g_new (glong,    n_glyphs);
    tags    = g_new (gulong,   n_glyphs);

    n_glyphs  = indic_ot_reorder (wc_in, utf8_offsets, n_chars, indic_shape_engine->classTable, wc_out, indices, tags, &mprefixups);

    pango_glyph_string_set_size (glyphs, n_glyphs);
    buffer = pango_ot_buffer_new (fc_font);
    pango_ot_buffer_set_rtl (buffer, analysis->level % 2 != 0);
    
    set_glyphs(font, wc_out, tags, n_glyphs, buffer,
  	     (indic_shape_engine->classTable->scriptFlags & SF_PROCESS_ZWJ) != 0);
    
    desc.script = analysis->script;
    desc.language = analysis->language;

    desc.n_static_gsub_features = G_N_ELEMENTS (gsub_features);
    desc.static_gsub_features = gsub_features;
    desc.n_static_gpos_features = G_N_ELEMENTS (gpos_features);
    desc.static_gpos_features = gpos_features;

    /* TODO populate other_features from analysis->extra_attrs */
    desc.n_other_features = 0;
    desc.other_features = NULL;
    
    ruleset = pango_ot_ruleset_get_for_description (pango_ot_info_get (face), &desc);

    /* do gsub processing */
    pango_ot_ruleset_substitute (ruleset, buffer);
    /* Fix pre-modifiers for some scripts before base consonant */
    if (mprefixups)
      {
        indic_mprefixups_apply (mprefixups, buffer);
        indic_mprefixups_free (mprefixups);
      }

    /* do gpos processing */
    pango_ot_ruleset_position (ruleset, buffer);
    pango_ot_buffer_output (buffer, glyphs);
    
    /* Get the right log_clusters values */
    for (i = 0; i < glyphs->num_glyphs; i += 1) {
      glyphs->log_clusters[i] = indices[glyphs->log_clusters[i]];
    }

    pango_fc_font_unlock_face (fc_font);

    pango_ot_buffer_destroy (buffer);
    g_free (tags);
    g_free (indices);
    g_free (wc_out);
    g_free (wc_in);
    g_free (utf8_offsets);
  #endif //HAVE_HARFBUZZNG
  #endif //LAB126
}

static void
indic_engine_fc_class_init (PangoEngineShapeClass *class)
{
  class->script_shape = indic_engine_shape;
}

PANGO_ENGINE_SHAPE_DEFINE_TYPE (IndicEngineFc, indic_engine_fc,
				indic_engine_fc_class_init, NULL)

void
PANGO_MODULE_ENTRY(init) (GTypeModule *module)
{
  indic_engine_fc_register_type (module);
}

void
PANGO_MODULE_ENTRY(exit) (void)
{
}

void
PANGO_MODULE_ENTRY(list) (PangoEngineInfo **engines,
			  int              *n_engines)
{
  *engines = script_engines;
  *n_engines = G_N_ELEMENTS (script_engines);
}

PangoEngine *
PANGO_MODULE_ENTRY(create) (const char *id)
{
  guint i;

  for (i = 0; i < G_N_ELEMENTS(script_engines); i += 1)
    {
      if (!strcmp(id, script_engines[i].id))
	{
	  IndicEngineFc *engine = g_object_new (indic_engine_fc_type, NULL);
	  engine->classTable = indic_ot_class_tables[i];

	  return (PangoEngine *)engine;
	}
    }

  return NULL;
}
