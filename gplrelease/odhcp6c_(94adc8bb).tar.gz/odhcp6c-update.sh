#!/bin/sh
[ -z "$2" ] && echo "Error: should be run by odhcpc6c" && exit 1

update_resolv() {
	local device="$1"
	local dns="$2"

	(
		flock 9
		grep -v "#odhcp6c:$device:" /var/run/resolv.conf > /tmp/resolv.conf.tmp
		echo -n >  /var/log/odhcp6c.log
		for c in $dns; do
			echo "nameserver $c #odhcp6c:$device:" >> /tmp/resolv.conf.tmp
			echo "adding dns $c" >> /var/log/odhcp6c.log
		done
		mv /tmp/resolv.conf.tmp /var/run/resolv.conf
		chmod 0644 /var/run/resolv.conf
	) 9>/tmp/resolv.conf.lock
	rm -f /tmp/resolv.conf.lock /tmp/resolv.conf.tmp
}

setup_interface () {
	local device="$1"

	# Merge RA-DNS
	for radns in $RA_DNS; do
		local duplicate=0
		for dns in $RDNSS; do
			[ "$radns" = "$dns" ] && duplicate=1
		done
		[ "$duplicate" = 0 ] && RDNSS="$RDNSS $radns"
	done

	local dnspart=""
	for dns in $RDNSS; do
		if [ -z "$dnspart" ]; then
			dnspart="\"$dns\""
		else
			dnspart="$dnspart, \"$dns\""
		fi
	done

	update_resolv "$device" "$dns"
}

teardown_interface() {
	local device="$1"

	update_resolv "$device" ""
}

(
	flock 9
	case "$2" in
		bound)
			teardown_interface "$1"
			setup_interface "$1"
		;;
		informed|updated|rebound|ra-updated)
			setup_interface "$1"
		;;
#		stopped|unbound)
#			teardown_interface "$1"
#		;;
		started)
			teardown_interface "$1"
		;;
	esac
) 9>/tmp/odhcp6c.lock.$1
rm -f /tmp/odhcp6c.lock.$1
